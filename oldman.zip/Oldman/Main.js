var Main = (function () {
    function Main(scene) {
        this.sceneMaterial = SceneMaterial.getInstance();
        this.startframe = -1;
        this.endframe = -1;
        this.target = false;
        this.chars = [];
        this.n = 1;
        this.isVisible = false;
        this.islab = false;
        this.labIsComputing = false;
        this.timer = 0;
        this.anim = [61, 90, 91, 143, 144, 168, 169, 345, 61, 90, 91, 143, 144, 168, 169, 345];
        this.ac = 0;
        this.scene = scene;
    }
    Main.prototype.start = function () {
        var _this = this;
        this.scene.enablePhysics(new BABYLON.Vector3(0, -10, 0), new BABYLON.OimoJSPlugin());

        var basis = new Basis(this.scene);

        this.ui = new Ui(this.scene);
        this.ui.bind(Constant.EVENT, function (event) {
            return _this.userEvent(event);
        });

        this.scene.enablePhysics(new BABYLON.Vector3(0, -10, 0), new BABYLON.OimoJSPlugin());

        this.addCharacters();

        this.mode_INTRO();

        var canvas = document.getElementById("renderCanvas");
        canvas.addEventListener("click", function (evt) {
            return _this.pickM(evt);
        });
    };

    Main.prototype.addCharacters = function () {
        if (this.chars.length != 0)
            this.chars = [];

        for (var i = 0; i < this.n; i++) {
            var c = new Character(this.scene, i);

            if (this.n > 1) {
                c.isVisible(false);
            }
            this.chars.push(c);
        }
    };

    Main.prototype.reset = function () {
        if (!this.islab) {
            this.n = 1;
        }
        this.labIsComputing = false;
        this.isVisible = false;

        this.ac = 0;

        this.scene.setGravity(new BABYLON.Vector3(0, -10, 0));

        for (var i = 0; i < this.chars.length; i++)
            this.chars[i].reset();

        this.ui.reset();

        this.addCharacters();

        Constant.INTRO = Constant.HANGED = Constant.PLAY = Constant.GRAVITY = Constant.LAB = this.islab = false;

        this.mode_INTRO();
    };

    Main.prototype.mode_INTRO = function () {
        this.startframe = 0;
        this.endframe = 60;
        Constant.INTRO = true;
    };

    Main.prototype.pickM = function (event) {
        if (!Constant.TARGET)
            return;
        var pickResult = this.scene.pick(event.clientX, event.clientY);

        if (pickResult.hit) {
            if (pickResult.pickedMesh.name != "ground" && pickResult.pickedMesh.name != "boxOverGround") {
                if (Constant.PLAY || Constant.INTRO) {
                    this.pick = pickResult;
                    Constant.PLAY = false;
                    Constant.INTRO = false;
                    Constant.GRAVITY = true;

                    this.ui.addDeadEnd();
                } else {
                    for (var i = 0; i < this.n; i++) {
                        this.chars[i].targetImpulse(pickResult);
                    }
                }
            }
        }
    };

    Main.prototype.impulseMode = function () {
        if (Constant.GRAVITY || Constant.LAB) {
            for (var i = 0; i < this.n; i++) {
                this.chars[i].impulse();
            }
        }
    };

    Main.prototype.targetMode = function () {
        if (Constant.TARGET)
            Constant.TARGET = false;
        else
            Constant.TARGET = true;
        this.ui.enableTarget(Constant.TARGET);
    };

    Main.prototype.loop = function () {
        if (Constant.INTRO) {
            for (var i = 0; i < this.n; i++) {
                if (this.chars[i].boxesForOimoCreated) {
                    this.chars[i].keyFrameMode();
                } else {
                    this.chars[i].startKeyframeAnimation(this.startframe, this.endframe);
                    this.chars[i].createBoxesForOimo();
                }
            }
        }

        if (Constant.PLAY) {
            for (var i = 0; i < this.n; i++) {
                this.chars[i].keyFrameMode();
            }
        }

        if (Constant.GRAVITY) {
            for (var i = 0; i < this.n; i++) {
                if (this.chars[i].oimoBodiesCreated) {
                    this.chars[i].ragdollMode();

                    if (this.pick != null) {
                        this.chars[i].targetImpulse(this.pick);
                        this.pick = null;
                    }
                } else {
                    this.chars[i].registerPhysicObject(1, 1);
                    this.chars[i].pauseKeyFrameAnimation();
                }
            }
        }

        if (Constant.HANGED) {
            for (var i = 0; i < this.n; i++) {
                if (this.chars[i].oimoBodiesCreated) {
                    this.chars[i].ragdollMode();
                    this.chars[i].dragMode();
                } else {
                    this.chars[i].registerPhysicObject(100, 1);
                    this.chars[i].pauseKeyFrameAnimation();
                }
            }
        }

        if (Constant.LAB) {
            for (var i = 0; i < this.n; i++) {
                if (this.chars[i].oimoBodiesCreated) {
                    if (this.scene.getRenderId() >= this.timer + 50) {
                        this.chars[i].ragdollMode();

                        if (!this.isVisible) {
                            this.labIsComputing = false;
                            for (var i = 0; i < this.n; i++)
                                this.chars[i].isVisible(true);
                            this.isVisible = true;
                        }
                    } else {
                        this.chars[i].translateRagdoll(0, 300);
                    }
                } else {
                    this.chars[i].registerPhysicObject(1, 1);
                    this.chars[i].pauseKeyFrameAnimation();
                }
            }
        }
    };

    Main.prototype.userEvent = function (event) {
        var _this = this;
        switch (event) {
            case Constant.CLIC_PLAY:
                console.log(this.ac);

                if (Constant.GRAVITY || Constant.HANGED || Constant.LAB) {
                    this.reset();
                    return;
                }

                this.startframe = this.anim[this.ac];
                this.endframe = this.anim[this.ac + 1];

                Constant.INTRO = false;
                Constant.PLAY = true;

                for (var i = 0; i < this.n; i++) {
                    this.chars[i].startKeyframeAnimation(this.startframe, this.endframe);
                }

                this.chars[0].canMove = false;
                this.chars[0].dummy.position = new BABYLON.Vector3(0, 0, 0);
                this.chars[0].mesh.position = new BABYLON.Vector3(0, 0, 0);

                if (this.ac == 6 || this.ac == 14) {
                    this.sceneMaterial.zombieMode(true);
                    this.chars[0].mesh.material = this.sceneMaterial.getMultimap();
                } else {
                    this.sceneMaterial.zombieMode(false);
                    this.chars[0].mesh.material = this.sceneMaterial.getMultimap();
                }

                if (this.ac == 8) {
                    this.chars[0].canMove = true;
                    this.chars[0].speed = 2;
                }
                if (this.ac == 10) {
                    this.chars[0].canMove = true;
                    this.chars[0].speed = 2.7;
                }
                if (this.ac == 12) {
                    this.chars[0].canMove = true;
                    this.chars[0].speed = 6;
                }
                if (this.ac == 14) {
                    this.chars[0].canMove = true;
                    this.chars[0].speed = .5;
                }

                this.ac = this.ac + 2;
                if (this.ac >= 16) {
                    this.ac = 0;
                }

                break;

            case Constant.CLIC_GRAVITY:
                if (Constant.LAB)
                    return;
                if (Constant.HANGED) {
                    Constant.HANGED = false;
                    Constant.GRAVITY = true;
                    for (var i = 0; i < this.n; i++) {
                        this.chars[i].setMassOimoBody(0, 1);
                    }
                    this.ui.addDeadEnd();
                }

                Constant.INTRO = false;
                Constant.PLAY = false;
                Constant.GRAVITY = true;
                this.ui.addDeadEnd();
                break;

            case Constant.CLIC_LAB:
                if (this.labIsComputing)
                    return;
                console.log("clic lab");
                this.islab = true;
                this.n = Constant.NLAB;
                this.reset();
                this.labIsComputing = true;
                setTimeout(function () {
                    return _this.fedUp();
                }, 1000);
                break;

            case Constant.CLIC_HANGED:
                if (this.chars[0].canMove)
                    return;
                if (Constant.LAB)
                    return;
                if (Constant.GRAVITY)
                    return;

                Constant.HANGED = true;
                Constant.INTRO = false;
                Constant.PLAY = false;
                break;

            case Constant.CLIC_RESET:
                this.islab = false;
                this.reset();
                break;

            case Constant.CLIC_IMPULSE:
                this.impulseMode();
                break;

            case Constant.CLIC_TARGET:
                this.targetMode();
                break;

            case Constant.CLIC_RENDER:
                this.sceneMaterial.swapRender();
                break;
        }
    };

    Main.prototype.fedUp = function () {
        this.timer = this.scene.getRenderId();
        Constant.INTRO = false;
        Constant.LAB = true;

        this.ui.addDeadEnd();
    };
    return Main;
})();
