﻿var Ini = (function () {
    function Ini() {
        var _this = this;
        this.canvas = document.getElementById("renderCanvas");

        if (!BABYLON.Engine.isSupported()) {
            window.alert('Browser not supported');
        } else {
            this.engine = new BABYLON.Engine(this.canvas, true);
            this.scene = new BABYLON.Scene(this.engine);
            this.main = new Main(this.scene);

            window.addEventListener("resize", function () {
                return _this.engine.resize();
            });

            var assets = new Assets(this.scene);
            assets.bind(Constant.EVENT_ASSETS_MANAGEMENT, function (event) {
                return _this.assetsAreLoaded(event);
            });
        }
    }
    Ini.prototype.assetsAreLoaded = function (event) {
        var _this = this;
        console.log("receive final event from assets management");
        this.main.start();
        this.scene.executeWhenReady(function () {
            return _this.iniCamera();
        });
        this.engine.runRenderLoop(function () {
            return _this.mainLoop();
        });
    };

    Ini.prototype.iniCamera = function () {
        if (this.scene.activeCamera) {
            this.scene.activeCamera.attachControl(this.canvas);
        }
    };

    Ini.prototype.mainLoop = function () {
        var container = document.getElementById("fps");
        container.innerHTML = BABYLON.Tools.GetFps().toFixed() + " fps" + "<br>";

        if (this.scene) {
            this.main.loop();
            this.scene.render();
        }
    };
    return Ini;
})();

document.addEventListener("DOMContentLoaded", function () {
    return new Ini();
}, false);
