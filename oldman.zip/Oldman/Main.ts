
class Main {

    //init things
    public scene: BABYLON.Scene;
    private shadowGenerator: BABYLON.ShadowGenerator;

    // instance of Character class
    private character: Character;

    // material 
    private sceneMaterial: SceneMaterial = SceneMaterial.getInstance();

    // keyframe animation 
    private startframe: number = -1;
    private endframe: number = -1;   

    // user interface
    private ui: Ui;

    // target boolean 
    private target: boolean = false;
    private pick: BABYLON.PickingInfo;

    //characters instances
    private chars: Character[] = [];
    // n characters
    private n: number = 1;

    // isvisible for lab
    private isVisible: boolean = false;
    private islab: boolean = false;
    private labIsComputing: boolean = false;
    // timer for lab
    private timer: number = 0;

    // animation and anim counter
    private anim = [61, 90, 91, 143, 144, 168, 169, 345, 61, 90, 91, 143, 144, 168, 169, 345]; 
    private ac: number = 0;


    constructor(scene: BABYLON.Scene) {
        this.scene = scene;       
    }

    public start(): void {

        

        //enable physic engine with oimo
        this.scene.enablePhysics(new BABYLON.Vector3(0, -10, 0), new BABYLON.OimoJSPlugin());

        // light camera and static mesh
        var basis: Basis = new Basis(this.scene);

        //User interface 
        this.ui = new Ui(this.scene);
        this.ui.bind(Constant.EVENT, (event) => this.userEvent(event));

        //enable physic engine with oimo
        this.scene.enablePhysics(new BABYLON.Vector3(0, -10, 0), new BABYLON.OimoJSPlugin());

        // Create characters instance
        this.addCharacters();        
        
        // start with intro mode, idle aniamation
        this.mode_INTRO();

        // add listener for object picking
        var canvas = document.getElementById("renderCanvas");
        canvas.addEventListener("click", (evt) => this.pickM(evt));
    }

    private addCharacters(): void {

        // add one character , multiple are supported too
        // this.character = new Character(this.scene, 0.01);

        if (this.chars.length != 0) this.chars = [];

        for (var i = 0; i < this.n; i++) {
            var c = new Character(this.scene, i);
           
            if (this.n > 1) {
                //just deal with for lab aka multiple mode
                c.isVisible(false);
            }
            this.chars.push(c);
        }
    }

    private reset(): void {


        // cas particulier lab
      //  if (Constant.LAB && this.isVisible==false) this.n = 1; 
        if (!this.islab) {
           this.n = 1;
        }
        this.labIsComputing = false;
        this.isVisible = false;

        // reset animation cycle
        this.ac = 0; 
        
        

        // reset world's gravity
        this.scene.setGravity(new BABYLON.Vector3(0, -10, 0));

        // reset character
        for (var i = 0; i < this.chars.length; i++)
            this.chars[i].reset();       
        
         // reset UI       
        this.ui.reset();       

        // Create characters instance
        this.addCharacters();

        // reset constant
        Constant.INTRO = Constant.HANGED = Constant.PLAY = Constant.GRAVITY = Constant.LAB = this.islab = false;

        // start with intro mode, idle aniamation
        this.mode_INTRO();

    }

    private mode_INTRO(): void {
     
        this.startframe = 0;
        this.endframe =60;
        Constant.INTRO = true;
    }


    private pickM(event) {   
        if (!Constant.TARGET) return;
        var pickResult: BABYLON.PickingInfo = this.scene.pick(event.clientX, event.clientY);
       
        if (pickResult.hit) {
            if (pickResult.pickedMesh.name != "ground" && pickResult.pickedMesh.name != "boxOverGround") {             

                if (Constant.PLAY || Constant.INTRO) {

                    this.pick = pickResult;
                    Constant.PLAY = false;
                    Constant.INTRO = false;
                    Constant.GRAVITY = true;

                    this.ui.addDeadEnd();
                } else {
                    for (var i = 0; i < this.n; i++) {
                        this.chars[i].targetImpulse(pickResult);
                    }
                }
            }

        }
    }

    private impulseMode(): void {
        if (Constant.GRAVITY || Constant.LAB) {
            for (var i = 0; i < this.n; i++) {
                this.chars[i].impulse();
            }
        }
    }

    private targetMode(): void {
        if (Constant.TARGET) Constant.TARGET = false; else Constant.TARGET = true;
        this.ui.enableTarget(Constant.TARGET);          
    }
    
    

    public loop(): void {
        

        if (Constant.INTRO) {
            for (var i = 0; i < this.n; i++) {
                if (this.chars[i].boxesForOimoCreated) {
                    this.chars[i].keyFrameMode();
                  
                } else {
                    this.chars[i].startKeyframeAnimation(this.startframe, this.endframe);
                    this.chars[i].createBoxesForOimo();
                }
            }
        }


        if (Constant.PLAY) {               
                for (var i = 0; i < this.n; i++) {
                    this.chars[i].keyFrameMode();
                }            
        }

        if (Constant.GRAVITY) {
            for (var i = 0; i < this.n; i++) {

                if (this.chars[i].oimoBodiesCreated) {
                    this.chars[i].ragdollMode();

                    if (this.pick != null) {
                        this.chars[i].targetImpulse(this.pick);
                        this.pick = null;
                    }

                } else {                
                    this.chars[i].registerPhysicObject(1, 1);
                    this.chars[i].pauseKeyFrameAnimation();   
                   
                }
            }


        }

        if (Constant.HANGED) {
            for (var i = 0; i < this.n; i++) {
                if (this.chars[i].oimoBodiesCreated) {
                    this.chars[i].ragdollMode();
                    this.chars[i].dragMode();

                } else {
               
                    this.chars[i].registerPhysicObject(100, 1);
                    this.chars[i].pauseKeyFrameAnimation();
                
                  
                }
            }
        }
                

        // multiple mode
        if (Constant.LAB) {

            for (var i = 0; i < this.n; i++) {
                if (this.chars[i].oimoBodiesCreated) {
                    if (this.scene.getRenderId() >= this.timer + 50) {
                        this.chars[i].ragdollMode();
                        //set visibitility not very optimize here quoi que !
                        if (!this.isVisible) {
                            this.labIsComputing = false;
                            for (var i = 0; i < this.n; i++) this.chars[i].isVisible(true); 
                            this.isVisible = true; 
                           
                        }
                        
                    } else {                                             
                        this.chars[i].translateRagdoll(0, 300);
                    }   
                } else {
                  
                    this.chars[i].registerPhysicObject(1, 1);
                    this.chars[i].pauseKeyFrameAnimation();
                }
            }       
        }      
    }


    private userEvent(event): void {
       

        switch (event) {           

            case Constant.CLIC_PLAY:
                console.log(this.ac);


                if (Constant.GRAVITY || Constant.HANGED || Constant.LAB ) {
                    this.reset(); return
                }             

                this.startframe = this.anim[this.ac];
                this.endframe =   this.anim[this.ac+1];            

                Constant.INTRO = false; Constant.PLAY = true;

                for (var i = 0; i < this.n; i++) {
                      this.chars[i].startKeyframeAnimation(this.startframe,this.endframe);                   
                }

                this.chars[0].canMove = false;
                this.chars[0].dummy.position = new BABYLON.Vector3(0, 0, 0);
                this.chars[0].mesh.position = new BABYLON.Vector3(0, 0, 0);

                // zombie mode...
                if (this.ac == 6 || this.ac == 14) {
                    this.sceneMaterial.zombieMode(true);                  
                    this.chars[0].mesh.material = this.sceneMaterial.getMultimap();
                } else {
                    this.sceneMaterial.zombieMode(false);
                    this.chars[0].mesh.material = this.sceneMaterial.getMultimap();
                }

                if (this.ac == 8) {                   
                    this.chars[0].canMove = true; 
                    this.chars[0].speed = 2;
                }
                if (this.ac == 10) {
                    this.chars[0].canMove = true;
                    this.chars[0].speed = 2.7;
                }
                if (this.ac == 12) {
                    this.chars[0].canMove = true;
                    this.chars[0].speed = 6;
                }
                if (this.ac == 14) {
                    this.chars[0].canMove = true;
                    this.chars[0].speed = .5;
                }

             

                //compteur animations
                this.ac = this.ac + 2;
                if (this.ac >=16) {                 
                    this.ac = 0;
                }
               
                break;         

            case Constant.CLIC_GRAVITY:

                if (Constant.LAB)  return; 
                if (Constant.HANGED) {
                    Constant.HANGED = false;  Constant.GRAVITY = true;
                    for (var i = 0; i < this.n; i++) {
                        // trick against joint dilatation in oimo to give normal weight to the head
                        this.chars[i].setMassOimoBody(0, 1);
                    }
                    this.ui.addDeadEnd();
                }
            
                Constant.INTRO = false; Constant.PLAY = false;  Constant.GRAVITY = true; 
                this.ui.addDeadEnd();
                break;

            case Constant.CLIC_LAB:

                if (this.labIsComputing) return;
                console.log("clic lab");          
                this.islab = true;
                this.n =Constant.NLAB; 
                this.reset();
                this.labIsComputing = true; 
                 setTimeout(() => this.fedUp(), 1000);
                break;

            case Constant.CLIC_HANGED:
                if (this.chars[0].canMove) return; 
                if (Constant.LAB) return;
                if (Constant.GRAVITY) return;      
                 
                Constant.HANGED = true; Constant.INTRO = false; Constant.PLAY = false;
                break;

            case Constant.CLIC_RESET:  
                this.islab = false;          
                this.reset();
                break;

            case Constant.CLIC_IMPULSE:
                this.impulseMode();               
                break;          

            case Constant.CLIC_TARGET:
                this.targetMode();
                break;

            case Constant.CLIC_RENDER:
                this.sceneMaterial.swapRender();
                break;

        }


    }


    private fedUp() {
        // sorry that s easy...
        this.timer = this.scene.getRenderId();
        Constant.INTRO = false; Constant.LAB = true;
     
        this.ui.addDeadEnd();
    }


   



}

