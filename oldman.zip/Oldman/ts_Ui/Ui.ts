﻿
declare var $;

class Ui extends EventManagement {

    private scene: BABYLON.Scene;
    private infoText: HTMLElement;
    private imgForbidden; 
    private imgCoche; 
    private btnplay:HTMLElement;
    private btnhanged: HTMLElement;
    private nodiv;
    private coche;
    private btngrav: HTMLElement;
    private btntarget: HTMLElement;
    private btngravity: HTMLElement;
    private gNumber: HTMLElement;
    private g: number = -10;

    private triggerGravity: boolean = true;
    private iconForbiddenisOn: boolean = false;

   

    constructor(scene:BABYLON.Scene) {
        super();

        this.scene = scene; 
        this.imgForbidden = new Image();
        this.imgForbidden.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAr9JREFUeNo8Ut1L2mEUPlm/1NTKMksKQkZ+gBbB2mBkwa6qiwpZbMkEvelfCPYHdLH7YOymi/WhW7mmll9tlY5hk9ZgA4NK0zYzoSR2FX3tPC73wI/f+77nPO97zvMcqq6uJkEQCKivrxeNj48/WV5eXszn86mLi4si/9M+n8/jcDieyWSyKuSBIxaL/y0ArVZ77yPj9g7Hx8eFg4ODZC6XOymfbWxsRHU6nQH5JXJFRQW1t7dr9/b2UkhYZQwNDT02m82KsbExEf/lfX19jwKBQAjxw8PDo46ODj14VMVYW1vbRGBqauplZWUlcXnEL9Dg4CApFAqqqamRra+vx8oVxGKxOLcqptHRUSsOVlZWQriN7yK1Wl36RCIRyMpoNPoFOdPT069cLtci1jab7TktLS29x6a3t9dSFqOhoYEkEgnV1tbKw+HwJ8Tn5ubciHd1dXXf3NzcBoPBALGaGRbnpLW1VdrY2AgCysSLYq/X6wPR4/F4+VIxzjlP4L6zZ2dnv+nq6up8f3//58jICA0MDJRe5nKF2dnZtyD6/f4gVyGDFogPDw9TMpnc5tf/UKFQyLId+ba2NimEYohmZmbegMgibdbV1SkwB4ipVCpqbm6uSqVSmWKxmCMeiA9I7OnpeQgmi/Ia+3g8nmhpaVGhVGgAIYHOzs7u6+vr21AoFCb28imS3W63B1ZhvbOz84N709z1+F95YH5+/h1y7Ha7A6MplK0AEonEdlNTkxplwmf4LZfLS8TJyckXyNna2vrGEyYpCaTX63WZTOYXAmxNxGKx3OfJklitVjIajeL+/v4HCwsLLsQxrmyXCVYS7IEgBoPB+JlRroAvO9rd3f2eTqez5TPW4avJZDJLpVLSaDRUEkOpVJZmnNeC0+m083j7T09Ps5eXl+fs51EkElmdmJhwwnuUz20Ri0l/BRgApFKKJMmgzeQAAAAASUVORK5CYII="

        this.imgCoche = new Image(); 
        this.imgCoche.src =  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA+dpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYxIDY0LjE0MDk0OSwgMjAxMC8xMi8wNy0xMDo1NzowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1LjEgV2luZG93cyIgeG1wOkNyZWF0ZURhdGU9IjIwMTQtMTAtMjVUMTY6MTE6MTIrMDI6MDAiIHhtcDpNb2RpZnlEYXRlPSIyMDE0LTEwLTI1VDE4OjQ1OjM1KzAyOjAwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDE0LTEwLTI1VDE4OjQ1OjM1KzAyOjAwIiBkYzpmb3JtYXQ9ImltYWdlL3BuZyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1NzhCRDI0QTVDNjYxMUU0OThERUI3NzUyRTQxNzgxQiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo1NzhCRDI0QjVDNjYxMUU0OThERUI3NzUyRTQxNzgxQiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkFCRTM3NUE1NUM1MTExRTRBOEZBQzMzNjFFRUExQ0ZGIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkFCRTM3NUE2NUM1MTExRTRBOEZBQzMzNjFFRUExQ0ZGIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+mu5+6AAAAKNJREFUeNrUUkEKwyAQ1H7SN0jQiwdB9Au+TyQqePATHrZ0SdMEkxJaKHRhYXeckR1dCgDk07iRL+K3Yufcy+fD89VsrcES2F8WzvOMKqXUKGaMwZmw1opCzvmOsyVBSmm4YMFASjmcrYW1Fkk555VUSkFsmqbDqXbN4gdCCBBjxFoIcWpnAIwxzxc9HHWb9Gg9tdbQeyfee/ruz+l/7vZdgAEALi9VwcWXWMwAAAAASUVORK5CYII="
        this.registerEvent(Constant.PLAY);
        this.infoText = document.getElementById("infoText");

        var y = 20;
        var index = 0;

      


        this.btnplay = document.getElementById("btnplay");
        this.btnplay.style.top = +(20 + (80 * index++)) + "px";
        this. btnplay.innerHTML = "<img src='Assets/ui/play.jpg'/>";
        this.btnplay.addEventListener("pointerup", (event) => this.clic(event, Constant.CLIC_PLAY));
        this.btnplay.addEventListener("pointerenter", (event) => this.over(event, Constant.OVER_PLAY));
        this.btnplay.addEventListener("pointerleave", (event) => this.out(event));
        

        this.btntarget = document.getElementById("btntarget");
        this.btntarget.style.top = +(20 +(80*index++))+ "px";
        this.btntarget.innerHTML = "<img src='Assets/ui/target.jpg'/>";
        this.btntarget.addEventListener("click", (event) => this.clic(event, Constant.CLIC_TARGET));
        this.btntarget.addEventListener("pointerenter", (event) => this.over(event, Constant.OVER_TARGET));
        this.btntarget.addEventListener("pointerleave", (event) => this.out(event));
     
        this.btnhanged = document.getElementById("btnhanged");
        this.btnhanged.style.top = +(20 + (80 * index++)) + "px";
        this.btnhanged.innerHTML = "<img src='Assets/ui/hanged.jpg'/>";
        this.btnhanged.addEventListener("pointerup", (event) => this.clic(event, Constant.CLIC_HANGED));
        this.btnhanged.addEventListener("pointerenter", (event) => this.over(event, Constant.OVER_HANGED));
        this.btnhanged.addEventListener("pointerleave", (event) => this.out(event));
      

         this.btngravity= document.getElementById("btngravity");
         this. btngravity.style.top = +(20 + (80 * index++)) + "px";
         this.btngravity.innerHTML = "<img src='Assets/ui/gravity.jpg'/>";
         this.btngravity.addEventListener("pointerup", (event) => this.clic(event, Constant.CLIC_GRAVITY));     
         this.btngravity.addEventListener("pointerenter", (event) => this.over(event, Constant.OVER_GRAVITY));
         this. btngravity.addEventListener("pointerleave", (event) => this.out(event));
      

        var btnimpulse = document.getElementById("btnimpulse");
        btnimpulse.style.top = +(20 + (80 * index++)) + "px";
        btnimpulse.innerHTML = "<img src='Assets/ui/impulse.jpg'/>";
        btnimpulse.addEventListener("pointerup", (event) => this.clic(event, Constant.CLIC_IMPULSE));
        btnimpulse.addEventListener("pointerenter", (event) => this.over(event, Constant.OVER_IMPULSE));
        btnimpulse.addEventListener("pointerleave", (event) => this.out(event));


        var btnlab = document.getElementById("btnlab");
        btnlab.style.top = +(20 + (80 * index++)) + "px";
        btnlab.innerHTML = "<img src='Assets/ui/lab.jpg'/>";
        btnlab.addEventListener("click", (event) => this.clicOnChangeLab(event, Constant.CLIC_LAB));
        btnlab.addEventListener("pointerenter", (event) => this.over(event, Constant.OVER_LAB));
        btnlab.addEventListener("pointerleave", (event) => this.out(event));


      
        this.btngrav = document.getElementById("btngrav");
        this.btngrav.style.top = +(20 + (80 * index++)) + "px";
        this.btngrav.innerHTML = "<img src='Assets/ui/grav.jpg'/>";
        this.btngrav.addEventListener("click", (event) => this.clicOnChangeGravity(event));
        this.btngrav.addEventListener("pointerenter", (event) => this.over(event, Constant.OVER_GRAV));
        this.btngrav.addEventListener("pointerleave", (event) => this.out(event));




        var btnrender = document.getElementById("btnrender");
        btnrender.style.top = +(20 + (80 * index++)) + "px";
        btnrender.innerHTML = "<img src='Assets/ui/bone.jpg'/>";
        btnrender.addEventListener("pointerup", (event) => this.clic(event, Constant.CLIC_RENDER));
        btnrender.addEventListener("pointerenter", (event) => this.over(event, Constant.OVER_RENDER));
        btnrender.addEventListener("pointerleave", (event) => this.out(event));



        var btnreset = document.getElementById("btnreset");
        btnreset.style.top = +(20 + (80 * index++)) + "px";
        btnreset.innerHTML = "<img src='Assets/ui/reset.jpg'/>";
        btnreset.addEventListener("click", (event) => this.clic(event, Constant.CLIC_RESET));
        btnreset.addEventListener("pointerenter", (event) => this.over(event, Constant.OVER_RESET));
        btnreset.addEventListener("pointerleave", (event) => this.out(event));

       
       

        this.gNumber = document.createElement("div");
        this.gNumber.style.position = "absolute";
        this.gNumber.style.left = "58px";
        this.gNumber.style.top = "529px";        
        this.gNumber.style.fontFamily = "Arial";
        this.gNumber.style.fontSize = "15px";
        this.gNumber.style.color = "white";
        this.gNumber.style.textAlign = "center";
        this.gNumber.innerHTML = "-10";

        document.body.appendChild(this.gNumber);



       

    }

    private clic(event, target): void {     

        // few thing to prevent   

        switch (target) {

            case Constant.CLIC_PLAY:
                this.trigger(Constant.EVENT, target);
                break;

            case Constant.CLIC_TARGET:
                this.trigger(Constant.EVENT, target);
                break;

            case Constant.CLIC_HANGED:
                this.trigger(Constant.EVENT, target);
                break;

            case Constant.CLIC_GRAVITY:
                // if gravity is on no need to trigger the event
                if (this.triggerGravity) {
                    this.trigger(Constant.EVENT, target);
                    this.triggerGravity = false;
                }
                break;

            case Constant.CLIC_IMPULSE:
                this.trigger(Constant.EVENT, target);
                break;

            case Constant.CLIC_LAB:
                // case Constant.CLIC_GRAV:
                  // + or - gravity is outside               
             //   this.trigger(Constant.EVENT, target);
                break;

            case Constant.CLIC_RENDER:
                this.trigger(Constant.EVENT, target);
                break;

            case Constant.CLIC_RESET:
                this.trigger(Constant.EVENT, target);
                break;
        }
 


    }

   
    private clicOnChangeGravity(event:any) {
      
        if (event.offsetY < 35) {         
            this.scene.setGravity(new BABYLON.Vector3(0, this.g++, 0)); 
            this.gNumber.innerHTML =this.g.toString();
        } else {             
            this.scene.setGravity(new BABYLON.Vector3(0, this.g--, 0));         
            this.gNumber.innerHTML = this.g.toString();
        }

    }

    private clicOnChangeLab(event: any , target) {


        if (event.offsetX < 35) return;
        if (event.offsetY < 23) {
            Constant.NLAB = 10;
        } else if (event.offsetY >= 23 && event.offsetY < 46) {
            Constant.NLAB = 30;
        } else if (event.offsetY >= 46) {
            Constant.NLAB = 50;
        }


        this.trigger(Constant.EVENT, target);

    }

    public enableTarget(b:boolean) {

        if (b) {         
            document.getElementById('coche').style.top = "150px";
            document.getElementById('coche').style.left = "75px";
            this.coche = document.getElementById("coche");
            //this.nodiv.innerHTML = this.imgFront.src;
            this.coche.appendChild(this.imgCoche);        
        } else {
          
            this.coche.removeChild(this.imgCoche);
        }
    }


    public addDeadEnd() {      

        if (Constant.GRAVITY) {
            document.getElementById('nodiv').style.top = "228px";
            document.getElementById('nodiv').style.left = "73px";
            this.nodiv = document.getElementById("nodiv");         
            this.nodiv.appendChild(this.imgForbidden);  
            this.iconForbiddenisOn = true;      
        }

        if (Constant.LAB) {
            document.getElementById('nodiv').style.top = "228px";
            document.getElementById('nodiv').style.left = "73px";
            this.nodiv = document.getElementById("nodiv");
            this.nodiv.appendChild(this.imgForbidden);
            this.iconForbiddenisOn = true;   
        }

    }

    public reset(): void {      

        this.g = -10;        
        this.gNumber.innerHTML = ""+ this.g
        this.triggerGravity = true;
        if (this.iconForbiddenisOn) this.nodiv.removeChild(this.imgForbidden);         
        if (Constant.TARGET) this.enableTarget(false);
        Constant.TARGET = false;
        this.iconForbiddenisOn = false;
    }



    private over(event, target): void {


        switch (target) {

            case Constant.OVER_PLAY: 
                document.getElementById('infoText').style.top = "35px";
                this.infoText.innerHTML = "click to play and switch between keyframe animations (in place mode first)";
               // this.trigger(Constant.EVENT, target);
                break;

            case Constant.OVER_TARGET:
                document.getElementById('infoText').style.top = "115px";
                this.infoText.innerHTML = "target mode";
              //  this.trigger(Constant.EVENT, target);
                break;

            case Constant.OVER_HANGED:
                document.getElementById('infoText').style.top = "195px";
                this.infoText.innerHTML = "character is linked to your pointer";
               // this.trigger(Constant.EVENT, target);
                break;

            case Constant.OVER_GRAVITY: 

                document.getElementById('infoText').style.top = "275px";
                this.infoText.innerHTML = "swich to physic mode";
              //  this.trigger(Constant.EVENT, target);
                break;

            case Constant.OVER_IMPULSE: 
                document.getElementById('infoText').style.top = "355px";
                this.infoText.innerHTML = "apply +Y Force if gravity is on";
               // this.trigger(Constant.EVENT, target);
                break;

            case Constant.OVER_LAB:
                document.getElementById('infoText').style.top = "435px";
                this.infoText.innerHTML = "Multiple characters mode - Stress test :-)";
              //  this.trigger(Constant.EVENT, target);
                break;

            case Constant.OVER_GRAV:
                document.getElementById('infoText').style.top = "515px";
                this.infoText.innerHTML = "play with world's gravity";
               // this.trigger(Constant.EVENT, target);
                break;


            case Constant.OVER_RENDER: 
                document.getElementById('infoText').style.top = "595px";
                this.infoText.innerHTML = "display skin character or skeleton";
                //this.trigger(Constant.EVENT, target);
                break;

            case Constant.OVER_RESET: 
                document.getElementById('infoText').style.top = "675px";               
                this.infoText.innerHTML = "reset scene";
                //this.trigger(Constant.EVENT, target);
                break;

          
             
        }
        this.infoText.style.transition = "opacity 3s ease-in";   
      
        setTimeout(() => {
            this.infoText.style.opacity = "0";         
        }, 0);
    }

    private out(event): void {
        this.infoText.classList.remove('transition');
        this.infoText.style.transition = "opacity 0s linear";   
        setTimeout(() => {
            this.infoText.style.opacity = "1";

        }, 0);
        this.infoText.innerHTML = "";
    }


} 