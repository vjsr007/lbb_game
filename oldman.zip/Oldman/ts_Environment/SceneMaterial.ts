﻿class SceneMaterial {

    private static _instance: SceneMaterial = null;

    public alphaImportMax: number = 1;
    public alphaOimoBones: number = 0;

    private eyesMaterial: BABYLON.StandardMaterial;
    private handMaterial: BABYLON.StandardMaterial;
    private torsoMaterial: BABYLON.StandardMaterial;
    private pantsMaterial: BABYLON.StandardMaterial;
    private headMaterial: BABYLON.StandardMaterial; 
    private shoeMaterial: BABYLON.StandardMaterial; 

    public  oimoBonesMaterial: BABYLON.StandardMaterial; 
    private groundMaterial: BABYLON.StandardMaterial; 
    private boxMaterial: BABYLON.StandardMaterial; 

    // xtra
    private teteZ: BABYLON.Texture; 
    private tDiffuse: BABYLON.Texture; 

    private scene: BABYLON.Scene;


    private multimat: BABYLON.MultiMaterial;

    constructor() {

        if (SceneMaterial._instance) {
            throw new Error("Error: Instantiation failed: Use SingletonDemo.getInstance() instead of new.");
        }

        SceneMaterial._instance = this;

    }

    public static getInstance(): SceneMaterial {
        if (SceneMaterial._instance === null) {
            SceneMaterial._instance = new SceneMaterial();
        }
        return SceneMaterial._instance;
    }

    public create(scene: BABYLON.Scene): void {


        this.scene = scene;
       
        this.headMaterial = new BABYLON.StandardMaterial("head", scene);       
        this.headMaterial.emissiveColor = new BABYLON.Color3(.8,.8,.8);
        this.headMaterial.specularColor = new BABYLON.Color3(.1,.1,.1);                
        this. tDiffuse = Assets.TeteDiffuse;
        var tBump: BABYLON.Texture = Assets.TeteBump; 
        this.headMaterial.diffuseTexture = this.tDiffuse;
        this.headMaterial.bumpTexture = Assets.TeteBump; 
     
        tBump.uScale = 80;
        tBump.vScale = 80;     
        
        
      

        this.torsoMaterial = new BABYLON.StandardMaterial("torse", scene); 
        this.torsoMaterial.emissiveColor = new BABYLON.Color3(1,1,1);
        this.torsoMaterial.specularColor = new BABYLON.Color3(.1,.1,.1);          
        var torseDiffuse: BABYLON.Texture = Assets.TorseDiffuse;
        var torseBump: BABYLON.Texture = Assets.TorseBump;
        this.torsoMaterial.diffuseTexture = torseDiffuse;
        this.torsoMaterial.bumpTexture = torseBump;     
      

        this.pantsMaterial = new BABYLON.StandardMaterial("pants", scene);
        this.pantsMaterial.emissiveColor = new BABYLON.Color3(1,1,1);
        this.pantsMaterial.specularColor = new BABYLON.Color3(0.4,0.4,0.4);
        var pantsDiffuse: BABYLON.Texture = Assets.PantsDiffuse;
        var pantsBump: BABYLON.Texture = Assets.PantsBump;
        this.pantsMaterial.diffuseTexture = pantsDiffuse;
        this.pantsMaterial.bumpTexture = pantsBump;

        this.handMaterial = new BABYLON.StandardMaterial("hand", scene);
        this.handMaterial.emissiveColor = new BABYLON.Color3(1, 1, 1);
        this.handMaterial.specularColor = new BABYLON.Color3(0.4, 0.4, 0.4);
        var handDiffuse: BABYLON.Texture = Assets.MainDiffuse;
        this.handMaterial.diffuseTexture = handDiffuse;
       
        this.eyesMaterial = new BABYLON.StandardMaterial("eyes", scene);
        this.eyesMaterial.emissiveColor = new BABYLON.Color3(1, 1, 1);
        this.eyesMaterial.specularColor = new BABYLON.Color3(0.4, 0.4, 0.4);
        var eyesDiffuse: BABYLON.Texture = Assets.EyesDiffuse;
        this.eyesMaterial.diffuseTexture = eyesDiffuse;

        this.shoeMaterial = new BABYLON.StandardMaterial("0", scene);       
        this.shoeMaterial.diffuseColor = new BABYLON.Color3(.21, 0.10, 0.04);
        this.shoeMaterial.specularColor = new BABYLON.Color3(0.31, 0.15, 0.06);
        
       

        this.multimat= new BABYLON.MultiMaterial("multi", this.scene);
        this.multimat.subMaterials.push(this.headMaterial);
        this.multimat.subMaterials.push(this.torsoMaterial);
        this.multimat.subMaterials.push(this.pantsMaterial);
        this.multimat.subMaterials.push(this.handMaterial);
        this.multimat.subMaterials.push(this.shoeMaterial);
        this.multimat.subMaterials.push(this.eyesMaterial);
        
              
       

        // oimo bones material
        this.oimoBonesMaterial = new BABYLON.StandardMaterial("oimoMesh", scene);
        this.oimoBonesMaterial.alpha = this.alphaOimoBones;
        this.oimoBonesMaterial.wireframe = false;
        this.oimoBonesMaterial.diffuseColor = new BABYLON.Color3(1, 0.45, 0);
        this.oimoBonesMaterial.emissiveColor = new BABYLON.Color3(1, 0.45, 0);
      

        //ground material
        this.groundMaterial = new BABYLON.StandardMaterial("ground", scene);
     
        this.groundMaterial.emissiveColor =   new BABYLON.Color3(.15,.15,.2);
        this.groundMaterial.diffuseColor = new BABYLON.Color3(.57,.63,.66);
        this.groundMaterial.specularColor = new BABYLON.Color3(0,0,0);

      
       
    }



    public zombieMode(b: boolean) {

        if (b) {

            this.headMaterial = new BABYLON.StandardMaterial("head", this.scene);
            this.headMaterial.emissiveColor = new BABYLON.Color3(.8, .8, .8);
            this.headMaterial.specularColor = new BABYLON.Color3(.1, .1, .1);
            this.tDiffuse = Assets.TeteZDiffuse;
            var tBump: BABYLON.Texture = Assets.TeteBump;
            this.headMaterial.diffuseTexture = this.tDiffuse;
            this.headMaterial.bumpTexture = Assets.TeteBump;

            tBump.uScale = 80;
            tBump.vScale = 80;     
          

            this.multimat = new BABYLON.MultiMaterial("multi", this.scene);
         
            this.multimat.subMaterials.push( this.headMaterial);
            this.multimat.subMaterials.push(this.torsoMaterial);
            this.multimat.subMaterials.push(this.pantsMaterial);
            this.multimat.subMaterials.push(this.handMaterial);
            this.multimat.subMaterials.push(this.shoeMaterial);
            this.multimat.subMaterials.push(this.eyesMaterial);
           
            
           
            
        }
        else {

          


            this.headMaterial = new BABYLON.StandardMaterial("head", this.scene);
            this.headMaterial.emissiveColor = new BABYLON.Color3(.8, .8, .8);
            this.headMaterial.specularColor = new BABYLON.Color3(.1, .1, .1);
            this.tDiffuse = Assets.TeteDiffuse;
            var tBump: BABYLON.Texture = Assets.TeteBump;
            this.headMaterial.diffuseTexture = this.tDiffuse;
            this.headMaterial.bumpTexture = Assets.TeteBump;

            tBump.uScale = 80;
            tBump.vScale = 80;


            this.multimat = new BABYLON.MultiMaterial("multi", this.scene);

            this.multimat.subMaterials.push(this.headMaterial);
            this.multimat.subMaterials.push(this.torsoMaterial);
            this.multimat.subMaterials.push(this.pantsMaterial);
            this.multimat.subMaterials.push(this.handMaterial);
            this.multimat.subMaterials.push(this.shoeMaterial);
            this.multimat.subMaterials.push(this.eyesMaterial);
        }
    }


    public getMultimap(): BABYLON.MultiMaterial {

        return this.multimat;
    }

    public getMaterialForImportMesh(): BABYLON.StandardMaterial {

        return this.headMaterial;
    }

    public getMaterialForGround(): BABYLON.StandardMaterial {

        return this.groundMaterial;
    }

    public getMaterialForTorso(): BABYLON.StandardMaterial {

        return this.torsoMaterial;
    }

    public getMaterialForHand(): BABYLON.StandardMaterial {

        return this.handMaterial;
    }

    public getMaterialForEyes(): BABYLON.StandardMaterial {

        return this.eyesMaterial;
    }

    public getMaterialForPants(): BABYLON.StandardMaterial {

        return this.pantsMaterial;
    }

    public getMaterialForOimoBones(): BABYLON.StandardMaterial {

        return this.oimoBonesMaterial;
    }

    public setAlphaImport(v: number): void {      

        for (var i = 0; i < this.multimat.subMaterials.length; i++) {

            this.multimat.subMaterials[i].alpha = v;               
        }
    }

    public swapRender(): void {

        if (this.oimoBonesMaterial.alpha == 0) {

            this.oimoBonesMaterial.alpha = 1;
            this.setAlphaImport(0);
        } else {
            this.oimoBonesMaterial.alpha = 0;
            this.setAlphaImport(1);
        }
       
    }

    public setOimoAlpha(v: number): void {       
        this.oimoBonesMaterial.alpha = v;
    }

    

}
