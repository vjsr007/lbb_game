﻿var Particle = (function () {
    function Particle(scene) {
        this.scene = scene;

        this.particleSystem = new BABYLON.ParticleSystem("particles", 200, this.scene);

        this.particleSystem.particleTexture = new BABYLON.Texture("Assets/misc/Flare.png", this.scene);

        this.particleSystem.minEmitBox = new BABYLON.Vector3(0, 0, 0);
        this.particleSystem.maxEmitBox = new BABYLON.Vector3(-1, -1, -1);

        this.particleSystem.color1 = new BABYLON.Color4(1, 1, 0, 1.0);
        this.particleSystem.color2 = new BABYLON.Color4(1, 1, 0, 1.0);

        this.particleSystem.minSize = 3;
        this.particleSystem.maxSize = 6;

        this.particleSystem.minLifeTime = .2;
        this.particleSystem.maxLifeTime = .6;

        this.particleSystem.emitRate = 100;

        this.particleSystem.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;

        this.particleSystem.gravity = new BABYLON.Vector3(0, -9.81, 0);

        this.particleSystem.direction1 = new BABYLON.Vector3(-2, 2, 2);
        this.particleSystem.direction2 = new BABYLON.Vector3(2, -2, -2);

        this.particleSystem.minAngularSpeed = 0;
        this.particleSystem.maxAngularSpeed = Math.PI;

        this.particleSystem.minEmitPower = 1;
        this.particleSystem.maxEmitPower = 3;
        this.particleSystem.updateSpeed = 0.005;

        this.particleSystem.targetStopDuration = 0.1;
    }
    Particle.prototype.start = function (pickResult) {
        this.particleSystem.emitter = pickResult.pickedMesh;
        this.particleSystem.start();
    };
    return Particle;
})();
