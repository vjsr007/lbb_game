﻿var SceneMaterial = (function () {
    function SceneMaterial() {
        this.alphaImportMax = 1;
        this.alphaOimoBones = 0;
        if (SceneMaterial._instance) {
            throw new Error("Error: Instantiation failed: Use SingletonDemo.getInstance() instead of new.");
        }

        SceneMaterial._instance = this;
    }
    SceneMaterial.getInstance = function () {
        if (SceneMaterial._instance === null) {
            SceneMaterial._instance = new SceneMaterial();
        }
        return SceneMaterial._instance;
    };

    SceneMaterial.prototype.create = function (scene) {
        this.scene = scene;

        this.headMaterial = new BABYLON.StandardMaterial("head", scene);
        this.headMaterial.emissiveColor = new BABYLON.Color3(.8, .8, .8);
        this.headMaterial.specularColor = new BABYLON.Color3(.1, .1, .1);
        this.tDiffuse = Assets.TeteDiffuse;
        var tBump = Assets.TeteBump;
        this.headMaterial.diffuseTexture = this.tDiffuse;
        this.headMaterial.bumpTexture = Assets.TeteBump;

        tBump.uScale = 80;
        tBump.vScale = 80;

        this.torsoMaterial = new BABYLON.StandardMaterial("torse", scene);
        this.torsoMaterial.emissiveColor = new BABYLON.Color3(1, 1, 1);
        this.torsoMaterial.specularColor = new BABYLON.Color3(.1, .1, .1);
        var torseDiffuse = Assets.TorseDiffuse;
        var torseBump = Assets.TorseBump;
        this.torsoMaterial.diffuseTexture = torseDiffuse;
        this.torsoMaterial.bumpTexture = torseBump;

        this.pantsMaterial = new BABYLON.StandardMaterial("pants", scene);
        this.pantsMaterial.emissiveColor = new BABYLON.Color3(1, 1, 1);
        this.pantsMaterial.specularColor = new BABYLON.Color3(0.4, 0.4, 0.4);
        var pantsDiffuse = Assets.PantsDiffuse;
        var pantsBump = Assets.PantsBump;
        this.pantsMaterial.diffuseTexture = pantsDiffuse;
        this.pantsMaterial.bumpTexture = pantsBump;

        this.handMaterial = new BABYLON.StandardMaterial("hand", scene);
        this.handMaterial.emissiveColor = new BABYLON.Color3(1, 1, 1);
        this.handMaterial.specularColor = new BABYLON.Color3(0.4, 0.4, 0.4);
        var handDiffuse = Assets.MainDiffuse;
        this.handMaterial.diffuseTexture = handDiffuse;

        this.eyesMaterial = new BABYLON.StandardMaterial("eyes", scene);
        this.eyesMaterial.emissiveColor = new BABYLON.Color3(1, 1, 1);
        this.eyesMaterial.specularColor = new BABYLON.Color3(0.4, 0.4, 0.4);
        var eyesDiffuse = Assets.EyesDiffuse;
        this.eyesMaterial.diffuseTexture = eyesDiffuse;

        this.shoeMaterial = new BABYLON.StandardMaterial("0", scene);
        this.shoeMaterial.diffuseColor = new BABYLON.Color3(.21, 0.10, 0.04);
        this.shoeMaterial.specularColor = new BABYLON.Color3(0.31, 0.15, 0.06);

        this.multimat = new BABYLON.MultiMaterial("multi", this.scene);
        this.multimat.subMaterials.push(this.headMaterial);
        this.multimat.subMaterials.push(this.torsoMaterial);
        this.multimat.subMaterials.push(this.pantsMaterial);
        this.multimat.subMaterials.push(this.handMaterial);
        this.multimat.subMaterials.push(this.shoeMaterial);
        this.multimat.subMaterials.push(this.eyesMaterial);

        this.oimoBonesMaterial = new BABYLON.StandardMaterial("oimoMesh", scene);
        this.oimoBonesMaterial.alpha = this.alphaOimoBones;
        this.oimoBonesMaterial.wireframe = false;
        this.oimoBonesMaterial.diffuseColor = new BABYLON.Color3(1, 0.45, 0);
        this.oimoBonesMaterial.emissiveColor = new BABYLON.Color3(1, 0.45, 0);

        this.groundMaterial = new BABYLON.StandardMaterial("ground", scene);

        this.groundMaterial.emissiveColor = new BABYLON.Color3(.15, .15, .2);
        this.groundMaterial.diffuseColor = new BABYLON.Color3(.57, .63, .66);
        this.groundMaterial.specularColor = new BABYLON.Color3(0, 0, 0);
    };

    SceneMaterial.prototype.zombieMode = function (b) {
        if (b) {
            this.headMaterial = new BABYLON.StandardMaterial("head", this.scene);
            this.headMaterial.emissiveColor = new BABYLON.Color3(.8, .8, .8);
            this.headMaterial.specularColor = new BABYLON.Color3(.1, .1, .1);
            this.tDiffuse = Assets.TeteZDiffuse;
            var tBump = Assets.TeteBump;
            this.headMaterial.diffuseTexture = this.tDiffuse;
            this.headMaterial.bumpTexture = Assets.TeteBump;

            tBump.uScale = 80;
            tBump.vScale = 80;

            this.multimat = new BABYLON.MultiMaterial("multi", this.scene);

            this.multimat.subMaterials.push(this.headMaterial);
            this.multimat.subMaterials.push(this.torsoMaterial);
            this.multimat.subMaterials.push(this.pantsMaterial);
            this.multimat.subMaterials.push(this.handMaterial);
            this.multimat.subMaterials.push(this.shoeMaterial);
            this.multimat.subMaterials.push(this.eyesMaterial);
        } else {
            this.headMaterial = new BABYLON.StandardMaterial("head", this.scene);
            this.headMaterial.emissiveColor = new BABYLON.Color3(.8, .8, .8);
            this.headMaterial.specularColor = new BABYLON.Color3(.1, .1, .1);
            this.tDiffuse = Assets.TeteDiffuse;
            var tBump = Assets.TeteBump;
            this.headMaterial.diffuseTexture = this.tDiffuse;
            this.headMaterial.bumpTexture = Assets.TeteBump;

            tBump.uScale = 80;
            tBump.vScale = 80;

            this.multimat = new BABYLON.MultiMaterial("multi", this.scene);

            this.multimat.subMaterials.push(this.headMaterial);
            this.multimat.subMaterials.push(this.torsoMaterial);
            this.multimat.subMaterials.push(this.pantsMaterial);
            this.multimat.subMaterials.push(this.handMaterial);
            this.multimat.subMaterials.push(this.shoeMaterial);
            this.multimat.subMaterials.push(this.eyesMaterial);
        }
    };

    SceneMaterial.prototype.getMultimap = function () {
        return this.multimat;
    };

    SceneMaterial.prototype.getMaterialForImportMesh = function () {
        return this.headMaterial;
    };

    SceneMaterial.prototype.getMaterialForGround = function () {
        return this.groundMaterial;
    };

    SceneMaterial.prototype.getMaterialForTorso = function () {
        return this.torsoMaterial;
    };

    SceneMaterial.prototype.getMaterialForHand = function () {
        return this.handMaterial;
    };

    SceneMaterial.prototype.getMaterialForEyes = function () {
        return this.eyesMaterial;
    };

    SceneMaterial.prototype.getMaterialForPants = function () {
        return this.pantsMaterial;
    };

    SceneMaterial.prototype.getMaterialForOimoBones = function () {
        return this.oimoBonesMaterial;
    };

    SceneMaterial.prototype.setAlphaImport = function (v) {
        for (var i = 0; i < this.multimat.subMaterials.length; i++) {
            this.multimat.subMaterials[i].alpha = v;
        }
    };

    SceneMaterial.prototype.swapRender = function () {
        if (this.oimoBonesMaterial.alpha == 0) {
            this.oimoBonesMaterial.alpha = 1;
            this.setAlphaImport(0);
        } else {
            this.oimoBonesMaterial.alpha = 0;
            this.setAlphaImport(1);
        }
    };

    SceneMaterial.prototype.setOimoAlpha = function (v) {
        this.oimoBonesMaterial.alpha = v;
    };
    SceneMaterial._instance = null;
    return SceneMaterial;
})();
