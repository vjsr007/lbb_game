﻿var Basis = (function () {
    function Basis(scene) {
        this.sceneMaterial = SceneMaterial.getInstance();
        this.scene = scene;

        var background = new BABYLON.Layer("back", "", this.scene, true, new BABYLON.Color4(1, 1, 1, 1));
        background.texture = Assets.Background;

        this.scene.ambientColor = new BABYLON.Color3(0.28, 0.39, .5);

        this.light = new BABYLON.DirectionalLight("dir01", new BABYLON.Vector3(-1, -2, -1), this.scene);
        this.light.position = new BABYLON.Vector3(100, 3000, 100);

        Basis.shadowGenerator = new BABYLON.ShadowGenerator(2048, this.light);

        this.camera = new BABYLON.ArcRotateCamera("Camera", 0, 0, 10, new BABYLON.Vector3(0, 50, 0), this.scene);
        this.camera.setPosition(new BABYLON.Vector3(-80, 80, -400));

        this.camera.upperBetaLimit = (Math.PI / 2) * 1.01;

        var ground = BABYLON.Mesh.CreateBox("ground", 20000, this.scene);
        ground.position.y = -10;
        ground.scaling.y = 0.0005;
        ground.material = this.sceneMaterial.getMaterialForGround();
        ground.receiveShadows = true;
        ground.isPickable = false;

        ground.setPhysicsState(BABYLON.PhysicsEngine.BoxImpostor, { move: false, mass: 0, friction: 0, restitution: 0, num: null });

        var box = BABYLON.Mesh.CreateBox("boxOverGround", 800, this.scene);
        box.material = this.sceneMaterial.getMaterialForGround();

        box.scaling.y = 0.05;
        box.position.y = -20;
        box.receiveShadows = true;
        box.setPhysicsState(BABYLON.PhysicsEngine.BoxImpostor, { move: false, mass: 0, friction: 0, restitution: 0, num: null });
    }
    Basis.prototype.reg = function () {
        this.camera.alpha += 0.03;
        console.log(this.camera.alpha += 0.03);
    };
    return Basis;
})();
