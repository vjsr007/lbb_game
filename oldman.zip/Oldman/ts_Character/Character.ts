﻿class Character {

    
     private scene: BABYLON.Scene

    // the skeleton
    public skeleton: BABYLON.Skeleton;
    private nBundle: number;
    private clone_skeleton: BABYLON.Skeleton;

    //mesh
    public mesh: BABYLON.AbstractMesh;
    private mesh_clone: BABYLON.AbstractMesh;

    // compteur d'instance 
    static instanceCounter: number = 0;
    private instanceID: number = 0;

    // materials single acces
    private sceneMaterial: SceneMaterial = SceneMaterial.getInstance();

    // store a 'bundle' with the babylon bones skeleton (just a point in 3d space) , the mesh, and the oimo body
    private bundles: Bundle[] = [];

    // boolean use to store offset only one time 
    private offsetsAreStored: boolean = false;

    // prevent for the main loop better to use boolean vs timestasmp
    public boxesForOimoCreated = false;
    public oimoBodiesCreated = false;
    public characterIsTranslated = false;

    //hanged mode   
    private drag: DragDrop;

    // multiragdoll mode
    private suffix: number = 0;
    private boolForTranslateMultiRagdoll: boolean = true;

    // particle
    private particleSystem: Particle

    // quaternion precompute
    private R1: BABYLON.Quaternion; 
    private R2: BABYLON.Quaternion; 
    private R3: BABYLON.Quaternion; 

    // dummy to move the mesh
    public dummy: BABYLON.Mesh; 
    public canMove: boolean = false; 
    public speed: number = 0;

    constructor(scene, suffix) {

        this.instanceID = Character.instanceCounter++;

        this.suffix = suffix;

        this.scene = scene;

        // generate character
        this.createCharacter();

        // ini PS
        this.particleSystem = new Particle(this.scene);

        // avirer d'ici plus tard mais m'en souviens plus ou...
        this.drag = new DragDrop(this.scene);

        
        // precompute 3 quaternion
        
        // 0, Math.PI / 2, Math.PI / 2
        this.R1 = new BABYLON.Quaternion(0.5, -0.4999999999999999, 0.5, 0.5000000000000001);
        //0, -Math.PI / 2, Math.PI / 2);
        this.R2 = new BABYLON.Quaternion(-0.5, 0.4999999999999999, 0.5, 0.5000000000000001);
        // 0, Math.PI, Math.PI / 2   
        this.R3 = new BABYLON.Quaternion(0.7071067811865476, -0.7071067811865475, 4.329780281177466e-17, 4.329780281177467e-17);

        //var q: BABYLON.Quaternion = BABYLON.Quaternion.RotationYawPitchRoll(0, Math.PI, 0); 

    }

 
    private regBeforeR_move(): void {
        if (this.canMove) {
            this.mesh.position.z =    this.dummy.position.z -= this.speed;          
           
        }

    }

    public createCharacter(): void {

        // this dummy is used to move the mesh
        this.dummy = new BABYLON.Mesh("dummy", this.scene);

     
        this.scene.registerBeforeRender(() => this.regBeforeR_move()) ;
        
        // get the skeleton
        this.skeleton = Assets.getSkeletonAsClone();

        // store a len to iterate 
        this.nBundle = this.skeleton.bones.length;

        // Character Mesh
        this.mesh = Assets.getCharacterAsClone();
        this.mesh.skeleton = this.skeleton;

        this.mesh.isVisible = true;
        this.mesh.isPickable = false;
        this.mesh.name = "character" + this.instanceID;     

        this.mesh.material = this.sceneMaterial.getMultimap();
     
        Basis.shadowGenerator.getShadowMap().renderList.push(this.mesh);


        //Let's create all bundles aka class for skeleton bone oimo mesh (babylon) and body (oimo)
        this.createBundles();
    }

    public reset(): void {

        // unregister oimobody -> in fact we need the mesh to unregister oimobody carreful to dummy
        for (var i = 0; i < this.nBundle; i++) {
            if (this.bundles[i].type == Constant.IS_DUMMY) continue;
            this.scene.getPhysicsEngine()._unregisterMesh(this.bundles[i].mesh);

        }

        // unregister mesh
        for (var i = 0; i < this.nBundle; i++) {
            if (this.bundles[i].type == Constant.IS_DUMMY) continue;
            this.bundles[i].mesh.dispose();
            this.bundles[i].helper.dispose();          
        }    

        //unregister character
        this.mesh.dispose();   
  

        //  finally reset  all bundle instance 'dummy include'

        for (var i = 0; i < this.nBundle; i++) {
            this.bundles[i] = null;
        }
        
        this.boxesForOimoCreated = false;
        this.oimoBodiesCreated = false;
        this.characterIsTranslated = false;
        // reset offset storing
        this.offsetsAreStored = false;
        // reset instance counter warnig it s static
        Character.instanceCounter = 0;



        // avirer d'ici plus tard
        this.drag = null;
        this.drag = new DragDrop(this.scene);

    }

    public ragdollMode() {

        this.canMove = false;
     
        // update the bones matrix to the rigth place    
        for (var i = 0; i < this.nBundle; i++) {
            // we have to intercept dummy bones 
            if (this.bundles[i].type == Constant.IS_DUMMY) continue;
            this.bundles[i].compute(this.dummy.position, this.dummy.rotationQuaternion);
        }
       // this.mesh.position.x = this.mesh.position.z = 0; 
    }

    public keyFrameMode(): void {

        // carrefull to the pelvis dummy...size center are different from max to my computing... a voir
        var parent: BABYLON.Vector3 = BABYLON.Vector3.Zero();
        var child: BABYLON.Vector3 = BABYLON.Vector3.Zero();

        for (var i = 0; i < this.nBundle; i++) {

            // we have to intercept dummy bones 
            if (this.bundles[i].type == Constant.IS_DUMMY) continue;
            // get right position easy ...
            parent = Compute.MatrixToXYZ_(parent, this.bundles[i].bone.getLocalMatrix());
            child = Compute.MatrixToXYZ_(child, this.bundles[i + 1].bone.getLocalMatrix());

            //assign postion
            var v: BABYLON.Vector3 = Compute.GetMiddle(parent, child);
            this.bundles[i].mesh.position = new BABYLON.Vector3(v.x + this.dummy.position.x, v.y, v.z + this.dummy.position.z);

            // get rotation and assign it to mesh
            var q: BABYLON.Quaternion = new BABYLON.Quaternion();

            q.fromRotationMatrix(this.bundles[i].bone.getLocalMatrix())

         
            var rotationToApply: BABYLON.Quaternion;

            //arms1 need a different correction id 11 12 14 15
            if (i == 11 || i == 12) {
                rotationToApply = this.R1
            } else if (i == 14) {
                rotationToApply = this.R2

            } else if (i == 15) {
                rotationToApply = this.R2
            }
            else {
                rotationToApply = this.R3
            }

           q = q.multiply(rotationToApply);
            // assign rotation
            this.bundles[i].mesh.rotationQuaternion = q; 

        }

        // les offsets (fucking offset) sont évalues une fois

        if (!this.offsetsAreStored) {
            for (var i = 0; i < this.nBundle - 1; i++) {
                if (this.bundles[i].type == Constant.IS_DUMMY) continue;
                this.bundles[i].offset = this.bundles[i].mesh.position;
                this.bundles[i].qset = this.bundles[i].mesh.rotationQuaternion;
            }
            this.offsetsAreStored = true;
        }

    }

    public dragMode() {

        this.bundles[0].oimoBodySetPosition(this.drag.move());
        this.bundles[0].helper.rotationQuaternion = new BABYLON.Quaternion(0, 0, 0, 1);

    }

    public isVisible(b: boolean): void {
        this.mesh.isVisible = b;
    }





    public translateRagdoll(x, yBrut): void {

        // use to get the right position for multiple ragdoll
        var y: number = yBrut + this.instanceID * 250;

        var index = 0;
        for (var i = 0; i < this.bundles.length; i++) {
            if (this.bundles[i].type == Constant.IS_DUMMY) continue;


            if (i < 5) {
                this.bundles[i].oimoBodySetPosition(new BABYLON.Vector2(x, y - 15 * index++));
            }

            if (i == 5 || i == 6) {
                this.bundles[i].oimoBodySetPosition(new BABYLON.Vector2(x + 10, y - 17 * index++));
            }

            if (i == 8 || i == 9) {
                this.bundles[i].oimoBodySetPosition(new BABYLON.Vector2(x - 10, y - 17 * (-2 + index++)));
            }

            if (i == 11 || i == 12) {
                this.bundles[i].oimoBodySetPosition(new BABYLON.Vector2(x - 20, y - 17 * (-4 + index++)));
            }

            if (i == 14 || i == 15) {
                this.bundles[i].oimoBodySetPosition(new BABYLON.Vector2(x + 20, y - 17 * (-6 + index++)));
            }


        }


        if (this.boolForTranslateMultiRagdoll) {
            this.createlink();
            this.boolForTranslateMultiRagdoll = false;
        }


        this.characterIsTranslated = true;

    }

    public impulse(): void {

        this.bundles[0].impulse(0, 8, 0);
        this.bundles[1].impulse(0, 8, 0);
    }

    public targetImpulse(pickResult: BABYLON.PickingInfo): void {
        

        // Start the particle system
        this.particleSystem.start(pickResult);

        // apply impulse at the right place
        for (var i = 0; i < this.bundles.length; i++) {
            if (this.bundles[i].type == Constant.IS_DUMMY) continue;


            if (pickResult.pickedMesh.name == this.bundles[i].mesh.name) {


                var dir = pickResult.pickedPoint.subtract(this.scene.activeCamera.position);
                dir.normalize();
                this.bundles[i].impulseTarget(dir.scale(10), pickResult.pickedPoint);


            }

        }

    }

    public setMassOimoBody(index: number, mass: number) {

        // hack of the death but  stable we give a normal weight to the head

        this.bundles[index].registerMeshAsOimoBodyPhysic(mass, .9, .1);
        var i = index;
        this.bundles[i].mesh.setPhysicsLinkWith(
            this.bundles[i + 1].mesh,
            new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0),
            new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0),
            { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true }
            );

        this.bundles[i].body = this.scene.getPhysicsEngine().getRegisterMesches()[this.scene.getPhysicsEngine().getRegisterMesches().length - 1].body;

    }

   

    public iniDragAndDrop(): void {
        this.drag = new DragDrop(this.scene);
    }

   

    public registerPhysicObject(mass1: number, mass2: number): void {


        // mass 1 and  mass 2 to deal for the moment with bad spring gestion of head to torso

        for (var i = 0; i < this.nBundle; i++) {

            // we have to intercept dummy bones 
            if (this.bundles[i].type == Constant.IS_DUMMY) continue;
            //before creating bodies store few values essantially to restore good position and rotation oimo euler vs quaternion
            this.bundles[i].storePositionJustBeforePhysic();
            // reset quaternion for each mesh due to a bug/strange behavior of oimo....
            this.bundles[i].resetQuaternion();
            // register physic body this if statement only for debug purpose. index = 0 head = mass at 0 = hanged man
            if (i == 0) {
                this.bundles[i].registerMeshAsOimoBodyPhysic(mass1, .3, .1);
            } else {
                this.bundles[i].registerMeshAsOimoBodyPhysic(mass2, .3, .1);
            }
        }


        // Physic bodies  are now created we need to bypass not a bug but a weird implementation in oimo //
        // if == 1 case only one charater if multiple joint are created in other place
        if (Character.instanceCounter == 1) {
            this.createlink();
        }

        // we get all oimo bodies as static in Bundle  x n instace ,  not very intelligent ! FIX NEEEED
        Bundle.GetPhysicBodiesInsideOimo(this.scene.getPhysicsEngine().getRegisterMesches());

        // register oimo body in each DBone instance and setPositionAndQuaternion
        //because index 0 is the ground and 1 is the box... Static for multiple instance
        var index = 2 + (this.instanceID * 12); //12 because 12 bodies

        for (var i = 0; i < this.nBundle; i++) {

            // we have to intercept dummy bones 
            if (this.bundles[i].type == Constant.IS_DUMMY) continue;

            this.bundles[i].registerBodyInDBinstance(index);
            this.bundles[i].oimoBodySetQuaternionAndPositionToReachTheRightPlace();

            // set  helper more easy that matrix computing -> dev are lazy ...
            this.bundles[i].setHelperXYZ_Q(); 
            index++
        }

        this.oimoBodiesCreated = true;
    }

    private createlink(): void {
        for (var i = 0; i < this.nBundle; i++) {

            // we have to intercept dummy bones 
            if (this.bundles[i].type == Constant.IS_DUMMY) continue;


            if (i <= 2) { // bodyup

                this.bundles[i].mesh.setPhysicsLinkWith(
                    this.bundles[i + 1].mesh,
                    new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0),
                    new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0),
                    { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true }
                    );
            }

            if (i == 5) {// left leg
                this.bundles[i].mesh.setPhysicsLinkWith(
                    this.bundles[i + 1].mesh,
                    new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0),
                    new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0),
                    { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true }
                    );
            }

            if (i == 8) {// right leg
                this.bundles[i].mesh.setPhysicsLinkWith(
                    this.bundles[i + 1].mesh,
                    new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0),
                    new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0),
                    { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true }
                    );
            }

            if (i == 8) {// right leg
                this.bundles[i].mesh.setPhysicsLinkWith(
                    this.bundles[i + 1].mesh,
                    new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0),
                    new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0),
                    { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true }
                    );
            }

            if (i == 11) {// right arm 0 &1
                this.bundles[i].mesh.setPhysicsLinkWith(
                    this.bundles[i + 1].mesh,
                    new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0),
                    new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0),
                    { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true }
                    );
            }

            if (i == 14) {// left arm 0 &1
                this.bundles[i].mesh.setPhysicsLinkWith(
                    this.bundles[i + 1].mesh,
                    new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0),
                    new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0),
                    { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true }
                    );
            }


        }

        // pelvis left leg
        this.bundles[3].mesh.setPhysicsLinkWith(
            this.bundles[5].mesh,
            new BABYLON.Vector3(3, -this.bundles[3].mesh.scaling.y / 2 - 2.5, 0),
            new BABYLON.Vector3(-3, this.bundles[5].mesh.scaling.y / 2 + 2.5, 0),
            { axe1: [1, 0, 1], axe2: [1, 0,1], collision: false }
            );
        // pelvis right leg
        this.bundles[3].mesh.setPhysicsLinkWith(
            this.bundles[8].mesh,
            new BABYLON.Vector3(-3, -this.bundles[3].mesh.scaling.y / 2 - 2.5, 0),
            new BABYLON.Vector3(3, this.bundles[8].mesh.scaling.y / 2 + 2.5, 0),
            { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: false }
            );

        // torso up left arm
        this.bundles[1].mesh.setPhysicsLinkWith(
            this.bundles[14].mesh,
            new BABYLON.Vector3(this.bundles[1].mesh.scaling.x / 2 + 1, this.bundles[1].mesh.scaling.y / 2, 0),
            new BABYLON.Vector3(-this.bundles[14].mesh.scaling.x / 2 - 1, this.bundles[14].mesh.scaling.y / 2, 0),
            { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: false }
            );

        // torso up rigth arm
        this.bundles[1].mesh.setPhysicsLinkWith(
            this.bundles[11].mesh,
            new BABYLON.Vector3(-this.bundles[1].mesh.scaling.x / 2 - 1, this.bundles[1].mesh.scaling.y / 2, 0),
            new BABYLON.Vector3(this.bundles[11].mesh.scaling.x / 2 + 1, this.bundles[11].mesh.scaling.y / 2, 0),
            { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: false }
            );

    }



  

    public createBoxesForOimo(): void {


        //  if (Constant.OIMO_BOXES_GENERATED) return; 

        for (var i = 0; i < this.nBundle; i++) {

            // we have to intercept dummy bones 
            if (this.bundles[i].type === Constant.IS_DUMMY) continue;


            //before create helper should be replace later by a matrix 
            var hlp = new BABYLON.Mesh("helper", this.scene);
            hlp.isVisible = false;
            this.bundles[i].registerHelper(hlp);


            //  console.log(i, this.bundles[i].name, "=>", this.bundles[i + 1].name);
            var length: number = Compute.GetDistanceV3(
                Compute.MatrixToXYZ(this.bundles[i + 1].bone.getAbsoluteMatrix()),
                Compute.MatrixToXYZ(this.bundles[i].bone.getAbsoluteMatrix())
                );

            // the mesh who will be convert at run time in oimo body
            var box: BABYLON.Mesh = BABYLON.Mesh.CreateBox("", 1, this.scene, true);
            box.name = this.bundles[i].name +"_"+ this.suffix;

            box.material = this.sceneMaterial.getMaterialForOimoBones();

            // -5 is to deal with jointhinge after

            // legs
            if (i == 5 || i == 6 || i == 8 || i == 9) {
                box.scaling = new BABYLON.Vector3(12, length - 5, 12);

            }
            // top body
            if (i == 1 || i == 2) {
                box.scaling = new BABYLON.Vector3(25, length - 5, 22);

            }

            if (i == 3) {
                box.scaling = new BABYLON.Vector3(18, 15, 10);

            }
            // head
            if (i == 0) {
                box.scaling = new BABYLON.Vector3(15, length - 5, 30);
            }

            // arms
            if (i == 11 || i == 12 || i == 14 || i == 15) {

                box.scaling = new BABYLON.Vector3(10, length - 5, 10);
            }

            this.bundles[i].mesh = box;
        }

        this.boxesForOimoCreated = true;


    }

    private createBundles(): void {

        for (var i = 0; i < this.nBundle; i++) {

            // Dummy bone (Constant.IS_DUMMY) are use to compute lenght at body part extremity, They are not converted as physic object.         
            // carefull when you export from max to mach bone name...
            var boneName = this.skeleton.bones[i].name;
            var type = Constant.IS_REAL;

            var id: number;

            switch (boneName) {
                case "head":
                    id = 0;
                    break;
                case "torsoUp":
                    id = 1;
                    break;
                case "torsoDown":
                    id = 2;
                    break;
                case "pelvis":
                    id = 3;
                    break;
                case "pelvisDummy":
                    id = 4;
                    type = Constant.IS_DUMMY;
                    break;
                case "thighLeft":
                    id = 5;
                    break;
                case "calfLeft":
                    id = 6;
                    break;
                case "footLeft":
                    id = 7;
                    type = Constant.IS_DUMMY;
                    break;
                case "thighRight":
                    id = 8;
                    break;
                case "calfRight":
                    id = 9;
                    break;
                case "footRight":
                    id = 10;
                    type = Constant.IS_DUMMY;
                    break;
                case "armRight0":
                    id = 11;
                    break;
                case "armRight1":
                    id = 12;
                    break;
                case "handRight":
                    id = 13;
                    type = Constant.IS_DUMMY;
                    break;
                case "armLeft0":
                    id = 14;
                    break;
                case "armLeft1":
                    id = 15;
                    break;
                case "handLeft":
                    id = 16;
                    type = Constant.IS_DUMMY;
                    break;

            }


            var temp: Bundle = new Bundle(id, type, this.skeleton.bones[i]);
            this.bundles[id] = temp;
        }
    }

    public startKeyframeAnimation(startframe, endframe): void {

        this.scene.beginAnimation(this.skeleton, startframe, endframe, true, 1);

    }

   

    public stopKeyFrameAnimation(): void {

        this.scene.stopAnimation(this.skeleton);
    }

    public pauseKeyFrameAnimation(): void {

        // warnig have to fix when stop frame is the last...

        var s = this.skeleton.getAnimatables();
        var t: number = + s[0].animations[0].currentFrame.toFixed();
        this.scene.beginAnimation(this.skeleton, t, t + 0.000001, true, 1);
    }
}