﻿


class Bundle {


    public name: string;

    public id: number;
    public type: string;

    public bone: BABYLON.Bone;
    public mesh: BABYLON.Mesh;
    public helper: BABYLON.AbstractMesh;



    // values to init mesh for oimo ans offsetrotation
    public q: BABYLON.Quaternion = new BABYLON.Quaternion();     
    public p: BABYLON.Vector3 = BABYLON.Vector3.Zero(); 
    public m: BABYLON.Matrix = BABYLON.Matrix.Identity();
    


    // for the helper
    public offset: BABYLON.Vector3;
    public qset: BABYLON.Quaternion;

    // oimo body
    public body: any;



    // physic body propertu
    private mass: number;
    private friction: number;
    private restitution: number;

    // oimo bodies register in Oimo
    static RegisteredBodiesInOimo: any[] = [];

    private wait: boolean = true;


    constructor(id: number, type: string, bone: BABYLON.Bone) {

        this.id = id;

        this.type = type;
        this.bone = bone;
        this.name = bone.name;
       // console.log(type, bone.name, id);
    }
   

    public compute(v:BABYLON.Vector3 , o:BABYLON.Quaternion): void {

        //waarning call order here are very very very ? important     
        
        // this fucking translation offset 
        var t: BABYLON.Vector3 = this.offset;
        this.helper.locallyTranslate(new BABYLON.Vector3(-t.x, -t.y, -t.z));        
       

        //compute matrix and update skeleton 
        var world: BABYLON.Matrix = this.helper.getWorldMatrix();
        world.invert();
        var m = this.bone.getWorldMatrix().multiply(world);


        // waitt 1 one frame before update this scheisse fucking merdique putain de bordel...
        if (!this.wait) {
            this.bone.update(m);
        }       
      
       // this fucking rotation quaternion offset fix
        var qinvert = BABYLON.Quaternion.Inverse(this.qset);
        var r = this.mesh.rotationQuaternion;         
        this.helper.rotationQuaternion = r.multiply(qinvert);  


        var t = new BABYLON.Vector3(this.mesh.position.x-v.x, this.mesh.position.y-v.y, this.mesh.position.z-v.z)
        this.helper.position = t; 

         this.wait = false;


    }

    public registerMeshAsOimoBodyPhysic(mass?: number, friction?: number, restitution?: number , num?:number): void {

        // have to check that
        this.mass = mass;
        this.friction = friction;
        this.restitution = restitution;
        this.mesh.setPhysicsState({ impostor: BABYLON.PhysicsEngine.BoxImpostor, move: true, mass: this.mass, friction: this.friction, restitution: this.restitution  , num : num});

    }


    public setHelperXYZ_Q() {

        this.helper.position = this.p;
        this.helper.rotationQuaternion = this.qset;


    }


    public registerHelper(helper: BABYLON.AbstractMesh): void {
        this.helper = helper;
    }

    public oimoBodySetQuaternionAndPositionToReachTheRightPlace(): void {
        this.body.setQuaternion(this.q);      
        this.body.setPosition(this.p);
    }


    public oimoBodySetQuaternion(q: BABYLON.Quaternion): void {
        this.body.setQuaternion(q);
    }

    

    public oimoBodySetPosition(v:BABYLON.Vector2): void {          
        this.body.setPosition(new BABYLON.Vector3(v.x, v.y, 0));
       
    }

    public resetQuaternion(): void {
        this.mesh.rotationQuaternion = new BABYLON.Quaternion(0, 0, 0, 1);
    }

    public storePositionJustBeforePhysic() {
       
        this.q = this.mesh.rotationQuaternion; 
        this.p = this.mesh.position; 
    }

   

    public registerBodyInDBinstance(index: number): void {       
        this.body = Bundle.RegisteredBodiesInOimo[index].body;      
    }

   

    static GetPhysicBodiesInsideOimo(bodies: any[]): void {
        // We get All bodies... Ground Included... So we have to deal with that and dummy bones...     
        Bundle.RegisteredBodiesInOimo = bodies;
    }


    public impulseTarget(force: BABYLON.Vector3, contactPoint: BABYLON.Vector3) {
        this.mesh.applyImpulse(force, contactPoint); 

    }

    public impulse(x,y,z): void {         
        var v = this.mesh.position;
        this.mesh.applyImpulse(new BABYLON.Vector3(x, y, z), v);         
    }   



}

