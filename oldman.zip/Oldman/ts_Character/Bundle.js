﻿var Bundle = (function () {
    function Bundle(id, type, bone) {
        this.q = new BABYLON.Quaternion();
        this.p = BABYLON.Vector3.Zero();
        this.m = BABYLON.Matrix.Identity();
        this.wait = true;
        this.id = id;

        this.type = type;
        this.bone = bone;
        this.name = bone.name;
    }
    Bundle.prototype.compute = function (v, o) {
        var t = this.offset;
        this.helper.locallyTranslate(new BABYLON.Vector3(-t.x, -t.y, -t.z));

        var world = this.helper.getWorldMatrix();
        world.invert();
        var m = this.bone.getWorldMatrix().multiply(world);

        if (!this.wait) {
            this.bone.update(m);
        }

        var qinvert = BABYLON.Quaternion.Inverse(this.qset);
        var r = this.mesh.rotationQuaternion;
        this.helper.rotationQuaternion = r.multiply(qinvert);

        var t = new BABYLON.Vector3(this.mesh.position.x - v.x, this.mesh.position.y - v.y, this.mesh.position.z - v.z);
        this.helper.position = t;

        this.wait = false;
    };

    Bundle.prototype.registerMeshAsOimoBodyPhysic = function (mass, friction, restitution, num) {
        this.mass = mass;
        this.friction = friction;
        this.restitution = restitution;
        this.mesh.setPhysicsState({ impostor: BABYLON.PhysicsEngine.BoxImpostor, move: true, mass: this.mass, friction: this.friction, restitution: this.restitution, num: num });
    };

    Bundle.prototype.setHelperXYZ_Q = function () {
        this.helper.position = this.p;
        this.helper.rotationQuaternion = this.qset;
    };

    Bundle.prototype.registerHelper = function (helper) {
        this.helper = helper;
    };

    Bundle.prototype.oimoBodySetQuaternionAndPositionToReachTheRightPlace = function () {
        this.body.setQuaternion(this.q);
        this.body.setPosition(this.p);
    };

    Bundle.prototype.oimoBodySetQuaternion = function (q) {
        this.body.setQuaternion(q);
    };

    Bundle.prototype.oimoBodySetPosition = function (v) {
        this.body.setPosition(new BABYLON.Vector3(v.x, v.y, 0));
    };

    Bundle.prototype.resetQuaternion = function () {
        this.mesh.rotationQuaternion = new BABYLON.Quaternion(0, 0, 0, 1);
    };

    Bundle.prototype.storePositionJustBeforePhysic = function () {
        this.q = this.mesh.rotationQuaternion;
        this.p = this.mesh.position;
    };

    Bundle.prototype.registerBodyInDBinstance = function (index) {
        this.body = Bundle.RegisteredBodiesInOimo[index].body;
    };

    Bundle.GetPhysicBodiesInsideOimo = function (bodies) {
        Bundle.RegisteredBodiesInOimo = bodies;
    };

    Bundle.prototype.impulseTarget = function (force, contactPoint) {
        this.mesh.applyImpulse(force, contactPoint);
    };

    Bundle.prototype.impulse = function (x, y, z) {
        var v = this.mesh.position;
        this.mesh.applyImpulse(new BABYLON.Vector3(x, y, z), v);
    };
    Bundle.RegisteredBodiesInOimo = [];
    return Bundle;
})();
