﻿var Character = (function () {
    function Character(scene, suffix) {
        this.instanceID = 0;
        this.sceneMaterial = SceneMaterial.getInstance();
        this.bundles = [];
        this.offsetsAreStored = false;
        this.boxesForOimoCreated = false;
        this.oimoBodiesCreated = false;
        this.characterIsTranslated = false;
        this.suffix = 0;
        this.boolForTranslateMultiRagdoll = true;
        this.canMove = false;
        this.speed = 0;
        this.instanceID = Character.instanceCounter++;

        this.suffix = suffix;

        this.scene = scene;

        this.createCharacter();

        this.particleSystem = new Particle(this.scene);

        this.drag = new DragDrop(this.scene);

        this.R1 = new BABYLON.Quaternion(0.5, -0.4999999999999999, 0.5, 0.5000000000000001);

        this.R2 = new BABYLON.Quaternion(-0.5, 0.4999999999999999, 0.5, 0.5000000000000001);

        this.R3 = new BABYLON.Quaternion(0.7071067811865476, -0.7071067811865475, 4.329780281177466e-17, 4.329780281177467e-17);
    }
    Character.prototype.regBeforeR_move = function () {
        if (this.canMove) {
            this.mesh.position.z = this.dummy.position.z -= this.speed;
        }
    };

    Character.prototype.createCharacter = function () {
        var _this = this;
        this.dummy = new BABYLON.Mesh("dummy", this.scene);

        this.scene.registerBeforeRender(function () {
            return _this.regBeforeR_move();
        });

        this.skeleton = Assets.getSkeletonAsClone();

        this.nBundle = this.skeleton.bones.length;

        this.mesh = Assets.getCharacterAsClone();
        this.mesh.skeleton = this.skeleton;

        this.mesh.isVisible = true;
        this.mesh.isPickable = false;
        this.mesh.name = "character" + this.instanceID;

        this.mesh.material = this.sceneMaterial.getMultimap();

        Basis.shadowGenerator.getShadowMap().renderList.push(this.mesh);

        this.createBundles();
    };

    Character.prototype.reset = function () {
        for (var i = 0; i < this.nBundle; i++) {
            if (this.bundles[i].type == Constant.IS_DUMMY)
                continue;
            this.scene.getPhysicsEngine()._unregisterMesh(this.bundles[i].mesh);
        }

        for (var i = 0; i < this.nBundle; i++) {
            if (this.bundles[i].type == Constant.IS_DUMMY)
                continue;
            this.bundles[i].mesh.dispose();
            this.bundles[i].helper.dispose();
        }

        this.mesh.dispose();

        for (var i = 0; i < this.nBundle; i++) {
            this.bundles[i] = null;
        }

        this.boxesForOimoCreated = false;
        this.oimoBodiesCreated = false;
        this.characterIsTranslated = false;

        this.offsetsAreStored = false;

        Character.instanceCounter = 0;

        this.drag = null;
        this.drag = new DragDrop(this.scene);
    };

    Character.prototype.ragdollMode = function () {
        this.canMove = false;

        for (var i = 0; i < this.nBundle; i++) {
            if (this.bundles[i].type == Constant.IS_DUMMY)
                continue;
            this.bundles[i].compute(this.dummy.position, this.dummy.rotationQuaternion);
        }
    };

    Character.prototype.keyFrameMode = function () {
        var parent = BABYLON.Vector3.Zero();
        var child = BABYLON.Vector3.Zero();

        for (var i = 0; i < this.nBundle; i++) {
            if (this.bundles[i].type == Constant.IS_DUMMY)
                continue;

            parent = Compute.MatrixToXYZ_(parent, this.bundles[i].bone.getLocalMatrix());
            child = Compute.MatrixToXYZ_(child, this.bundles[i + 1].bone.getLocalMatrix());

            var v = Compute.GetMiddle(parent, child);
            this.bundles[i].mesh.position = new BABYLON.Vector3(v.x + this.dummy.position.x, v.y, v.z + this.dummy.position.z);

            var q = new BABYLON.Quaternion();

            q.fromRotationMatrix(this.bundles[i].bone.getLocalMatrix());

            var rotationToApply;

            if (i == 11 || i == 12) {
                rotationToApply = this.R1;
            } else if (i == 14) {
                rotationToApply = this.R2;
            } else if (i == 15) {
                rotationToApply = this.R2;
            } else {
                rotationToApply = this.R3;
            }

            q = q.multiply(rotationToApply);

            this.bundles[i].mesh.rotationQuaternion = q;
        }

        if (!this.offsetsAreStored) {
            for (var i = 0; i < this.nBundle - 1; i++) {
                if (this.bundles[i].type == Constant.IS_DUMMY)
                    continue;
                this.bundles[i].offset = this.bundles[i].mesh.position;
                this.bundles[i].qset = this.bundles[i].mesh.rotationQuaternion;
            }
            this.offsetsAreStored = true;
        }
    };

    Character.prototype.dragMode = function () {
        this.bundles[0].oimoBodySetPosition(this.drag.move());
        this.bundles[0].helper.rotationQuaternion = new BABYLON.Quaternion(0, 0, 0, 1);
    };

    Character.prototype.isVisible = function (b) {
        this.mesh.isVisible = b;
    };

    Character.prototype.translateRagdoll = function (x, yBrut) {
        var y = yBrut + this.instanceID * 250;

        var index = 0;
        for (var i = 0; i < this.bundles.length; i++) {
            if (this.bundles[i].type == Constant.IS_DUMMY)
                continue;

            if (i < 5) {
                this.bundles[i].oimoBodySetPosition(new BABYLON.Vector2(x, y - 15 * index++));
            }

            if (i == 5 || i == 6) {
                this.bundles[i].oimoBodySetPosition(new BABYLON.Vector2(x + 10, y - 17 * index++));
            }

            if (i == 8 || i == 9) {
                this.bundles[i].oimoBodySetPosition(new BABYLON.Vector2(x - 10, y - 17 * (-2 + index++)));
            }

            if (i == 11 || i == 12) {
                this.bundles[i].oimoBodySetPosition(new BABYLON.Vector2(x - 20, y - 17 * (-4 + index++)));
            }

            if (i == 14 || i == 15) {
                this.bundles[i].oimoBodySetPosition(new BABYLON.Vector2(x + 20, y - 17 * (-6 + index++)));
            }
        }

        if (this.boolForTranslateMultiRagdoll) {
            this.createlink();
            this.boolForTranslateMultiRagdoll = false;
        }

        this.characterIsTranslated = true;
    };

    Character.prototype.impulse = function () {
        this.bundles[0].impulse(0, 8, 0);
        this.bundles[1].impulse(0, 8, 0);
    };

    Character.prototype.targetImpulse = function (pickResult) {
        this.particleSystem.start(pickResult);

        for (var i = 0; i < this.bundles.length; i++) {
            if (this.bundles[i].type == Constant.IS_DUMMY)
                continue;

            if (pickResult.pickedMesh.name == this.bundles[i].mesh.name) {
                var dir = pickResult.pickedPoint.subtract(this.scene.activeCamera.position);
                dir.normalize();
                this.bundles[i].impulseTarget(dir.scale(10), pickResult.pickedPoint);
            }
        }
    };

    Character.prototype.setMassOimoBody = function (index, mass) {
        this.bundles[index].registerMeshAsOimoBodyPhysic(mass, .9, .1);
        var i = index;
        this.bundles[i].mesh.setPhysicsLinkWith(this.bundles[i + 1].mesh, new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0), new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0), { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true });

        this.bundles[i].body = this.scene.getPhysicsEngine().getRegisterMesches()[this.scene.getPhysicsEngine().getRegisterMesches().length - 1].body;
    };

    Character.prototype.iniDragAndDrop = function () {
        this.drag = new DragDrop(this.scene);
    };

    Character.prototype.registerPhysicObject = function (mass1, mass2) {
        for (var i = 0; i < this.nBundle; i++) {
            if (this.bundles[i].type == Constant.IS_DUMMY)
                continue;

            this.bundles[i].storePositionJustBeforePhysic();

            this.bundles[i].resetQuaternion();

            if (i == 0) {
                this.bundles[i].registerMeshAsOimoBodyPhysic(mass1, .3, .1);
            } else {
                this.bundles[i].registerMeshAsOimoBodyPhysic(mass2, .3, .1);
            }
        }

        if (Character.instanceCounter == 1) {
            this.createlink();
        }

        Bundle.GetPhysicBodiesInsideOimo(this.scene.getPhysicsEngine().getRegisterMesches());

        var index = 2 + (this.instanceID * 12);

        for (var i = 0; i < this.nBundle; i++) {
            if (this.bundles[i].type == Constant.IS_DUMMY)
                continue;

            this.bundles[i].registerBodyInDBinstance(index);
            this.bundles[i].oimoBodySetQuaternionAndPositionToReachTheRightPlace();

            this.bundles[i].setHelperXYZ_Q();
            index++;
        }

        this.oimoBodiesCreated = true;
    };

    Character.prototype.createlink = function () {
        for (var i = 0; i < this.nBundle; i++) {
            if (this.bundles[i].type == Constant.IS_DUMMY)
                continue;

            if (i <= 2) {
                this.bundles[i].mesh.setPhysicsLinkWith(this.bundles[i + 1].mesh, new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0), new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0), { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true });
            }

            if (i == 5) {
                this.bundles[i].mesh.setPhysicsLinkWith(this.bundles[i + 1].mesh, new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0), new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0), { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true });
            }

            if (i == 8) {
                this.bundles[i].mesh.setPhysicsLinkWith(this.bundles[i + 1].mesh, new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0), new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0), { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true });
            }

            if (i == 8) {
                this.bundles[i].mesh.setPhysicsLinkWith(this.bundles[i + 1].mesh, new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0), new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0), { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true });
            }

            if (i == 11) {
                this.bundles[i].mesh.setPhysicsLinkWith(this.bundles[i + 1].mesh, new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0), new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0), { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true });
            }

            if (i == 14) {
                this.bundles[i].mesh.setPhysicsLinkWith(this.bundles[i + 1].mesh, new BABYLON.Vector3(0, -this.bundles[i].mesh.scaling.y / 2 - 2.5, 0), new BABYLON.Vector3(0, this.bundles[i + 1].mesh.scaling.y / 2 + 2.5, 0), { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: true });
            }
        }

        this.bundles[3].mesh.setPhysicsLinkWith(this.bundles[5].mesh, new BABYLON.Vector3(3, -this.bundles[3].mesh.scaling.y / 2 - 2.5, 0), new BABYLON.Vector3(-3, this.bundles[5].mesh.scaling.y / 2 + 2.5, 0), { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: false });

        this.bundles[3].mesh.setPhysicsLinkWith(this.bundles[8].mesh, new BABYLON.Vector3(-3, -this.bundles[3].mesh.scaling.y / 2 - 2.5, 0), new BABYLON.Vector3(3, this.bundles[8].mesh.scaling.y / 2 + 2.5, 0), { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: false });

        this.bundles[1].mesh.setPhysicsLinkWith(this.bundles[14].mesh, new BABYLON.Vector3(this.bundles[1].mesh.scaling.x / 2 + 1, this.bundles[1].mesh.scaling.y / 2, 0), new BABYLON.Vector3(-this.bundles[14].mesh.scaling.x / 2 - 1, this.bundles[14].mesh.scaling.y / 2, 0), { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: false });

        this.bundles[1].mesh.setPhysicsLinkWith(this.bundles[11].mesh, new BABYLON.Vector3(-this.bundles[1].mesh.scaling.x / 2 - 1, this.bundles[1].mesh.scaling.y / 2, 0), new BABYLON.Vector3(this.bundles[11].mesh.scaling.x / 2 + 1, this.bundles[11].mesh.scaling.y / 2, 0), { axe1: [1, 0, 1], axe2: [1, 0, 1], collision: false });
    };

    Character.prototype.createBoxesForOimo = function () {
        for (var i = 0; i < this.nBundle; i++) {
            if (this.bundles[i].type === Constant.IS_DUMMY)
                continue;

            var hlp = new BABYLON.Mesh("helper", this.scene);
            hlp.isVisible = false;
            this.bundles[i].registerHelper(hlp);

            var length = Compute.GetDistanceV3(Compute.MatrixToXYZ(this.bundles[i + 1].bone.getAbsoluteMatrix()), Compute.MatrixToXYZ(this.bundles[i].bone.getAbsoluteMatrix()));

            var box = BABYLON.Mesh.CreateBox("", 1, this.scene, true);
            box.name = this.bundles[i].name + "_" + this.suffix;

            box.material = this.sceneMaterial.getMaterialForOimoBones();

            if (i == 5 || i == 6 || i == 8 || i == 9) {
                box.scaling = new BABYLON.Vector3(12, length - 5, 12);
            }

            if (i == 1 || i == 2) {
                box.scaling = new BABYLON.Vector3(25, length - 5, 22);
            }

            if (i == 3) {
                box.scaling = new BABYLON.Vector3(18, 15, 10);
            }

            if (i == 0) {
                box.scaling = new BABYLON.Vector3(15, length - 5, 30);
            }

            if (i == 11 || i == 12 || i == 14 || i == 15) {
                box.scaling = new BABYLON.Vector3(10, length - 5, 10);
            }

            this.bundles[i].mesh = box;
        }

        this.boxesForOimoCreated = true;
    };

    Character.prototype.createBundles = function () {
        for (var i = 0; i < this.nBundle; i++) {
            var boneName = this.skeleton.bones[i].name;
            var type = Constant.IS_REAL;

            var id;

            switch (boneName) {
                case "head":
                    id = 0;
                    break;
                case "torsoUp":
                    id = 1;
                    break;
                case "torsoDown":
                    id = 2;
                    break;
                case "pelvis":
                    id = 3;
                    break;
                case "pelvisDummy":
                    id = 4;
                    type = Constant.IS_DUMMY;
                    break;
                case "thighLeft":
                    id = 5;
                    break;
                case "calfLeft":
                    id = 6;
                    break;
                case "footLeft":
                    id = 7;
                    type = Constant.IS_DUMMY;
                    break;
                case "thighRight":
                    id = 8;
                    break;
                case "calfRight":
                    id = 9;
                    break;
                case "footRight":
                    id = 10;
                    type = Constant.IS_DUMMY;
                    break;
                case "armRight0":
                    id = 11;
                    break;
                case "armRight1":
                    id = 12;
                    break;
                case "handRight":
                    id = 13;
                    type = Constant.IS_DUMMY;
                    break;
                case "armLeft0":
                    id = 14;
                    break;
                case "armLeft1":
                    id = 15;
                    break;
                case "handLeft":
                    id = 16;
                    type = Constant.IS_DUMMY;
                    break;
            }

            var temp = new Bundle(id, type, this.skeleton.bones[i]);
            this.bundles[id] = temp;
        }
    };

    Character.prototype.startKeyframeAnimation = function (startframe, endframe) {
        this.scene.beginAnimation(this.skeleton, startframe, endframe, true, 1);
    };

    Character.prototype.stopKeyFrameAnimation = function () {
        this.scene.stopAnimation(this.skeleton);
    };

    Character.prototype.pauseKeyFrameAnimation = function () {
        var s = this.skeleton.getAnimatables();
        var t = +s[0].animations[0].currentFrame.toFixed();
        this.scene.beginAnimation(this.skeleton, t, t + 0.000001, true, 1);
    };
    Character.instanceCounter = 0;
    return Character;
})();
