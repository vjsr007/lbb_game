﻿var BABYLON;
(function (BABYLON) {
    var _DepthCullingState = (function () {
        function _DepthCullingState() {
            this._isDepthTestDirty = false;
            this._isDepthMaskDirty = false;
            this._isDepthFuncDirty = false;
            this._isCullFaceDirty = false;
            this._isCullDirty = false;
        }
        Object.defineProperty(_DepthCullingState.prototype, "isDirty", {
            get: function () {
                return this._isDepthFuncDirty || this._isDepthTestDirty || this._isDepthMaskDirty || this._isCullFaceDirty || this._isCullDirty;
            },
            enumerable: true,
            configurable: true
        });

        Object.defineProperty(_DepthCullingState.prototype, "cullFace", {
            get: function () {
                return this._cullFace;
            },
            set: function (value) {
                if (this._cullFace === value) {
                    return;
                }

                this._cullFace = value;
                this._isCullFaceDirty = true;
            },
            enumerable: true,
            configurable: true
        });


        Object.defineProperty(_DepthCullingState.prototype, "cull", {
            get: function () {
                return this._cull;
            },
            set: function (value) {
                if (this._cull === value) {
                    return;
                }

                this._cull = value;
                this._isCullDirty = true;
            },
            enumerable: true,
            configurable: true
        });


        Object.defineProperty(_DepthCullingState.prototype, "depthFunc", {
            get: function () {
                return this._depthFunc;
            },
            set: function (value) {
                if (this._depthFunc === value) {
                    return;
                }

                this._depthFunc = value;
                this._isDepthFuncDirty = true;
            },
            enumerable: true,
            configurable: true
        });


        Object.defineProperty(_DepthCullingState.prototype, "depthMask", {
            get: function () {
                return this._depthMask;
            },
            set: function (value) {
                if (this._depthMask === value) {
                    return;
                }

                this._depthMask = value;
                this._isDepthMaskDirty = true;
            },
            enumerable: true,
            configurable: true
        });


        Object.defineProperty(_DepthCullingState.prototype, "depthTest", {
            get: function () {
                return this._depthTest;
            },
            set: function (value) {
                if (this._depthTest === value) {
                    return;
                }

                this._depthTest = value;
                this._isDepthTestDirty = true;
            },
            enumerable: true,
            configurable: true
        });


        _DepthCullingState.prototype.reset = function () {
            this._depthMask = true;
            this._depthTest = true;
            this._depthFunc = null;
            this._cull = null;
            this._cullFace = null;

            this._isDepthTestDirty = true;
            this._isDepthMaskDirty = true;
            this._isDepthFuncDirty = false;
            this._isCullFaceDirty = false;
            this._isCullDirty = false;
        };

        _DepthCullingState.prototype.apply = function (gl) {
            if (!this.isDirty) {
                return;
            }

            if (this._isCullDirty) {
                if (this.cull === true) {
                    gl.enable(gl.CULL_FACE);
                } else if (this.cull === false) {
                    gl.disable(gl.CULL_FACE);
                }

                this._isCullDirty = false;
            }

            if (this._isCullFaceDirty) {
                gl.cullFace(this.cullFace);
                this._isCullFaceDirty = false;
            }

            if (this._isDepthMaskDirty) {
                gl.depthMask(this.depthMask);
                this._isDepthMaskDirty = false;
            }

            if (this._isDepthTestDirty) {
                if (this.depthTest === true) {
                    gl.enable(gl.DEPTH_TEST);
                } else if (this.depthTest === false) {
                    gl.disable(gl.DEPTH_TEST);
                }
                this._isDepthTestDirty = false;
            }

            if (this._isDepthFuncDirty) {
                gl.depthFunc(this.depthFunc);
                this._isDepthFuncDirty = false;
            }
        };
        return _DepthCullingState;
    })();
    BABYLON._DepthCullingState = _DepthCullingState;

    var _AlphaState = (function () {
        function _AlphaState() {
            this._isAlphaBlendDirty = false;
            this._isBlendFunctionParametersDirty = false;
            this._alphaBlend = false;
            this._blendFunctionParameters = new Array(4);
        }
        Object.defineProperty(_AlphaState.prototype, "isDirty", {
            get: function () {
                return this._isAlphaBlendDirty || this._isBlendFunctionParametersDirty;
            },
            enumerable: true,
            configurable: true
        });

        Object.defineProperty(_AlphaState.prototype, "alphaBlend", {
            get: function () {
                return this._alphaBlend;
            },
            set: function (value) {
                if (this._alphaBlend === value) {
                    return;
                }

                this._alphaBlend = value;
                this._isAlphaBlendDirty = true;
            },
            enumerable: true,
            configurable: true
        });


        _AlphaState.prototype.setAlphaBlendFunctionParameters = function (value0, value1, value2, value3) {
            if (this._blendFunctionParameters[0] === value0 && this._blendFunctionParameters[1] === value1 && this._blendFunctionParameters[2] === value2 && this._blendFunctionParameters[3] === value3) {
                return;
            }

            this._blendFunctionParameters[0] = value0;
            this._blendFunctionParameters[1] = value1;
            this._blendFunctionParameters[2] = value2;
            this._blendFunctionParameters[3] = value3;

            this._isBlendFunctionParametersDirty = true;
        };

        _AlphaState.prototype.reset = function () {
            this._alphaBlend = false;
            this._blendFunctionParameters[0] = null;
            this._blendFunctionParameters[1] = null;
            this._blendFunctionParameters[2] = null;
            this._blendFunctionParameters[3] = null;

            this._isAlphaBlendDirty = true;
            this._isBlendFunctionParametersDirty = false;
        };

        _AlphaState.prototype.apply = function (gl) {
            if (!this.isDirty) {
                return;
            }

            if (this._isAlphaBlendDirty) {
                if (this._alphaBlend === true) {
                    gl.enable(gl.BLEND);
                } else if (this._alphaBlend === false) {
                    gl.disable(gl.BLEND);
                }

                this._isAlphaBlendDirty = false;
            }

            if (this._isBlendFunctionParametersDirty) {
                gl.blendFuncSeparate(this._blendFunctionParameters[0], this._blendFunctionParameters[1], this._blendFunctionParameters[2], this._blendFunctionParameters[3]);
                this._isBlendFunctionParametersDirty = false;
            }
        };
        return _AlphaState;
    })();
    BABYLON._AlphaState = _AlphaState;

    var compileShader = function (gl, source, type, defines) {
        var shader = gl.createShader(type === "vertex" ? gl.VERTEX_SHADER : gl.FRAGMENT_SHADER);

        gl.shaderSource(shader, (defines ? defines + "\n" : "") + source);
        gl.compileShader(shader);

        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
            throw new Error(gl.getShaderInfoLog(shader));
        }
        return shader;
    };

    var getSamplingParameters = function (samplingMode, generateMipMaps, gl) {
        var magFilter = gl.NEAREST;
        var minFilter = gl.NEAREST;
        if (samplingMode === BABYLON.Texture.BILINEAR_SAMPLINGMODE) {
            magFilter = gl.LINEAR;
            if (generateMipMaps) {
                minFilter = gl.LINEAR_MIPMAP_NEAREST;
            } else {
                minFilter = gl.LINEAR;
            }
        } else if (samplingMode === BABYLON.Texture.TRILINEAR_SAMPLINGMODE) {
            magFilter = gl.LINEAR;
            if (generateMipMaps) {
                minFilter = gl.LINEAR_MIPMAP_LINEAR;
            } else {
                minFilter = gl.LINEAR;
            }
        } else if (samplingMode === BABYLON.Texture.NEAREST_SAMPLINGMODE) {
            magFilter = gl.NEAREST;
            if (generateMipMaps) {
                minFilter = gl.NEAREST_MIPMAP_LINEAR;
            } else {
                minFilter = gl.NEAREST;
            }
        }

        return {
            min: minFilter,
            mag: magFilter
        };
    };

    var prepareWebGLTexture = function (texture, gl, scene, width, height, invertY, noMipmap, isCompressed, processFunction, samplingMode) {
        if (typeof samplingMode === "undefined") { samplingMode = BABYLON.Texture.TRILINEAR_SAMPLINGMODE; }
        var engine = scene.getEngine();
        var potWidth = BABYLON.Tools.GetExponantOfTwo(width, engine.getCaps().maxTextureSize);
        var potHeight = BABYLON.Tools.GetExponantOfTwo(height, engine.getCaps().maxTextureSize);

        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, invertY === undefined ? 1 : (invertY ? 1 : 0));

        processFunction(potWidth, potHeight);

        var filters = getSamplingParameters(samplingMode, !noMipmap, gl);

        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filters.mag);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filters.min);

        if (!noMipmap && !isCompressed) {
            gl.generateMipmap(gl.TEXTURE_2D);
        }

        gl.bindTexture(gl.TEXTURE_2D, null);

        engine._activeTexturesCache = [];
        texture._baseWidth = width;
        texture._baseHeight = height;
        texture._width = potWidth;
        texture._height = potHeight;
        texture.isReady = true;
        scene._removePendingData(texture);
    };

    var cascadeLoad = function (rootUrl, index, loadedImages, scene, onfinish, extensions) {
        var img;

        var onload = function () {
            loadedImages.push(img);

            scene._removePendingData(img);

            if (index != extensions.length - 1) {
                cascadeLoad(rootUrl, index + 1, loadedImages, scene, onfinish, extensions);
            } else {
                onfinish(loadedImages);
            }
        };

        var onerror = function () {
            scene._removePendingData(img);
        };

        img = BABYLON.Tools.LoadImage(rootUrl + extensions[index], onload, onerror, scene.database);
        scene._addPendingData(img);
    };

    var EngineCapabilities = (function () {
        function EngineCapabilities() {
        }
        return EngineCapabilities;
    })();
    BABYLON.EngineCapabilities = EngineCapabilities;

    var Engine = (function () {
        function Engine(canvas, antialias, options) {
            var _this = this;
            this.isFullscreen = false;
            this.isPointerLock = false;
            this.forceWireframe = false;
            this.cullBackFaces = true;
            this.renderEvenInBackground = true;
            this.scenes = new Array();
            this._windowIsBackground = false;
            this._runningLoop = false;
            this._loadingDivBackgroundColor = "black";
            this._depthCullingState = new _DepthCullingState();
            this._alphaState = new _AlphaState();
            this._loadedTexturesCache = new Array();
            this._activeTexturesCache = new Array();
            this._compiledEffects = {};
            this._renderingCanvas = canvas;
            this._canvasClientRect = this._renderingCanvas.getBoundingClientRect();

            options = options || {};
            options.antialias = antialias;

            try  {
                this._gl = canvas.getContext("webgl", options) || canvas.getContext("experimental-webgl", options);
            } catch (e) {
                throw new Error("WebGL not supported");
            }

            if (!this._gl) {
                throw new Error("WebGL not supported");
            }

            this._onBlur = function () {
                _this._windowIsBackground = true;
            };

            this._onFocus = function () {
                _this._windowIsBackground = false;
            };

            window.addEventListener("blur", this._onBlur);
            window.addEventListener("focus", this._onFocus);

            this._workingCanvas = document.createElement("canvas");
            this._workingContext = this._workingCanvas.getContext("2d");

            this._hardwareScalingLevel = 1.0 / (window.devicePixelRatio || 1.0);
            this.resize();

            this._caps = new EngineCapabilities();
            this._caps.maxTexturesImageUnits = this._gl.getParameter(this._gl.MAX_TEXTURE_IMAGE_UNITS);
            this._caps.maxTextureSize = this._gl.getParameter(this._gl.MAX_TEXTURE_SIZE);
            this._caps.maxCubemapTextureSize = this._gl.getParameter(this._gl.MAX_CUBE_MAP_TEXTURE_SIZE);
            this._caps.maxRenderTextureSize = this._gl.getParameter(this._gl.MAX_RENDERBUFFER_SIZE);

            this._caps.standardDerivatives = (this._gl.getExtension('OES_standard_derivatives') !== null);
            this._caps.s3tc = this._gl.getExtension('WEBGL_compressed_texture_s3tc');
            this._caps.textureFloat = (this._gl.getExtension('OES_texture_float') !== null);
            this._caps.textureAnisotropicFilterExtension = this._gl.getExtension('EXT_texture_filter_anisotropic') || this._gl.getExtension('WEBKIT_EXT_texture_filter_anisotropic') || this._gl.getExtension('MOZ_EXT_texture_filter_anisotropic');
            this._caps.maxAnisotropy = this._caps.textureAnisotropicFilterExtension ? this._gl.getParameter(this._caps.textureAnisotropicFilterExtension.MAX_TEXTURE_MAX_ANISOTROPY_EXT) : 0;
            this._caps.instancedArrays = this._gl.getExtension('ANGLE_instanced_arrays');

            this.setDepthBuffer(true);
            this.setDepthFunctionToLessOrEqual();
            this.setDepthWrite(true);

            this._onFullscreenChange = function () {
                if (document.fullscreen !== undefined) {
                    _this.isFullscreen = document.fullscreen;
                } else if (document.mozFullScreen !== undefined) {
                    _this.isFullscreen = document.mozFullScreen;
                } else if (document.webkitIsFullScreen !== undefined) {
                    _this.isFullscreen = document.webkitIsFullScreen;
                } else if (document.msIsFullScreen !== undefined) {
                    _this.isFullscreen = document.msIsFullScreen;
                }

                if (_this.isFullscreen && _this._pointerLockRequested) {
                    canvas.requestPointerLock = canvas.requestPointerLock || canvas.msRequestPointerLock || canvas.mozRequestPointerLock || canvas.webkitRequestPointerLock;

                    if (canvas.requestPointerLock) {
                        canvas.requestPointerLock();
                    }
                }
            };

            document.addEventListener("fullscreenchange", this._onFullscreenChange, false);
            document.addEventListener("mozfullscreenchange", this._onFullscreenChange, false);
            document.addEventListener("webkitfullscreenchange", this._onFullscreenChange, false);
            document.addEventListener("msfullscreenchange", this._onFullscreenChange, false);

            this._onPointerLockChange = function () {
                _this.isPointerLock = (document.mozPointerLockElement === canvas || document.webkitPointerLockElement === canvas || document.msPointerLockElement === canvas || document.pointerLockElement === canvas);
            };

            document.addEventListener("pointerlockchange", this._onPointerLockChange, false);
            document.addEventListener("mspointerlockchange", this._onPointerLockChange, false);
            document.addEventListener("mozpointerlockchange", this._onPointerLockChange, false);
            document.addEventListener("webkitpointerlockchange", this._onPointerLockChange, false);
        }
        Object.defineProperty(Engine, "ALPHA_DISABLE", {
            get: function () {
                return Engine._ALPHA_DISABLE;
            },
            enumerable: true,
            configurable: true
        });

        Object.defineProperty(Engine, "ALPHA_ADD", {
            get: function () {
                return Engine._ALPHA_ADD;
            },
            enumerable: true,
            configurable: true
        });

        Object.defineProperty(Engine, "ALPHA_COMBINE", {
            get: function () {
                return Engine._ALPHA_COMBINE;
            },
            enumerable: true,
            configurable: true
        });

        Object.defineProperty(Engine, "DELAYLOADSTATE_NONE", {
            get: function () {
                return Engine._DELAYLOADSTATE_NONE;
            },
            enumerable: true,
            configurable: true
        });

        Object.defineProperty(Engine, "DELAYLOADSTATE_LOADED", {
            get: function () {
                return Engine._DELAYLOADSTATE_LOADED;
            },
            enumerable: true,
            configurable: true
        });

        Object.defineProperty(Engine, "DELAYLOADSTATE_LOADING", {
            get: function () {
                return Engine._DELAYLOADSTATE_LOADING;
            },
            enumerable: true,
            configurable: true
        });

        Object.defineProperty(Engine, "DELAYLOADSTATE_NOTLOADED", {
            get: function () {
                return Engine._DELAYLOADSTATE_NOTLOADED;
            },
            enumerable: true,
            configurable: true
        });

        Object.defineProperty(Engine, "Version", {
            get: function () {
                return "1.14.0";
            },
            enumerable: true,
            configurable: true
        });

        Engine.prototype.getAspectRatio = function (camera) {
            var viewport = camera.viewport;
            return (this.getRenderWidth() * viewport.width) / (this.getRenderHeight() * viewport.height);
        };

        Engine.prototype.getRenderWidth = function () {
            if (this._currentRenderTarget) {
                return this._currentRenderTarget._width;
            }

            return this._renderingCanvas.width;
        };

        Engine.prototype.getRenderHeight = function () {
            if (this._currentRenderTarget) {
                return this._currentRenderTarget._height;
            }

            return this._renderingCanvas.height;
        };

        Engine.prototype.getRenderingCanvas = function () {
            return this._renderingCanvas;
        };

        Engine.prototype.getRenderingCanvasClientRect = function () {
            return this._renderingCanvas.getBoundingClientRect();
        };

        Engine.prototype.setHardwareScalingLevel = function (level) {
            this._hardwareScalingLevel = level;
            this.resize();
        };

        Engine.prototype.getHardwareScalingLevel = function () {
            return this._hardwareScalingLevel;
        };

        Engine.prototype.getLoadedTexturesCache = function () {
            return this._loadedTexturesCache;
        };

        Engine.prototype.getCaps = function () {
            return this._caps;
        };

        Engine.prototype.setDepthFunctionToGreater = function () {
            this._depthCullingState.depthFunc = this._gl.GREATER;
        };

        Engine.prototype.setDepthFunctionToGreaterOrEqual = function () {
            this._depthCullingState.depthFunc = this._gl.GEQUAL;
        };

        Engine.prototype.setDepthFunctionToLess = function () {
            this._depthCullingState.depthFunc = this._gl.LESS;
        };

        Engine.prototype.setDepthFunctionToLessOrEqual = function () {
            this._depthCullingState.depthFunc = this._gl.LEQUAL;
        };

        Engine.prototype.stopRenderLoop = function () {
            this._renderFunction = null;
            this._runningLoop = false;
        };

        Engine.prototype._renderLoop = function () {
            var _this = this;
            var shouldRender = true;
            if (!this.renderEvenInBackground && this._windowIsBackground) {
                shouldRender = false;
            }

            if (shouldRender) {
                this.beginFrame();

                if (this._renderFunction) {
                    this._renderFunction();
                }

                this.endFrame();
            }

            if (this._runningLoop) {
                BABYLON.Tools.QueueNewFrame(function () {
                    _this._renderLoop();
                });
            }
        };

        Engine.prototype.runRenderLoop = function (renderFunction) {
            var _this = this;
            this._runningLoop = true;

            this._renderFunction = renderFunction;

            BABYLON.Tools.QueueNewFrame(function () {
                _this._renderLoop();
            });
        };

        Engine.prototype.switchFullscreen = function (requestPointerLock) {
            if (this.isFullscreen) {
                BABYLON.Tools.ExitFullscreen();
            } else {
                this._pointerLockRequested = requestPointerLock;
                BABYLON.Tools.RequestFullscreen(this._renderingCanvas);
            }
        };

        Engine.prototype.clear = function (color, backBuffer, depthStencil) {
            this.applyStates();

            this._gl.clearColor(color.r, color.g, color.b, color.a !== undefined ? color.a : 1.0);
            if (this._depthCullingState.depthMask) {
                this._gl.clearDepth(1.0);
            }
            var mode = 0;

            if (backBuffer)
                mode |= this._gl.COLOR_BUFFER_BIT;

            if (depthStencil && this._depthCullingState.depthMask)
                mode |= this._gl.DEPTH_BUFFER_BIT;

            this._gl.clear(mode);
        };

        Engine.prototype.setViewport = function (viewport, requiredWidth, requiredHeight) {
            var width = requiredWidth || this._renderingCanvas.width;
            var height = requiredHeight || this._renderingCanvas.height;
            var x = viewport.x || 0;
            var y = viewport.y || 0;

            this._cachedViewport = viewport;

            this._gl.viewport(x * width, y * height, width * viewport.width, height * viewport.height);
        };

        Engine.prototype.setDirectViewport = function (x, y, width, height) {
            this._cachedViewport = null;

            this._gl.viewport(x, y, width, height);
        };

        Engine.prototype.beginFrame = function () {
            BABYLON.Tools._MeasureFps();
        };

        Engine.prototype.endFrame = function () {
            this.flushFramebuffer();
        };

        Engine.prototype.resize = function () {
            this._renderingCanvas.width = this._renderingCanvas.clientWidth / this._hardwareScalingLevel;
            this._renderingCanvas.height = this._renderingCanvas.clientHeight / this._hardwareScalingLevel;

            this._canvasClientRect = this._renderingCanvas.getBoundingClientRect();
        };

        Engine.prototype.bindFramebuffer = function (texture) {
            this._currentRenderTarget = texture;

            var gl = this._gl;
            gl.bindFramebuffer(gl.FRAMEBUFFER, texture._framebuffer);
            this._gl.viewport(0, 0, texture._width, texture._height);

            this.wipeCaches();
        };

        Engine.prototype.unBindFramebuffer = function (texture) {
            this._currentRenderTarget = null;
            if (texture.generateMipMaps) {
                var gl = this._gl;
                gl.bindTexture(gl.TEXTURE_2D, texture);
                gl.generateMipmap(gl.TEXTURE_2D);
                gl.bindTexture(gl.TEXTURE_2D, null);
            }

            this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, null);
        };

        Engine.prototype.flushFramebuffer = function () {
            this._gl.flush();
        };

        Engine.prototype.restoreDefaultFramebuffer = function () {
            this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, null);

            this.setViewport(this._cachedViewport);

            this.wipeCaches();
        };

        Engine.prototype._resetVertexBufferBinding = function () {
            this._gl.bindBuffer(this._gl.ARRAY_BUFFER, null);
            this._cachedVertexBuffers = null;
        };

        Engine.prototype.createVertexBuffer = function (vertices) {
            var vbo = this._gl.createBuffer();
            this._gl.bindBuffer(this._gl.ARRAY_BUFFER, vbo);
            this._gl.bufferData(this._gl.ARRAY_BUFFER, new Float32Array(vertices), this._gl.STATIC_DRAW);
            this._resetVertexBufferBinding();
            vbo.references = 1;
            return vbo;
        };

        Engine.prototype.createDynamicVertexBuffer = function (capacity) {
            var vbo = this._gl.createBuffer();
            this._gl.bindBuffer(this._gl.ARRAY_BUFFER, vbo);
            this._gl.bufferData(this._gl.ARRAY_BUFFER, capacity, this._gl.DYNAMIC_DRAW);
            this._resetVertexBufferBinding();
            vbo.references = 1;
            return vbo;
        };

        Engine.prototype.updateDynamicVertexBuffer = function (vertexBuffer, vertices, length) {
            this._gl.bindBuffer(this._gl.ARRAY_BUFFER, vertexBuffer);

            if (vertices instanceof Float32Array) {
                this._gl.bufferSubData(this._gl.ARRAY_BUFFER, 0, vertices);
            } else {
                this._gl.bufferSubData(this._gl.ARRAY_BUFFER, 0, new Float32Array(vertices));
            }

            this._resetVertexBufferBinding();
        };

        Engine.prototype._resetIndexBufferBinding = function () {
            this._gl.bindBuffer(this._gl.ELEMENT_ARRAY_BUFFER, null);
            this._cachedIndexBuffer = null;
        };

        Engine.prototype.createIndexBuffer = function (indices) {
            var vbo = this._gl.createBuffer();
            this._gl.bindBuffer(this._gl.ELEMENT_ARRAY_BUFFER, vbo);
            this._gl.bufferData(this._gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indices), this._gl.STATIC_DRAW);
            this._resetIndexBufferBinding();
            vbo.references = 1;
            return vbo;
        };

        Engine.prototype.bindBuffers = function (vertexBuffer, indexBuffer, vertexDeclaration, vertexStrideSize, effect) {
            if (this._cachedVertexBuffers !== vertexBuffer || this._cachedEffectForVertexBuffers !== effect) {
                this._cachedVertexBuffers = vertexBuffer;
                this._cachedEffectForVertexBuffers = effect;

                this._gl.bindBuffer(this._gl.ARRAY_BUFFER, vertexBuffer);

                var offset = 0;
                for (var index = 0; index < vertexDeclaration.length; index++) {
                    var order = effect.getAttributeLocation(index);

                    if (order >= 0) {
                        this._gl.vertexAttribPointer(order, vertexDeclaration[index], this._gl.FLOAT, false, vertexStrideSize, offset);
                    }
                    offset += vertexDeclaration[index] * 4;
                }
            }

            if (this._cachedIndexBuffer !== indexBuffer) {
                this._cachedIndexBuffer = indexBuffer;
                this._gl.bindBuffer(this._gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
            }
        };

        Engine.prototype.bindMultiBuffers = function (vertexBuffers, indexBuffer, effect) {
            if (this._cachedVertexBuffers !== vertexBuffers || this._cachedEffectForVertexBuffers !== effect) {
                this._cachedVertexBuffers = vertexBuffers;
                this._cachedEffectForVertexBuffers = effect;

                var attributes = effect.getAttributesNames();

                for (var index = 0; index < attributes.length; index++) {
                    var order = effect.getAttributeLocation(index);

                    if (order >= 0) {
                        var vertexBuffer = vertexBuffers[attributes[index]];
                        if (!vertexBuffer) {
                            continue;
                        }
                        var stride = vertexBuffer.getStrideSize();
                        this._gl.bindBuffer(this._gl.ARRAY_BUFFER, vertexBuffer.getBuffer());
                        this._gl.vertexAttribPointer(order, stride, this._gl.FLOAT, false, stride * 4, 0);
                    }
                }
            }

            if (this._cachedIndexBuffer !== indexBuffer) {
                this._cachedIndexBuffer = indexBuffer;
                this._gl.bindBuffer(this._gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
            }
        };

        Engine.prototype._releaseBuffer = function (buffer) {
            buffer.references--;

            if (buffer.references === 0) {
                this._gl.deleteBuffer(buffer);
                return true;
            }

            return false;
        };

        Engine.prototype.createInstancesBuffer = function (capacity) {
            var buffer = this._gl.createBuffer();

            buffer.capacity = capacity;

            this._gl.bindBuffer(this._gl.ARRAY_BUFFER, buffer);
            this._gl.bufferData(this._gl.ARRAY_BUFFER, capacity, this._gl.DYNAMIC_DRAW);
            return buffer;
        };

        Engine.prototype.deleteInstancesBuffer = function (buffer) {
            this._gl.deleteBuffer(buffer);
        };

        Engine.prototype.updateAndBindInstancesBuffer = function (instancesBuffer, data, offsetLocations) {
            this._gl.bindBuffer(this._gl.ARRAY_BUFFER, instancesBuffer);
            this._gl.bufferSubData(this._gl.ARRAY_BUFFER, 0, data);

            for (var index = 0; index < 4; index++) {
                var offsetLocation = offsetLocations[index];
                this._gl.enableVertexAttribArray(offsetLocation);
                this._gl.vertexAttribPointer(offsetLocation, 4, this._gl.FLOAT, false, 64, index * 16);
                this._caps.instancedArrays.vertexAttribDivisorANGLE(offsetLocation, 1);
            }
        };

        Engine.prototype.unBindInstancesBuffer = function (instancesBuffer, offsetLocations) {
            this._gl.bindBuffer(this._gl.ARRAY_BUFFER, instancesBuffer);
            for (var index = 0; index < 4; index++) {
                var offsetLocation = offsetLocations[index];
                this._gl.disableVertexAttribArray(offsetLocation);
                this._caps.instancedArrays.vertexAttribDivisorANGLE(offsetLocation, 0);
            }
        };

        Engine.prototype.applyStates = function () {
            this._depthCullingState.apply(this._gl);
            this._alphaState.apply(this._gl);
        };

        Engine.prototype.draw = function (useTriangles, indexStart, indexCount, instancesCount) {
            this.applyStates();

            if (instancesCount) {
                this._caps.instancedArrays.drawElementsInstancedANGLE(useTriangles ? this._gl.TRIANGLES : this._gl.LINES, indexCount, this._gl.UNSIGNED_SHORT, indexStart * 2, instancesCount);
                return;
            }

            this._gl.drawElements(useTriangles ? this._gl.TRIANGLES : this._gl.LINES, indexCount, this._gl.UNSIGNED_SHORT, indexStart * 2);
        };

        Engine.prototype._releaseEffect = function (effect) {
            if (this._compiledEffects[effect._key]) {
                delete this._compiledEffects[effect._key];
                if (effect.getProgram()) {
                    this._gl.deleteProgram(effect.getProgram());
                }
            }
        };

        Engine.prototype.createEffect = function (baseName, attributesNames, uniformsNames, samplers, defines, fallbacks, onCompiled, onError) {
            var vertex = baseName.vertexElement || baseName.vertex || baseName;
            var fragment = baseName.fragmentElement || baseName.fragment || baseName;

            var name = vertex + "+" + fragment + "@" + defines;
            if (this._compiledEffects[name]) {
                return this._compiledEffects[name];
            }

            var effect = new BABYLON.Effect(baseName, attributesNames, uniformsNames, samplers, this, defines, fallbacks, onCompiled, onError);
            effect._key = name;
            this._compiledEffects[name] = effect;

            return effect;
        };

        Engine.prototype.createEffectForParticles = function (fragmentName, uniformsNames, samplers, defines, fallbacks, onCompiled, onError) {
            if (typeof uniformsNames === "undefined") { uniformsNames = []; }
            if (typeof samplers === "undefined") { samplers = []; }
            if (typeof defines === "undefined") { defines = ""; }
            return this.createEffect({
                vertex: "particles",
                fragmentElement: fragmentName
            }, ["position", "color", "options"], ["view", "projection"].concat(uniformsNames), ["diffuseSampler"].concat(samplers), defines, fallbacks, onCompiled, onError);
        };

        Engine.prototype.createShaderProgram = function (vertexCode, fragmentCode, defines) {
            var vertexShader = compileShader(this._gl, vertexCode, "vertex", defines);
            var fragmentShader = compileShader(this._gl, fragmentCode, "fragment", defines);

            var shaderProgram = this._gl.createProgram();
            this._gl.attachShader(shaderProgram, vertexShader);
            this._gl.attachShader(shaderProgram, fragmentShader);

            this._gl.linkProgram(shaderProgram);
            var linked = this._gl.getProgramParameter(shaderProgram, this._gl.LINK_STATUS);

            if (!linked) {
                var error = this._gl.getProgramInfoLog(shaderProgram);
                if (error) {
                    throw new Error(error);
                }
            }

            this._gl.deleteShader(vertexShader);
            this._gl.deleteShader(fragmentShader);

            return shaderProgram;
        };

        Engine.prototype.getUniforms = function (shaderProgram, uniformsNames) {
            var results = [];

            for (var index = 0; index < uniformsNames.length; index++) {
                results.push(this._gl.getUniformLocation(shaderProgram, uniformsNames[index]));
            }

            return results;
        };

        Engine.prototype.getAttributes = function (shaderProgram, attributesNames) {
            var results = [];

            for (var index = 0; index < attributesNames.length; index++) {
                try  {
                    results.push(this._gl.getAttribLocation(shaderProgram, attributesNames[index]));
                } catch (e) {
                    results.push(-1);
                }
            }

            return results;
        };

        Engine.prototype.enableEffect = function (effect) {
            if (!effect || !effect.getAttributesCount() || this._currentEffect === effect) {
                return;
            }

            this._vertexAttribArrays = this._vertexAttribArrays || [];

            this._gl.useProgram(effect.getProgram());

            for (var i in this._vertexAttribArrays) {
                if (i > this._gl.VERTEX_ATTRIB_ARRAY_ENABLED || !this._vertexAttribArrays[i]) {
                    continue;
                }
                this._vertexAttribArrays[i] = false;
                this._gl.disableVertexAttribArray(i);
            }

            var attributesCount = effect.getAttributesCount();
            for (var index = 0; index < attributesCount; index++) {
                var order = effect.getAttributeLocation(index);

                if (order >= 0) {
                    this._vertexAttribArrays[order] = true;
                    this._gl.enableVertexAttribArray(order);
                }
            }

            this._currentEffect = effect;
        };

        Engine.prototype.setArray = function (uniform, array) {
            if (!uniform)
                return;

            this._gl.uniform1fv(uniform, array);
        };

        Engine.prototype.setMatrices = function (uniform, matrices) {
            if (!uniform)
                return;

            this._gl.uniformMatrix4fv(uniform, false, matrices);
        };

        Engine.prototype.setMatrix = function (uniform, matrix) {
            if (!uniform)
                return;

            this._gl.uniformMatrix4fv(uniform, false, matrix.toArray());
        };

        Engine.prototype.setFloat = function (uniform, value) {
            if (!uniform)
                return;

            this._gl.uniform1f(uniform, value);
        };

        Engine.prototype.setFloat2 = function (uniform, x, y) {
            if (!uniform)
                return;

            this._gl.uniform2f(uniform, x, y);
        };

        Engine.prototype.setFloat3 = function (uniform, x, y, z) {
            if (!uniform)
                return;

            this._gl.uniform3f(uniform, x, y, z);
        };

        Engine.prototype.setBool = function (uniform, bool) {
            if (!uniform)
                return;

            this._gl.uniform1i(uniform, bool);
        };

        Engine.prototype.setFloat4 = function (uniform, x, y, z, w) {
            if (!uniform)
                return;

            this._gl.uniform4f(uniform, x, y, z, w);
        };

        Engine.prototype.setColor3 = function (uniform, color3) {
            if (!uniform)
                return;

            this._gl.uniform3f(uniform, color3.r, color3.g, color3.b);
        };

        Engine.prototype.setColor4 = function (uniform, color3, alpha) {
            if (!uniform)
                return;

            this._gl.uniform4f(uniform, color3.r, color3.g, color3.b, alpha);
        };

        Engine.prototype.setState = function (culling, force) {
            if (this._depthCullingState.cull !== culling || force) {
                if (culling) {
                    this._depthCullingState.cullFace = this.cullBackFaces ? this._gl.BACK : this._gl.FRONT;
                    this._depthCullingState.cull = true;
                } else {
                    this._depthCullingState.cull = false;
                }
            }
        };

        Engine.prototype.setDepthBuffer = function (enable) {
            this._depthCullingState.depthTest = enable;
        };

        Engine.prototype.getDepthWrite = function () {
            return this._depthCullingState.depthMask;
        };

        Engine.prototype.setDepthWrite = function (enable) {
            this._depthCullingState.depthMask = enable;
        };

        Engine.prototype.setColorWrite = function (enable) {
            this._gl.colorMask(enable, enable, enable, enable);
        };

        Engine.prototype.setAlphaMode = function (mode) {
            switch (mode) {
                case BABYLON.Engine.ALPHA_DISABLE:
                    this.setDepthWrite(true);
                    this._alphaState.alphaBlend = false;
                    break;
                case BABYLON.Engine.ALPHA_COMBINE:
                    this.setDepthWrite(false);
                    this._alphaState.setAlphaBlendFunctionParameters(this._gl.SRC_ALPHA, this._gl.ONE_MINUS_SRC_ALPHA, this._gl.ONE, this._gl.ONE);
                    this._alphaState.alphaBlend = true;
                    break;
                case BABYLON.Engine.ALPHA_ADD:
                    this.setDepthWrite(false);
                    this._alphaState.setAlphaBlendFunctionParameters(this._gl.ONE, this._gl.ONE, this._gl.ZERO, this._gl.ONE);
                    this._alphaState.alphaBlend = true;
                    break;
            }
        };

        Engine.prototype.setAlphaTesting = function (enable) {
            this._alphaTest = enable;
        };

        Engine.prototype.getAlphaTesting = function () {
            return this._alphaTest;
        };

        Engine.prototype.wipeCaches = function () {
            this._activeTexturesCache = [];
            this._currentEffect = null;

            this._depthCullingState.reset();
            this._alphaState.reset();

            this._cachedVertexBuffers = null;
            this._cachedIndexBuffer = null;
            this._cachedEffectForVertexBuffers = null;
        };

        Engine.prototype.setSamplingMode = function (texture, samplingMode) {
            var gl = this._gl;

            gl.bindTexture(gl.TEXTURE_2D, texture);

            var magFilter = gl.NEAREST;
            var minFilter = gl.NEAREST;

            if (samplingMode === BABYLON.Texture.BILINEAR_SAMPLINGMODE) {
                magFilter = gl.LINEAR;
                minFilter = gl.LINEAR;
            } else if (samplingMode === BABYLON.Texture.TRILINEAR_SAMPLINGMODE) {
                magFilter = gl.LINEAR;
                minFilter = gl.LINEAR_MIPMAP_LINEAR;
            }

            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, magFilter);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, minFilter);

            gl.bindTexture(gl.TEXTURE_2D, null);
        };

        Engine.prototype.createTexture = function (url, noMipmap, invertY, scene, samplingMode, onLoad, onError, buffer) {
            var _this = this;
            if (typeof samplingMode === "undefined") { samplingMode = BABYLON.Texture.TRILINEAR_SAMPLINGMODE; }
            if (typeof onLoad === "undefined") { onLoad = null; }
            if (typeof onError === "undefined") { onError = null; }
            if (typeof buffer === "undefined") { buffer = null; }
            var texture = this._gl.createTexture();

            var extension;
            var fromData = false;
            if (url.substr(0, 5) === "data:") {
                fromData = true;
            }

            if (!fromData)
                extension = url.substr(url.length - 4, 4).toLowerCase();
            else {
                var oldUrl = url;
                fromData = oldUrl.split(':');
                url = oldUrl;
                extension = fromData[1].substr(fromData[1].length - 4, 4).toLowerCase();
            }

            var isDDS = this.getCaps().s3tc && (extension === ".dds");
            var isTGA = (extension === ".tga");

            scene._addPendingData(texture);
            texture.url = url;
            texture.noMipmap = noMipmap;
            texture.references = 1;
            this._loadedTexturesCache.push(texture);

            var onerror = function () {
                scene._removePendingData(texture);

                if (onError) {
                    onError();
                }
            };

            if (isTGA) {
                var callback = function (arrayBuffer) {
                    var data = new Uint8Array(arrayBuffer);

                    var header = BABYLON.Internals.TGATools.GetTGAHeader(data);

                    prepareWebGLTexture(texture, _this._gl, scene, header.width, header.height, invertY, noMipmap, false, function () {
                        BABYLON.Internals.TGATools.UploadContent(_this._gl, data);

                        if (onLoad) {
                            onLoad();
                        }
                    }, samplingMode);
                };

                if (!(fromData instanceof Array))
                    BABYLON.Tools.LoadFile(url, function (arrayBuffer) {
                        callback(arrayBuffer);
                    }, onerror, scene.database, true);
                else
                    callback(buffer);
            } else if (isDDS) {
                var callback = function (data) {
                    var info = BABYLON.Internals.DDSTools.GetDDSInfo(data);

                    var loadMipmap = (info.isRGB || info.isLuminance || info.mipmapCount > 1) && !noMipmap && ((info.width >> (info.mipmapCount - 1)) == 1);
                    prepareWebGLTexture(texture, _this._gl, scene, info.width, info.height, invertY, !loadMipmap, info.isFourCC, function () {
                        BABYLON.Internals.DDSTools.UploadDDSLevels(_this._gl, _this.getCaps().s3tc, data, info, loadMipmap, 1);

                        if (onLoad) {
                            onLoad();
                        }
                    }, samplingMode);
                };

                if (!(fromData instanceof Array))
                    BABYLON.Tools.LoadFile(url, function (data) {
                        callback(data);
                    }, onerror, scene.database, true);
                else
                    callback(buffer);
            } else {
                var onload = function (img) {
                    prepareWebGLTexture(texture, _this._gl, scene, img.width, img.height, invertY, noMipmap, false, function (potWidth, potHeight) {
                        var isPot = (img.width == potWidth && img.height == potHeight);
                        if (!isPot) {
                            _this._workingCanvas.width = potWidth;
                            _this._workingCanvas.height = potHeight;

                            _this._workingContext.drawImage(img, 0, 0, img.width, img.height, 0, 0, potWidth, potHeight);
                        }

                        _this._gl.texImage2D(_this._gl.TEXTURE_2D, 0, _this._gl.RGBA, _this._gl.RGBA, _this._gl.UNSIGNED_BYTE, isPot ? img : _this._workingCanvas);

                        if (onLoad) {
                            onLoad();
                        }
                    }, samplingMode);
                };

                if (!(fromData instanceof Array))
                    BABYLON.Tools.LoadImage(url, onload, onerror, scene.database);
                else
                    BABYLON.Tools.LoadImage(buffer, onload, onerror, scene.database);
            }

            return texture;
        };

        Engine.prototype.createDynamicTexture = function (width, height, generateMipMaps, samplingMode) {
            var texture = this._gl.createTexture();

            width = BABYLON.Tools.GetExponantOfTwo(width, this._caps.maxTextureSize);
            height = BABYLON.Tools.GetExponantOfTwo(height, this._caps.maxTextureSize);

            this._gl.bindTexture(this._gl.TEXTURE_2D, texture);

            var filters = getSamplingParameters(samplingMode, generateMipMaps, this._gl);

            this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MAG_FILTER, filters.mag);
            this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MIN_FILTER, filters.min);
            this._gl.bindTexture(this._gl.TEXTURE_2D, null);

            this._activeTexturesCache = [];
            texture._baseWidth = width;
            texture._baseHeight = height;
            texture._width = width;
            texture._height = height;
            texture.isReady = false;
            texture.generateMipMaps = generateMipMaps;
            texture.references = 1;

            this._loadedTexturesCache.push(texture);

            return texture;
        };

        Engine.prototype.updateDynamicTexture = function (texture, canvas, invertY) {
            this._gl.bindTexture(this._gl.TEXTURE_2D, texture);
            this._gl.pixelStorei(this._gl.UNPACK_FLIP_Y_WEBGL, invertY ? 1 : 0);
            this._gl.texImage2D(this._gl.TEXTURE_2D, 0, this._gl.RGBA, this._gl.RGBA, this._gl.UNSIGNED_BYTE, canvas);
            if (texture.generateMipMaps) {
                this._gl.generateMipmap(this._gl.TEXTURE_2D);
            }
            this._gl.bindTexture(this._gl.TEXTURE_2D, null);
            this._activeTexturesCache = [];
            texture.isReady = true;
        };

        Engine.prototype.updateVideoTexture = function (texture, video, invertY) {
            this._gl.bindTexture(this._gl.TEXTURE_2D, texture);
            this._gl.pixelStorei(this._gl.UNPACK_FLIP_Y_WEBGL, invertY ? 0 : 1);

            if (video.videoWidth !== texture._width || video.videoHeight !== texture._height) {
                if (!texture._workingCanvas) {
                    texture._workingCanvas = document.createElement("canvas");
                    texture._workingContext = texture._workingCanvas.getContext("2d");
                    texture._workingCanvas.width = texture._width;
                    texture._workingCanvas.height = texture._height;
                }

                texture._workingContext.drawImage(video, 0, 0, video.videoWidth, video.videoHeight, 0, 0, texture._width, texture._height);

                this._gl.texImage2D(this._gl.TEXTURE_2D, 0, this._gl.RGBA, this._gl.RGBA, this._gl.UNSIGNED_BYTE, texture._workingCanvas);
            } else {
                this._gl.texImage2D(this._gl.TEXTURE_2D, 0, this._gl.RGBA, this._gl.RGBA, this._gl.UNSIGNED_BYTE, video);
            }

            if (texture.generateMipMaps) {
                this._gl.generateMipmap(this._gl.TEXTURE_2D);
            }

            this._gl.bindTexture(this._gl.TEXTURE_2D, null);
            this._activeTexturesCache = [];
            texture.isReady = true;
        };

        Engine.prototype.createRenderTargetTexture = function (size, options) {
            var generateMipMaps = false;
            var generateDepthBuffer = true;
            var samplingMode = BABYLON.Texture.TRILINEAR_SAMPLINGMODE;
            if (options !== undefined) {
                generateMipMaps = options.generateMipMaps === undefined ? options : options.generateMipmaps;
                generateDepthBuffer = options.generateDepthBuffer === undefined ? true : options.generateDepthBuffer;
                if (options.samplingMode !== undefined) {
                    samplingMode = options.samplingMode;
                }
            }
            var gl = this._gl;

            var texture = gl.createTexture();
            gl.bindTexture(gl.TEXTURE_2D, texture);

            var width = size.width || size;
            var height = size.height || size;

            var filters = getSamplingParameters(samplingMode, generateMipMaps, gl);

            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filters.mag);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filters.min);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);

            var depthBuffer;

            if (generateDepthBuffer) {
                depthBuffer = gl.createRenderbuffer();
                gl.bindRenderbuffer(gl.RENDERBUFFER, depthBuffer);
                gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, width, height);
            }

            var framebuffer = gl.createFramebuffer();
            gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer);
            gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
            if (generateDepthBuffer) {
                gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, depthBuffer);
            }

            gl.bindTexture(gl.TEXTURE_2D, null);
            gl.bindRenderbuffer(gl.RENDERBUFFER, null);
            gl.bindFramebuffer(gl.FRAMEBUFFER, null);

            texture._framebuffer = framebuffer;
            if (generateDepthBuffer) {
                texture._depthBuffer = depthBuffer;
            }
            texture._width = width;
            texture._height = height;
            texture.isReady = true;
            texture.generateMipMaps = generateMipMaps;
            texture.references = 1;
            this._activeTexturesCache = [];

            this._loadedTexturesCache.push(texture);

            return texture;
        };

        Engine.prototype.createCubeTexture = function (rootUrl, scene, extensions, noMipmap) {
            var _this = this;
            var gl = this._gl;

            var texture = gl.createTexture();
            texture.isCube = true;
            texture.url = rootUrl;
            texture.references = 1;
            this._loadedTexturesCache.push(texture);

            var extension = rootUrl.substr(rootUrl.length - 4, 4).toLowerCase();
            var isDDS = this.getCaps().s3tc && (extension === ".dds");

            if (isDDS) {
                BABYLON.Tools.LoadFile(rootUrl, function (data) {
                    var info = BABYLON.Internals.DDSTools.GetDDSInfo(data);

                    var loadMipmap = (info.isRGB || info.isLuminance || info.mipmapCount > 1) && !noMipmap;

                    gl.bindTexture(gl.TEXTURE_CUBE_MAP, texture);
                    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 1);

                    BABYLON.Internals.DDSTools.UploadDDSLevels(_this._gl, _this.getCaps().s3tc, data, info, loadMipmap, 6);

                    if (!noMipmap && !info.isFourCC && info.mipmapCount == 1) {
                        gl.generateMipmap(gl.TEXTURE_CUBE_MAP);
                    }

                    gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
                    gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_MIN_FILTER, loadMipmap ? gl.LINEAR_MIPMAP_LINEAR : gl.LINEAR);
                    gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
                    gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

                    gl.bindTexture(gl.TEXTURE_CUBE_MAP, null);

                    _this._activeTexturesCache = [];

                    texture._width = info.width;
                    texture._height = info.height;
                    texture.isReady = true;
                }, null, null, true);
            } else {
                cascadeLoad(rootUrl, 0, [], scene, function (imgs) {
                    var width = BABYLON.Tools.GetExponantOfTwo(imgs[0].width, _this._caps.maxCubemapTextureSize);
                    var height = width;

                    _this._workingCanvas.width = width;
                    _this._workingCanvas.height = height;

                    var faces = [
                        gl.TEXTURE_CUBE_MAP_POSITIVE_X, gl.TEXTURE_CUBE_MAP_POSITIVE_Y, gl.TEXTURE_CUBE_MAP_POSITIVE_Z,
                        gl.TEXTURE_CUBE_MAP_NEGATIVE_X, gl.TEXTURE_CUBE_MAP_NEGATIVE_Y, gl.TEXTURE_CUBE_MAP_NEGATIVE_Z
                    ];

                    gl.bindTexture(gl.TEXTURE_CUBE_MAP, texture);
                    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 0);

                    for (var index = 0; index < faces.length; index++) {
                        _this._workingContext.drawImage(imgs[index], 0, 0, imgs[index].width, imgs[index].height, 0, 0, width, height);
                        gl.texImage2D(faces[index], 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, _this._workingCanvas);
                    }

                    if (!noMipmap) {
                        gl.generateMipmap(gl.TEXTURE_CUBE_MAP);
                    }

                    gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
                    gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_MIN_FILTER, noMipmap ? gl.LINEAR : gl.LINEAR_MIPMAP_LINEAR);
                    gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
                    gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

                    gl.bindTexture(gl.TEXTURE_CUBE_MAP, null);

                    _this._activeTexturesCache = [];

                    texture._width = width;
                    texture._height = height;
                    texture.isReady = true;
                }, extensions);
            }

            return texture;
        };

        Engine.prototype._releaseTexture = function (texture) {
            var gl = this._gl;

            if (texture._framebuffer) {
                gl.deleteFramebuffer(texture._framebuffer);
            }

            if (texture._depthBuffer) {
                gl.deleteRenderbuffer(texture._depthBuffer);
            }

            gl.deleteTexture(texture);

            for (var channel = 0; channel < this._caps.maxTexturesImageUnits; channel++) {
                this._gl.activeTexture(this._gl["TEXTURE" + channel]);
                this._gl.bindTexture(this._gl.TEXTURE_2D, null);
                this._gl.bindTexture(this._gl.TEXTURE_CUBE_MAP, null);
                this._activeTexturesCache[channel] = null;
            }

            var index = this._loadedTexturesCache.indexOf(texture);
            if (index !== -1) {
                this._loadedTexturesCache.splice(index, 1);
            }
        };

        Engine.prototype.bindSamplers = function (effect) {
            this._gl.useProgram(effect.getProgram());
            var samplers = effect.getSamplers();
            for (var index = 0; index < samplers.length; index++) {
                var uniform = effect.getUniform(samplers[index]);
                this._gl.uniform1i(uniform, index);
            }
            this._currentEffect = null;
        };

        Engine.prototype._bindTexture = function (channel, texture) {
            this._gl.activeTexture(this._gl["TEXTURE" + channel]);
            this._gl.bindTexture(this._gl.TEXTURE_2D, texture);

            this._activeTexturesCache[channel] = null;
        };

        Engine.prototype.setTextureFromPostProcess = function (channel, postProcess) {
            this._bindTexture(channel, postProcess._textures.data[postProcess._currentRenderTextureInd]);
        };

        Engine.prototype.setTexture = function (channel, texture) {
            if (channel < 0) {
                return;
            }

            if (!texture || !texture.isReady()) {
                if (this._activeTexturesCache[channel] != null) {
                    this._gl.activeTexture(this._gl["TEXTURE" + channel]);
                    this._gl.bindTexture(this._gl.TEXTURE_2D, null);
                    this._gl.bindTexture(this._gl.TEXTURE_CUBE_MAP, null);
                    this._activeTexturesCache[channel] = null;
                }
                return;
            }

            if (texture instanceof BABYLON.VideoTexture) {
                if (texture.update()) {
                    this._activeTexturesCache[channel] = null;
                }
            } else if (texture.delayLoadState == BABYLON.Engine.DELAYLOADSTATE_NOTLOADED) {
                texture.delayLoad();
                return;
            }

            if (this._activeTexturesCache[channel] == texture) {
                return;
            }
            this._activeTexturesCache[channel] = texture;

            var internalTexture = texture.getInternalTexture();
            this._gl.activeTexture(this._gl["TEXTURE" + channel]);

            if (internalTexture.isCube) {
                this._gl.bindTexture(this._gl.TEXTURE_CUBE_MAP, internalTexture);

                if (internalTexture._cachedCoordinatesMode !== texture.coordinatesMode) {
                    internalTexture._cachedCoordinatesMode = texture.coordinatesMode;

                    var textureWrapMode = (texture.coordinatesMode !== BABYLON.Texture.CUBIC_MODE && texture.coordinatesMode !== BABYLON.Texture.SKYBOX_MODE) ? this._gl.REPEAT : this._gl.CLAMP_TO_EDGE;
                    this._gl.texParameteri(this._gl.TEXTURE_CUBE_MAP, this._gl.TEXTURE_WRAP_S, textureWrapMode);
                    this._gl.texParameteri(this._gl.TEXTURE_CUBE_MAP, this._gl.TEXTURE_WRAP_T, textureWrapMode);
                }

                this._setAnisotropicLevel(this._gl.TEXTURE_CUBE_MAP, texture);
            } else {
                this._gl.bindTexture(this._gl.TEXTURE_2D, internalTexture);

                if (internalTexture._cachedWrapU !== texture.wrapU) {
                    internalTexture._cachedWrapU = texture.wrapU;

                    switch (texture.wrapU) {
                        case BABYLON.Texture.WRAP_ADDRESSMODE:
                            this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_S, this._gl.REPEAT);
                            break;
                        case BABYLON.Texture.CLAMP_ADDRESSMODE:
                            this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_S, this._gl.CLAMP_TO_EDGE);
                            break;
                        case BABYLON.Texture.MIRROR_ADDRESSMODE:
                            this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_S, this._gl.MIRRORED_REPEAT);
                            break;
                    }
                }

                if (internalTexture._cachedWrapV !== texture.wrapV) {
                    internalTexture._cachedWrapV = texture.wrapV;
                    switch (texture.wrapV) {
                        case BABYLON.Texture.WRAP_ADDRESSMODE:
                            this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_T, this._gl.REPEAT);
                            break;
                        case BABYLON.Texture.CLAMP_ADDRESSMODE:
                            this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_T, this._gl.CLAMP_TO_EDGE);
                            break;
                        case BABYLON.Texture.MIRROR_ADDRESSMODE:
                            this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_T, this._gl.MIRRORED_REPEAT);
                            break;
                    }
                }

                this._setAnisotropicLevel(this._gl.TEXTURE_2D, texture);
            }
        };

        Engine.prototype._setAnisotropicLevel = function (key, texture) {
            var anisotropicFilterExtension = this._caps.textureAnisotropicFilterExtension;

            if (anisotropicFilterExtension && texture._cachedAnisotropicFilteringLevel !== texture.anisotropicFilteringLevel) {
                this._gl.texParameterf(key, anisotropicFilterExtension.TEXTURE_MAX_ANISOTROPY_EXT, Math.min(texture.anisotropicFilteringLevel, this._caps.maxAnisotropy));
                texture._cachedAnisotropicFilteringLevel = texture.anisotropicFilteringLevel;
            }
        };

        Engine.prototype.readPixels = function (x, y, width, height) {
            var data = new Uint8Array(height * width * 4);
            this._gl.readPixels(0, 0, width, height, this._gl.RGBA, this._gl.UNSIGNED_BYTE, data);
            return data;
        };

        Engine.prototype.dispose = function () {
            this.hideLoadingUI();

            this.stopRenderLoop();

            while (this.scenes.length) {
                this.scenes[0].dispose();
            }

            for (var name in this._compiledEffects) {
                this._gl.deleteProgram(this._compiledEffects[name]._program);
            }

            for (var i in this._vertexAttribArrays) {
                if (i > this._gl.VERTEX_ATTRIB_ARRAY_ENABLED || !this._vertexAttribArrays[i]) {
                    continue;
                }
                this._gl.disableVertexAttribArray(i);
            }

            window.removeEventListener("blur", this._onBlur);
            window.removeEventListener("focus", this._onFocus);
            document.removeEventListener("fullscreenchange", this._onFullscreenChange);
            document.removeEventListener("mozfullscreenchange", this._onFullscreenChange);
            document.removeEventListener("webkitfullscreenchange", this._onFullscreenChange);
            document.removeEventListener("msfullscreenchange", this._onFullscreenChange);
            document.removeEventListener("pointerlockchange", this._onPointerLockChange);
            document.removeEventListener("mspointerlockchange", this._onPointerLockChange);
            document.removeEventListener("mozpointerlockchange", this._onPointerLockChange);
            document.removeEventListener("webkitpointerlockchange", this._onPointerLockChange);
        };

        Engine.prototype.displayLoadingUI = function () {
            var _this = this;
            this._loadingDiv = document.createElement("div");

            this._loadingDiv.style.opacity = "0";
            this._loadingDiv.style.transition = "opacity 1.5s ease";

            this._loadingTextDiv = document.createElement("div");
            this._loadingTextDiv.style.position = "absolute";
            this._loadingTextDiv.style.left = "0";
            this._loadingTextDiv.style.top = "50%";
            this._loadingTextDiv.style.marginTop = "80px";
            this._loadingTextDiv.style.width = "100%";
            this._loadingTextDiv.style.height = "20px";
            this._loadingTextDiv.style.fontFamily = "Arial";
            this._loadingTextDiv.style.fontSize = "14px";
            this._loadingTextDiv.style.color = "white";
            this._loadingTextDiv.style.textAlign = "center";
            this._loadingTextDiv.innerHTML = "Loading";

            var imgFront = new Image();
            imgFront.src = "data:image/png;base64,/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAAAeAAD/7gAOQWRvYmUAZMAAAAAB/9sAhAAQCwsLDAsQDAwQFw8NDxcbFBAQFBsfFxcXFxcfHhcaGhoaFx4eIyUnJSMeLy8zMy8vQEBAQEBAQEBAQEBAQEBAAREPDxETERUSEhUUERQRFBoUFhYUGiYaGhwaGiYwIx4eHh4jMCsuJycnLis1NTAwNTVAQD9AQEBAQEBAQEBAQED/wAARCAQ4B4ADASIAAhEBAxEB/8QAowABAAMBAQEBAAAAAAAAAAAAAAUGBwQDAgEBAQEBAQEAAAAAAAAAAAAAAAACAQMEEAEAAgIBAgIEBwoJCwQDAQAAAQIDBBESBSEGMUEiE1FhcYGxMhSRoUJScrJzFTYHYpKiIzNjszQ1weGCwkNTg5PTdBbDlEUX8NHSJREBAQEAAQMEAwACAgMAAAAAAAERAiExEkFRcTJhIgOBE5GhsUJi/9oADAMBAAIRAxEAPwCpAPQ4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmOx+WO4d5n3mOIw6sTxbYvHh8lK/hf/AJ4rbh8k+XtLHF969s3418uT3VOfi6Jr9LLykVONrOhpEdp8jZJ93WdWbT6q7Hj97Jy4++eTuzYu27G9pzfFbDjtkrWL9dLcRzx7XM/fZ5z8nhfwoYLxreU+0ZPL1e4Wrk+0TqzmmeueOvo6vR8rbZO7JNUcBrAF41vKfaMnl6vcLVyfaJ1ZzTPXPHX0dXo+VlsndsmqOA1gAAAALP5P7B27vGPatuxeZw2pFOm3T9aLc/QsM+SvLdZ4t1xMemJypvOS4qcbZrNxo8+RvL2WsxjnLE/jUyRMx92JhBd78jbOlivs6GSdnDSOb47RxlrEemY48LE5yl41VQFJAWvyj5X1O66mbb34vOPrimGK26fqxzefvwWyTa2TeiqCw+b/AC/g7PnwX1It9mz1mPanqmMlZ8fH44mFeJdmlmdAAYCT7N5f7h3nJMa1ejDWeMme/hSvxfHPxQuOt5F7HqY/eb+S2eY+va9vdY/uVmJj+My8pFTjazsaR+qvIsz7vq1er0cfaPa/tOXlv+Suw5NTJsak3wzSlr0nHfrpPTEz49fV9LPOe1PC/hngnfKfatDum7mw78zGOmLrrxbo9rqrHp+dav8Awvyz8Nv+a285LhONrOBpNfI/l28c0jJaPiycvyfJXlqJ4mbxMemJys/2T8t8KzcaLl8m+Wq472rNuYrMx/O+uIZ9rY65dnDjt9W961t8kzENnKXsmyx5jSbeR/L1Y5tXJWPhnJw+f/C/LPw2/wCaz/ZPyrwrOBo//hfln4bf81Re9auDT7rs62t/Q4r9NOZ6vDj4WzlL2ZeNjiFl8ndi7f3j7Z9ti0+4910dNun6/vOef4qx28leW6zxbriY9MTl4ll5yXCcbZrNxo//AIP5dyxMY5yRPw0yRMx92JQnefImxqYrbHbsk7OOkc2w2jjLER+Lx4W+8TnxpeNVMBSQAASvYvLu73vLPueMWvSeMme0ezE/BEfhT8S4Y/JvlrQxxffvOT4b58vuq8/F0zX6WXlIqcbWdDSadm8kZ593j+zXtPqpsTz/ACcnKD83+We3dp08e5pddZvljFbHa3VXia3tzHPj+D8LJzludS8bmqkLH5Q7L2zuv2v9YTMe5917vi/R9fr6vzYWT/wvyz8Nv+aXnJcJxtms4Gk18j+XrRzWuS0fDGTl8/8AhflqPCZt/wA0/wBk/LfCs4F+7l5S8va/btvYwzb3uHDkyY/53n2q1m1fD5VR7BpYN/u+tqbETOHLaYvFZ4nwra3p+Zs5Sy32TeNlxHiz+cOwdu7Pj1baUXic1rxfqt1fVivH0qw2XZpZlwBK+We363c+74tTaiZw3reZis9M+zWbR4luTSIoWPzh2TQ7Pk1a6UWiM1bzfqt1fVmvH0q4S7NLMuA0enkjy/OGuS9ckc1iZmckxHjB/wCF+Wfht/zU/wCyflvhWcDRcvkDsmWvOHJmxzP1Zi9bV+/X/KhO5eQe4a1ZyaOWu3SPH3cx0ZPmjmYn7pOfGl41VR+3pfHe2PJWaXrPFq2jiYmPVMS7ux4+35u54cHcYmdbNPu5tW3TNbW+rPPyqY4Bb/NflPU7boV3e3xfpx24z1tbq9m3hW3zT4fOqBLLNhZgCz+UfLOHu1c21vRb7NT+bxRWembX9Np5+CILZJtJN6KwJPzFg7bq9zyavbYt7rB7F7Wt1dWSPrcfJ6EYQABgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmPLHY57z3DoycxqYeL7Fo9cfg0j47fRyh2l+R9Out2KmeY4vtWtktP8GJ6K/erz87OdyK4za/PMnmLD2HWx6elSv2q1eMWOI9jFSPCLTWPvQzvb3dvdyzm281s2Sfwrzzx8ker5nt3ffv3HuWxuXnmMt56PipHhSPmq4zjxyfk5XR74N7c18WTDhzXpizVmmTHE+xaLeE819DwGpGo6X7H0/7Gf7OWXNR0v2Pp/wBjP9nKP6enyvh6/DLgFoGo6X7H0/7Gf7OWXNR0v2Pp/wBjP9nKP6enyvh6/DLh9Y8eTLeuPFWb5LzFa0rHMzM+iIiHtudu3tC1a7mC+CbxzTrjjn5JWhzp/t3kvuncdLFu4MuCuLNEzWL2vFvCZr48Y5j1IB1Ye690wY64sG5nxYq/VpTLetY9fhEW4Lvo2Z6pvL5A75SvVW+DLP4tL2if5dKwrmXFkw5L4stZpkxzNb1nwmJjwmEn2/zJ3XV3cGxm2s+fFjvE3xZMlr1tWfC3haZjnifBN+e+2Yp9x3rW4mmxxTLMeiZmOrHf56+H3E7Zcvq3JZs9HT+7n+g3/wArH9F1d82/tFu/lV/MqsX7uf6Df/Kx/RdXfNv7Rbv5VfzKsn3vw2/WIrFly4bxkxXtjyV8a3rM1tHyTDSfJne9juujkx7VuvY1bRW2T12peJ6Zn4/CWaNC8g9uzavb8+3mrNPtdqzjifCZx44ni3z9Ut/pmHDdVLzPpY9Hvm3gxR045tGSkR6IjJEX4j5JlFJTzNu49/vm1sYp6sXVFKTHomMcRTmPl45Rap2ib3r9pS171pSJte0xFax6ZmfCIaXv3r5b8qxixzEZqY4xUmPXmyfWtH3ZsqXkrt323vWPLeOcWpHvrflR4Uj+N4/MkP3hdx95t4O3Un2cFfe5Yj8e/hWJ+Sv0o5deUn+VTpLU937Bj775ZnYwRzb3ddrDHpmLVjm1fl4mY+VmTQfIHcPf9uy6F55vq26qR/V5PH71uVP8wdu/Vnd9jViOMcW68P6O/tV+56Dh0t4nLrJUckew9oyd47jTVrzXFHt57x+Djj0/PPohHNB/d9pVx9tz7kx/ObGToif4GOP/AOplXK5NZxm13d67vp+We3YtfVx197MdOtg9URHpvfj1fTLOd/uW93HNObczWy2meYiZ9mv5NfRHzO3zRv33+97OSZ5pitOHFHqiuOenw+WeZRLOPHJvqcrt/A99Xe3NObTq5r4uuJi8VnwtExxxaPRLwFJAAaB+7v8AwzZ/T/6lVQ8w/wCO7/6fJ9K3/u7/AMM2f0/+pVUPMP8Aju/+nyfSjj9+S79Yjnto/wB91/0tPzoeL20f77r/AKWn50LQ0Tz3/gF/0uP6WatK89/4Bf8AS4/pZqn+f1/yvn3AFIXb92//AMj/AMD/ANVCec/2l3P+F/ZY03+7f/5H/gf+qhPOf7S7n/C/ssaJ978Lv0nyhseTJivGTFaaXr41tWZiY+SYaN5K75sd01MuDbt7zPqzX+cn03pfnjn4Zjp9LN1//d/23Nr6mxvZqzWNqaxiifCZpTn2vkmbfebzzxZw3VY82aWPS79s48UdOPJMZaxHq645t/K5Q6X8172Pe77s5cUxbFSYxUtHonojpmY/0uUQqdoy96ADGqadcfZPLNcmKsTODWnNaPx8k1655+WzMdzc2t7Yts7WScuW88za0/ej4I+Jpfl7f1e9dirgvMWtXF9n2scz4/V6Of8ASjxUjvvlbuHaL2yRWc+lzzXPWOeI/rIj6v0I4dLd7r5dpnZCve29uX1I0r5rW1q2jJXFaeYrasTWJrz6PC0+h4C0AANK8if4BT9Lk+lne9/fdj9Lf86WieRP8Ap+lyfSzve/vux+lv8AnSjj9uS+XaPFL+Uv2i0vyrfmWRCX8pftFpflW/Msu9r8JneLF+8b+g0Pysn0UUZef3jf0Gh+Vk+iijJ4fWN59xPeSP2iwfk5PzLIFPeSP2iwfk5PzLN5dr8MneJX9439Pofk5Ppopi5/vG/p9D8nJ9NFMOH1jeXetR8zfsvs/osf51GXNR8zfsvs/osf51GXJ/n2vy3n3/w9MG1s61+vXy3w3j8LHaaz/JW7y752zxmpqd3tF8V5itNmY4tWZ9HXx6Y+P7qmirJe6ZbGheduwYtrUt3TXpxta8c5en/aYo9Mz8dfTz8HzM9an5X2v1j5f15z+3MVtgy8/hRSZp4/LXhmG1hnX2c2CfTivak/6MzVPC95fRXL0vu0zy/vYu/9h91s+3fpnX2o9czxx1f6UePys47loZe3b2bSzfXw2mOfxq+mtvnjxSvk7u/6u7tXHktxr7fGLJz6It+Bb5p8PnTn7wO09eHF3XFX2sXGLPx+JM+xafknw+cn68s9KXrx32UrV1su3s4tXDHVlzWilI+OZ4aV3HYw+V/LlcWDj3lKxiwfwstvGbz9+yD8gdn6r5O75o8Kc4teJ/Gn69/mjw+6jPOfd/1h3SdfHbnW0+cdOPRa/wDtLfdjj5i/tyz0ncnSb7q/MzaZtaeZnxmZ9MyAtAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1XtHs+V9fo9P2TmOPh6OfpZU0/yZs02vL+CnhNsE3w5I+SeY/k2hH9O0+V8O7MB1dz0r9v7hsad44nDeax8dfTWfnjxcq0AADWOy3xY/LmpfPx7murW2TmOY6IrzbmPHnwZO1HS/Y+n/Yz/Zyj+nafK+Hq5f195H/qP/a3/wCkfr7yP/Uf+1v/ANJnA3wnvWed9o0f9feR/wCo/wDa3/6SV2cutm7Fny6nH2a+rkti6a9MdE0njisxHDI2o6X7H0/7Gf7OU8uMmd+6uPLdZ12juE9s7lg3opGX3NpmaT4cxaJrPz8T4JXzR5nxd7x4cGDBOLHitN5teYm02mOOI49SvDpk3UbcwFj7B5v/AFLozp/ZPf8AOS2Tr950fWiI446LfA78/wC8P32HJi/V/T7ytq8++546o45/omby9v8AtuT3U1fcX/8Ao+QLRfxvgxW+b7Pfmv8AJqoS+9k/m/Im3a3hF8Wz0/PFqfSzn6fJx9fh5/u5/oN/8rH9F0tv+X/LW3uZdjc6ftGSYnJzmmvjERH1eqPUif3c/wBBv/lY/ourvm39ot38qv5lU5vO9cVucZ01e9byp5e15jPi1IzWjxr12nJE/JF7dP3Vb8y+b9zJ73tmtgvpVj2Ms5PDLMfixEeFYn50T5d8w7PZtqvNpvpXnjNh9McT+FWPVaPvrd5u7Li7t26O46cRfYw0662r/tcMx1THx8R4x/nMzlPLr7U3Z06M5B0du0r7+9g08f1s14rz8EfhW+aPF0c1/wDJOjTt/ZLbub2LbUzmvafVipzFOfm5t86g9z3b9w7hsbl/TmvNoifVX0Vr80eDVtvL2rS066u7kx4dW9Pc1pkt01tSI6en7iH9z5D+HT/jx/8Atz48utuXq6WdJN7Kj5S7j9g75gtaeMWf+YyfJf6v3LcLF+8Lt3Xg1+5Uj2sU+5yz/Bt40n5p5+67IxeRImJidOJj0T1x/wDtL7WPU732rPhw5aZcOxS1K5Kz1Vi0eifD8W0F5ftLlhJ0s1kLUfJcRHlvUmPTM5Zn5fe3Zhkx3xZL4skdN6TNbVn0xNZ4mGh+QNquXs99fn29fLaJj+Df2on7vKv6fVnDuz7Zm07GWbfW67c8/Dy80n5l0baHe9rDMcUvecuP4OjJPVHHyc8IxU7JoAMAAaB+7v8AwzZ/T/6lVQ8w/wCO7/6fJ9K3/u7/AMM2f0/+pVUPMP8Aju/+nyfSjj9+S79Yjnto/wB91/0tPzoeL20f77r/AKWn50LQ1vumz23V1Jy9z6fs0WiJ66Tkjqn0ezFbIX9feR/6j/2t/wDpPvz3/gF/0uP6WaufDjLN2unLllaP+vvI/wDUf+1v/wBJnALnHEW6u37t/wD5H/gf+qmu49g8ubm7k2d7p+036fec5pp6KxWPZ6o9UQhf3b//ACP/AAP/AFUJ5z/aXc/4X9ljRm871xe5xnTV21vKXl3DMZsWrGafTXrvbJWfmtbpn51f8y+b9yPe9s1Ne+lx7GS+T2cvT8FYr4ViY9fM/Eg+wd/2uzbVbVtN9W8/z+DnwmPxqx6rQunmns+Hvfa67+lEZNjFT3mG9f8Aa4pjqmn+WP8AOZnKeXU3Z06M2AdHMAB09v7judt2I2dPJOPJHhPri0fi2j1wvXaPPWhtxXD3Gv2TNPhN/ThtPy+mvz+Hxs8GXjL3bOVjSu7eTu090pOfT6dXPaOquTFxOK/Pw0jw+ePvqB3Pte52rZnW3KdF48a2jxrev41Z9cOvsPmPd7Nnr02nJqTP87rzPhx65p+Lb/8AJXnzXoa/c+w5NivE3wY/tODJ6+mI6rR8lqp28bJesqunKbOlZgAtDSvIn+AU/S5PpZ3vf33Y/S3/ADpaJ5E/wCn6XJ9LO97++7H6W/50o4/bkvl2jxS/lL9otL8q35lkQlfK14p5g0bT6JydPz2rNY+ld7X4TO8WT9439BoflZPoooy+/vFxWnT0834NMtqT8t68x+aoSeH1jefcT3kj9osH5OT8yyBWHyLjtfzBjtHox48lrfJx0fTZvLtfhnHvEl+8b+n0Pycn00UxcP3i5Inc08Xrrjtafktbj/VU84fWN5d61HzN+y+z+ix/nUZc1HzN+y+z+ix/nUZcn+fa/Leff/ABWs2mK1iZtM8REeMzMrQ0jyFEx2KZn0TmvMfJxWFD71aLd437R4xOzmmJ+Kclmk9ux17B5bp9o8J1sNsuWP4dubzX7s8MryXtkvbJeebXmbWn45nmUcOt5VfLtI/Gn9h3cXmDy/OHZnqydE6+z8PPHEX+ePH5WYLX+7zLkjuuzhi0+7vrze1fVNqXpFZ+bqlvOdN9mcb1+Vh71tYfLfl2uvrT05eiMGv6pm0x7eT6bfKzP0+MrX+8PJee7a+KbT7uuvFq19UWte8Wn5+mFUOE6b7nK9c9gBSQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYPJ/fq9q3pw7FuNPa4i9p9FLx9W/yeqf8yvhZsxsudWleaPLNO9Y67WpNa7tK8RM/Vy09MVmfolnm3obmjknFt4b4bx6rxxz8k+ifmS/Y/N/cO01rgvEbWpX0YrzxakfwL+PHyLRh899h2KdOzTJi5+tW9IvX+TM/QieXHpmxV8b13Gcu/D2LuubVy7n2e2PWw0nJbLkjoiYrHPs9X1vmXj/AMw8rYPbwxM2/q8PTP8AKiqH7356ru6mbS09aa489ZpbLln2um3hPFK+v52+XK/+rMnuqDUdL9j6f9jP9nLLlz1/OXbMXYa9ttizznjWnBNorTo6pp088+854+Y5y3M9zjc1TAFJGo6X7H0/7Gf7OWXLnr+cu2Yuw17bbFnnPGtOCbRWnR1TTp5595zx8yectzPdXG5qveXdKm/3rU1slevFa/VkrPomtIm8xPy8cJHztr9u097Dp6GCmGaY+vNNI9M3n2Yn5Ij77m8q900e09wvt7sXmPdzTHFIi09Vpjx8Zj1Q4u87/wCsu57O749OW89ET6YpHs05/wBGG9fL8SHTxcQDUkRMzERHMz4REL736Y7N5PwdtmeM+atMcx6+efe5Z+Tnw+dX/Kev237dG73LYxYcOtMWx48loib5PTHs/BX0/K8fM3e57z3CctOY1sUdGvWfxfXaY+Gyb1snt1VOkv5WL93P9Bv/AJWP6Lq75t/aLd/Kr+ZV2+U/Mej2THs028eW855pNfdRWeOmLc89V6/Cie+b2HuPddjdwRauLNMTWLxEW8KxXx4mY9RJfO0t/WRwr35D7373FbtGe3t4om+tM+un4VP9H0/J8iiPXU2s2ls4trXt05cNotSfk9U/FLeU2YyXKm/OPY/1Z3D3+GvGptTNqceil/wqf5Y/zJD93vbvebOfuV49nDHusU/w7+Np+av0vXuvm/sXdu2309nBsVvesTW0VpMUyxHhas+8j0T9589i83dl7T2vFp+52LZaxNstq1p02yWnmfGcno9XoT+3jmdVdPLdcXnzuH2nu9dWs849OnTMf1l/at97iFZemzsZNnYy7OWecma9r3n47TzLzXJkkTbt0Xb93ncfHZ7Zef6/DH3K3j6PvqS7Oz9wt2zuWvuxzNcVvbrHpmk+zePuSzlNlhLlS3njt32PvM7FI4xbke8j4OuPC8f5fncnljvf6n7jGXJzOrmj3exEeqPVePyZ/wAqT80eZu0d70aYsOLPTZxXi+O960ivE+FqzNclp8fk9Sqkm8crb0uxqHmHsOt5g08ebXvWNilerXzx41vW3j0zMfgz8PqZzv8Aa9/t2Sce5gvimJ4i0x7NvybR4S7+yeaO49m/m6TGfV55nBefCPh6Lfg/R8S16/n3suekRs48uC0/Wiaxkr92vjP3Ezy49M2N/Xl+Kzt36XYu671LZMOvaMNaza2a8dFOIjmfan0/MvH/AJd5Uxe3ijm0ejow8T92Yqje6fvAxZcOTBoatv5ys1nJmmI4iY4+pSZ/Ob5cr24/8sye6lAKS0D93f8Ahmz+n/1Kqh5h/wAd3/0+T6Uv5V8z6HZdPNg2sea98mTrrOKtZjjpivj1Xr8CB7rtY93uWzt4omMefJa9YtxFoi08+PEymS+Vqrf1jle2j/fdf9LT86Hi9NbJXFsYstuZrjvW0xHp4rPKktI881tbsN4rE2n3uPwjx9bNvcZ/93b+LLQf/sLsv+42f4mP/qn/ANhdl/3Gz/Ex/wDVc+PlJni6XLd1n3uM/wDu7fxZfNq2rPFoms/BPg0P/wCwuy/7jZ/iY/8Aqqh5l7rr927pbc1q3pjmla8ZIiLc1/JtZctt6zE2T0urD+7f/wCR/wCB/wCqhPOf7S7n/C/ssb38peYdLsf2v7XTLf7R7vo91FZ46OvnnqtX8ZHeYO44e5932N7XrauLL0dNbxEW9mlaTz0zaPTX4WSXzt/Bb+siOXjyF3vqrbs+xbxrzfVmfg9N6f5Y+dR3prbGbV2Mezgt0ZcVovS0eqYbymzGS5dT/nTsf6u3/tmCvGptzM+Hopl9Nq/P6Y/zK4u3cPOPY+6dtvp7mvsVvkpHM1rS0UyRHhaszkifCVJOO51byzegA1KX3/K/d9Olc1cM7GvesXrlxRNuItHPtVjxj6PjRExMTMTHEx6YXftn7wNfHgx4N7VvWcdYp7zDMWieI456bzXj7qRnzh5Wz8WzTM2+DJhm0/RZPlynfjq84+lULtvat3umxXBqY5vMzEXvx7FI+G1vU0bzFnw9r8tZsM2+thjVxRPptNq+7/N5lH7Pn/tODH06WDJmtH1YmIxU+74z95Tu8d73u87EZtq0RWnMYsVfClIn4Pj+NmXlZsyQ2SXLtqPAWhpXkT/AKfpcn0s73v77sfpb/nStHlrzd23tPa66eziz3yRe1ucdaTXi35V6qrs5K5djLlrzFcl7WiJ9PFp5Txl8uSrekeb01s99bYxbOP6+G9clflrPVDzFJatva2r5k7F04rxFdisZMN/xMkejn5J8JZlv9t3e3ZpwbmK2K8T4TMezb4629Ew7+w+Zt7stppSIzatp5vgtPEc/DW34Mrdh89dh2MfTs0yYufrVvSL1/k9XP3ETy49psX05euVnePHky3jHirN728K1rEzM/JENE8m+X8vatfJubsdGzniI6J9OPHHj7XxzPpJ86eWtaszr1taZ9MYsXRM/xuhXe++c9zueO2rrU+y6tvC/jzkvHwWn1R8UfdL5cumYTJ13XB5n7nXuneM2xjnnDTjFhn4aU9fzzzKKBcmTE1qXmWs28sbMViZmcWPiI/KozD3Gf/d2/iyv2P8AeB2amOlJw7PNYiJ9jH6o/Svv/wCwuy/7jZ/iY/8AqufHynou5fVSNXsvdty0V19TLfn8Lpmtfntbiv31z8ueTa9uyV3+52rfYx+1jxxPNMc/jWmfTMfch57H7xdSIn7Lp5Lz6pyWrSP5PWrfd/NPdu7VnFlyRh15/wBhi5rWfyp9Nvob+1/+WfrPykvOPmancLfq7StzqY7c5csejLePREfwY++qoLkyZE27dFo/d7/jWf8A7a/9piVdM+Vu86vZu4ZNrarkvjvhtiiMURNuqbUt+Favh7LOXanHvHf+8L/GsH/bU/tMqrpnzT3nV7z3DHtatclMdMNcUxliIt1Ra9vwbW8PaQxx7Q5d6ANYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA7tXT1fsV9/cnJ7qMkYaUxcRab8dc8zaJ4jj4nDPHM8ej1cpum7anl2tvdYZ6dmMXE46zExGL60x+N/CfObNh0+26GXHr4rbGal+q96Rbwi3Hzz8bNbiGErktj7Zp6s4sWPJs7NPe3y5KxfprM8VrSLcxHxvjdri2e2Yu41x1w5YyzgzRjjppaenrrbp9Xg3TEaJ7uGzh0u51w4dXD7uYx+9i2Os9fVEc8fi+Hwet+Zsuvp94jQw62KdaclaZIvSL2t7ziZ9q3jHHV4M0xBPfWw6uSLW2dj3ERxERFJyWtz8UTEffO4Yaa+9sYMf1MeS1a/JE+D81o1JvP2u2StOPD3UVtPPx9Uw0eu7ofZqYs2PLGfXzxM48kRNfGvhaLVn0TDpzdp08E1pn3648tq1v0TivP1o5j2q8wd1iJ09SdWert9OquKfHr95M8395z6/kfPf/AO+4/wBBi/NYOfd7dm04pkm1cuDL/R5sc9VLcer4pe1e2a+PFjyb23GtbNWL48cUnLbon0Wt0zHHL7wTM+X9qL/Urmxzi5/Hn63H+i+o2NDuWLDi3LTrbWKkYqbER1Y7Vr9Xrj0x8p1HNh0Mex3GulgzxkpefZzxWYifZ6vqz4/E8t7UvpbWTWvPVNJ8LR6LVnxiYSHa9TNp9/wYM0R1VtMxMeNbRNbcWifgl87vO72/HsxHObUv9nzcemaTPOK3+qb1M6PDt/asm9g2M8XjHj16zPMxz1TETbpj5oceLHfLkpipHN72itY+GZniFi1p+zTbttfTg1M2TPx682SImf4seDg8v62S+fLt0pOS2rjm2OsePOW0TFI/ym9zOzm7n22/bs9cU3jLW9equSscRPEzW0fNMPmNCb9vnexXi/u7dGbHxxNOfq2+OJSWfR3b9kt9qxWpl08k3pa3ptjyfXj5reLl7DbJ9tnHERbXyUtG1FvCvuuPatPyG9Pgzq58WjNtLLu5L+7x0mKY4mOZyXn8GPkcqU77zjyYNfF4aNMVZ1Zjxi8W8bXn45n0o7DlnDkrkitbzX8G9YtWflrLYV9bOtm1cvuc8dOSIi0xzE+Fo5j0PJO97vbZ7pTRimOvvJwxGSKR183iI+t6ePH0PDb38ent31dbWwzr4LTjtGSkXtkms8Wm1p8fT8DJTES6+36Ndyc3XmjBTBjnJe81m3hE8eiPF9d31sOvtx7iOnDmpTNSk+PTF454dHYoxTXfjNM1x/Zrdc1jmYjmPRDbemnq8c/bMca19rU2a7WLFMRliK2panVPET029TgTNaas9t2sXa8lr3mIybUZY6bzipPPsRHh4T6fF5aFN6Nat8GtgjHMzzsZ4p7XxROWfR8jNMcfb9am3u4da8zWuW3TMx6YeOakY8t8ceMUtNYn5J4TttfDg8x6nua1pXLFMk1p40ibRPPT8Xg547hijuE6/wBmxW1LZZpatqRN5ibcdXX9bq9Zv/gxECYvp4Ip3LQrWJzatvf4MnEdc46+F6zb0/VlzZMePX7Rjm1Kzsbd5tW0xE2rix+HhPpjqs3THn3TTppbc6+O02rFa25t6farFvU5Fg29XDs9+vGfmcOLBXLkrHhNopjieHLp7+Pb28ersauD7NntGOKUpFbU656Ymt49rmJlkvQxEiY1MGvra3dvfYq57al8dMc2j8KMlq+n08TMePHpfPXTf7TtZsuLHTPqWxzTJjpFOa5LdHTMV4jwbpiMwVw3zUrnvOPFMxF7xHVNY+Hh+ZYpXJeuO3Xji0xS0xxM158J4dHa6Uydy1qXrF6WyVi1bRzExz64lIaeHBOxv0xUxTu1vMamPLEdHEXnq6Yt7PPHoLTEKOruNtmc8V2sNcGWscTFaRj5j4ZivhPyvbt2PHsau7rzSs5ox++w3mI6o91PNqxPp8YNEe+8FcN81K57zjxTMRe8R1TWPh4Ssamv+ppx9Efbej7Z1cR1e76vd9PPp46faftMGCm32rUtjpNpimTPM1iZtOa3VFb/AA8VZpiNpqXz5c9dX+cx4K3yzefZ/m6fhcT9D00dOmzj2r3tNZ18NstePXMTHhKT7bm9zsd1xUx4+nHi2L15pEz7MxEU/I/g+h5dpz0yW7jmy469M61ptixxGOs8dPhEV9HJpiGEvr5qdw09zHmw4qWwYvfYb46RSa9M+NfD0xKIaD6w1x2y0rmtNMU2iL3iOZrXnxnhK7+anas0aOvhxWtirX32XJSMlr3tEWn63PFfH1P3Jra193tmzjxVpi3bUnJh45pFovFbxET+DPwM0xE5q465b1w2m+KLTFLzHE2rz4Tw+U3rYtWu93f3mGmTHgrmtTHMRxHTfwivwfM/NTYwbWhtZdnWxWvpxW+GaUinPVzWK36eOa8mmIUSt703u0Z8+TFjpn1clIrfHSKc1v4dMxXiH7tZKdqrg18GLHbNbHXJmzZKRkmbX8emvVzxEN0xEvXBTWvXLOfLOO1aTOKIr1dd/VWfgdncsWG+rqb+LHXDOxF65cdPCkXxzxzWPVy/O1YsWTDvzkpW801rWpNoiem3MeMc+iTehiPE3qY7z27FftmLFn2Ym32ut61vljx9nprf8Hj4EPmta+a9rUjHabTzSsdMVn4Ir6jR8CV0/s+LsuXZvgplzVzxXHN4ieOa+v4Y+I6qdx7Zs5cmLHj2NTotXJjrFOqt56ZraK+HgaY5d7TprY9W9LTadjDXLbn1TMz4Q5E3v7ca2t2+ceKls061eb5Kxfivj4Vrbw+V+5fsWLuOjsXw0jBuYa2zYumOis35rNqxPo49LNMQYldTSpq7m3fZrF8WhW0zW8RNb3n2MUTE/Dzy9tXHe3bsWTtuLFn2Ym07db1rfLHj7PTW/wCDx8DdMROCmteuWc+Wcdq0mcURXq67+qs/A8knoUpm/WV82GkXrgvaKdMRFLcx9WJ+rw/a+67d27X2IxUy7W3N5i2SsXrjpSen2az4cz8JpiLEr2/Lr7m5e2zTDXN7qYwVmsUxWzfgzeI8Hh3Sd6tqY93XphvHM1tSladUflU8LQaY4QBgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADr+2Yv1R9h4t737R77q8Onp6Ojj0888/Ebe5iz6engpFovrVvW8zxxM2t1Rx4uQMaka7els6mLX3uumTX5rizY4i3NJ8em9bTHo9Tz3NzDbWx6WpW0a+O05JtfjryZJ8OqYjwjiPCHEGGu3uW7i29/7Tji0U4pHFoiJ9iIifRM/A/dvew5+7zvUi0YveUv0zEdXFenn18er4XCGGvffz02d3PsUiYplva1Yt6eJn18cvrWr262KY2r5ceWLcxala3rNeI8OJms8uYB27m5gvr4tLUraNfFabzbJx13vbw5mK+EeDq2tvsu5embNG1F60rSa0jHFZ6I49MzKIDDXXu79c+Omtr4/camKea4+eqbWn03vb1y9a/qK1a2vOzjvER7ylYpaJtx49MzPh86PDDUpXu+Ke74d22Oa6+CIpTHXi1opWs1j08cz4vLtncqaW3kyZKTkwZYnrx+HjMT10nx+C0OAMhru0u4xi2dnY2Oq9tjFkpzXifbyfLMeD8ndx07ZTTwRauW2Scme/oieI4pWsxPocQYa7e278auz1bHVk18lLY81I8Zmto9XMv2d3Bh7fbU1Iv73PbnYy3iI5pH1aV4mfD4XCGGu6u9hydttpbMWtfFbr1MlYienn61LczHsy4QGJLf3tXYy497DOSm5X3fVSYjoiccemLc8+r4H7nz9o28s7WaM2LLf2s2LHFbVtb1zW02jjn44RgY3XRv7lt3ZtmmsUrxFcdI8YrSscVh7dr29bW+0U2ovOPYxTi5xxE2jmY/GmHCGegkp3e36uvmx9vpltl2KTjvlz9MdNJ+tFa0+F+32+3bWrrV2fe0y6tPd9OOKzW9YnmPGZjpn4fBGBhqWyd21r911d2uO9cOClK2p4c+zz9Xx+N+V2uz12p3ujN1xacldbivR188x7fPPTz8SKDDUh27Zz5e848/HXkz5JjJX1TXJ4Xj5OJefds9Mu7amH+gwRGHDH8DH4ffnmXnrb2bVx3rhrSL35/nprE5KxMcTFbepzmdRKZe8U/Wv27DSbYppXHfHfiOqvTFLR4TL8xZ+0amaNvBGbJkpPViw5IrFa29XVaLTM8fIjAw124t+sae/hy9Vs25OO0WiI45peb26vH43zrbmLD2/d1bRacmz7romOOmPd2m09Xi5Aw1J6H2S3c+3xqRk6omnvuvj68T7U149Tyv+r8m1tfab5KTOW04746xaOOqeeqJmHnr9xz62KaYa4638YjP0R72It6eLuUwdvct3Hs118OHrnHrU6K5MnHXfmefHjniPgh59u2o093FsWibUrPF6x6ZpaOm0ePxS5gz0ElXueGO6TsTS32OaTh914dXuej3cR6ePjfH6xpbvMdwvFvdRli8VjjqilfCsenj6sOAMNSOp3DXxb21ly1t9n265cdunjrrXLPPPHPD519vU1J3KY5yZMefDOLFaaxE9U8eNo6vCOXAGGuvQ3MWtj265ItM7GG2KnTx4WmY9PMx4OQBiTzbfbt/ozbnvcWzWsVyWxVreuSKxxE+1aOLcPi/csdt3UyVpNNXSmkY6eE36aWi1pn0R1WR4Y3UjTuOCufuWSa26d2uSuLwjmOu3VHV4vHU3MWDT3MF4tN9mtK0mOOImtuqefFyBhrrwbmLH23a1LRb3me2O1JjjpiKTzPPi977ehu4sX233mLYw0jH7zFWL1yUr9Xqi0xxZGhhru2N3WzX1teKXroa3hxzHvLRaeb2n1cy6NCcER3W2CLRr/Z7Rj6/Txa0dMTwiXVl7jnya/wBmrXHixW4nJGKsUm819HXPrMNemrbtmOMWa+TPjz455vWlazEzE+HRbqjh4b+19s3Muz09HvbcxX4I9DwDBMaVtaOw5o2a2nFbZrHNOOqs9HMWjnwlz5tvUw6V9LR67e/tW2fNkiKzMU8a1rWJnw5ckbWWNW2pEx7m14yTHHj1RHT6XkYa69/cxbOPUrji0Tr4a4r9XHjaJn0cTPgb+5i2cepXHFonXw1xX6uPG0TPo4mfByPTXze4yxk6KZOPwMleqv3DBK932udDVxzHTsbVKZtmfXaKV6Mcz8vpcmrbtmOMWa+TPjz455vWlazEzE+HRbqjhy7Gxl2s1s2aeq9vT6oiI8IiIj1Q8zOhqT/W2O+x3DPkpNZ3MdqUrXiemZ446vR8D4xbmpm0qaW9F6+4m04M2OItMRbxtW1bTHhyjww11xHavfWra2f3PT7OTpr1dfPpmnP1ePjem7u69tLDo683vjxWm/vcvETzPh01rEzxHzuAMAAYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//2Q==";
            imgFront.style.position = "absolute";
            imgFront.style.height = "100%";
            imgFront.style.width = "100%";

            imgFront.style.marginLeft = "0px";
            imgFront.style.marginTop = "0px";

            this._loadingDiv.appendChild(imgFront);

            var imgBack = new Image();
            imgBack.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAYdEVYdFNvZnR3YXJlAHBhaW50Lm5ldCA0LjAuM4zml1AAAARbSURBVHhe7Z09aFNRFMc716kuLrq4FdyLq4Wi4CAoRQcR0UJBUBdRiuLSIYMo6CA4FF2sgw6CFAdFUOpSQYcWO4hD26UQCfXrIQrx/JJzw1OSWq3NPeL/B4Fy+0jg/HO+7j3vpUcI8b/Q39+/49ihfWdPHT94Yf/e3Se3bd263f8lus218TPn6vV6Ya8Wi/MzNRNmj18iusX9W1evmP1/EKNEIVG6CMbG6E3bt+fT++pHha8NoHdT72bLE8NDg7tGU64gLLndV4Wc4m8j/pS+vr4tGB/DT16v3Fyr8dvBe/jbit8BL0AES9LX1iPAz+BR/hFiLVCynj95dPzNy6fv3IZ/k4L3948Sq7FzYGBg4vLFGxitabuOFCbWNKGrMnbiUuo18KaV6tIHv6YtvL9/nOgE31jCktmrY7k6+/zhE4yP4Vf7hiNqh/BWWEl8mzDol4p22Lf7cIdvdUMEvv0Y2S9fE5S1hLzpqTsPkiep//gFGPnR3Yl7GL5p/xYFBrTwM+iXio3GqpwDGL5p/xYNIX7XG8Q6IJRgdIzf1KBBgafII7oMidhyQtVFaMA2Bt7il4huQRhaXphbcR2g4RXqBzKAGHiCCwGFVUAj/m/RTRDj29cvn10I0PZ3LghH5f4CL1EFlQmqqXK3jDDKFxmhQ3Yt6oQseUZGKmMnTpsOqc8o1F9kBOMjQlOLeqEeIyOc6JV6jYLJD/+XyIFvnzdgl9aXRQ5I2qZDK1SpospMqaoqON/wZZGDciLnMMiXRS7IF4hhqMTNTdk7CFu+LHLhR7BQqBvPDJUUQqCGvCMATHUgBmhWNgApmdOda9YpM+VwRYfuyyIXDK8hBlilNerLIheMZCKGwlUAyru6GlwOgPUbRxADdJ9FAChxXY864viyyEXqPxhc0M2TAfAbatSdRyHtXymhByEdRnE3ky+JnHAIhSA0h74kckETmHoQbSgGwJrCIRMEPSRIBCRIMAhZaYhaggQhJXUJEoRU9mofKwh+F22dLRRfEjlJM7w6KQwCoQpBOKTyJZETjmwRxKqtGV8SOSkNOGjKPQppBEgDDkFgpxdBVGkFgaYQQXRIFQSObk0P5ZFIpAZRHXsQ0r0hCluBWKkuvVbYCkQaCdL5ehBScudJP4yY+rLISdps1NBDEJKXMMmoSfggWC4ZQRR17oFYXph7hSiquIKQ+hJGTX1J5MYSPD/GVdNzsgLBwZVCVyAQAkF0ohiI/c1fS6tNXq9UfEnkhudmIQolsS+J3Hh/UtNDzQLhj42VKJFInqLwFYiUU5ToA+HdfI0JevUpQUAIn+vSz2lHIuUV/dJOIHhOY/IWVWGBIHQtzs88s9zyWBuTgcBLzGOmeNnfF/QslSDgMeQW85i3DOQxuipxAkCyZ8SIm4Omp+7MMlCB59j6sKZcMoM4iIEoeI2J9AKxrFobZx0v4vYInuHFS4J1GQRCAGaLEYQXfyMML5XSQgghhBBCCCH+cXp6vgNhKpSKX/XdOAAAAABJRU5ErkJggg==";

            imgBack.style.position = "absolute";
            imgBack.style.left = "50%";
            imgBack.style.top = "70%";
            imgBack.style.marginLeft = "-50px";
            imgBack.style.marginTop = "-50px";
            imgBack.style.transition = "transform 1.0s ease";
            imgBack.style.webkitTransition = "-webkit-transform 1.0s ease";

            var deg = 360;

            var onTransitionEnd = function () {
                deg += 360;
                imgBack.style.transform = "rotateZ(" + deg + "deg)";
                imgBack.style.webkitTransform = "rotateZ(" + deg + "deg)";
            };

            imgBack.addEventListener("transitionend", onTransitionEnd);
            imgBack.addEventListener("webkitTransitionEnd", onTransitionEnd);

            this._loadingDiv.appendChild(imgBack);

            this._loadingDiv.appendChild(this._loadingTextDiv);

            this._resizeLoadingUI = function () {
                var canvasRect = _this.getRenderingCanvasClientRect();
                _this._loadingDiv.style.position = "absolute";
                _this._loadingDiv.style.left = canvasRect.left + "px";
                _this._loadingDiv.style.top = canvasRect.top + "px";
                _this._loadingDiv.style.width = canvasRect.width + "px";
                _this._loadingDiv.style.height = canvasRect.height + "px";
            };
            this._resizeLoadingUI();

            window.addEventListener("resize", this._resizeLoadingUI);

            this._loadingDiv.style.backgroundColor = this._loadingDivBackgroundColor;
            document.body.appendChild(this._loadingDiv);

            setTimeout(function () {
                _this._loadingDiv.style.opacity = "1";
                imgBack.style.transform = "rotateZ(360deg)";
                imgBack.style.webkitTransform = "rotateZ(360deg)";
            }, 0);
        };

        Object.defineProperty(Engine.prototype, "loadingUIText", {
            set: function (text) {
                if (!this._loadingDiv) {
                    return;
                }

                this._loadingTextDiv.innerHTML = text;
            },
            enumerable: true,
            configurable: true
        });

        Object.defineProperty(Engine.prototype, "loadingUIBackgroundColor", {
            get: function () {
                return this._loadingDivBackgroundColor;
            },
            set: function (color) {
                this._loadingDivBackgroundColor = color;

                if (!this._loadingDiv) {
                    return;
                }

                this._loadingDiv.style.backgroundColor = this._loadingDivBackgroundColor;
            },
            enumerable: true,
            configurable: true
        });


        Engine.prototype.hideLoadingUI = function () {
            var _this = this;
            if (!this._loadingDiv) {
                return;
            }

            var onTransitionEnd = function () {
                if (!_this._loadingDiv) {
                    return;
                }
                document.body.removeChild(_this._loadingDiv);
                window.removeEventListener("resize", _this._resizeLoadingUI);

                _this._loadingDiv = null;
            };

            this._loadingDiv.style.opacity = "0";
            this._loadingDiv.addEventListener("transitionend", onTransitionEnd);
        };

        Engine.isSupported = function () {
            try  {
                var tempcanvas = document.createElement("canvas");
                var gl = tempcanvas.getContext("webgl") || tempcanvas.getContext("experimental-webgl");

                return gl != null && !!window.WebGLRenderingContext;
            } catch (e) {
                return false;
            }
        };
        Engine._ALPHA_DISABLE = 0;
        Engine._ALPHA_ADD = 1;
        Engine._ALPHA_COMBINE = 2;

        Engine._DELAYLOADSTATE_NONE = 0;
        Engine._DELAYLOADSTATE_LOADED = 1;
        Engine._DELAYLOADSTATE_LOADING = 2;
        Engine._DELAYLOADSTATE_NOTLOADED = 4;

        Engine.Epsilon = 0.001;
        Engine.CollisionsEpsilon = 0.001;
        Engine.ShadersRepository = "Babylon/Shaders/";
        return Engine;
    })();
    BABYLON.Engine = Engine;
})(BABYLON || (BABYLON = {}));
