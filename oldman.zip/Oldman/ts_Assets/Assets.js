﻿var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var Assets = (function (_super) {
    __extends(Assets, _super);
    function Assets(scene) {
        var _this = this;
        _super.call(this);
        this.texturesName = ["eyes.jpg", "main.jpg", "pantsBump.jpg", "pantsDiffuse.jpg", "tete.jpg", "tetebump.jpg", "torseBump.jpg", "torseDiffuse.jpg", "teteZ.jpg"];
        this.sceneMaterial = SceneMaterial.getInstance();
        this.scene = scene;

        this.assetsManager = new BABYLON.AssetsManager(this.scene);

        var meshTask = this.assetsManager.addMeshTask("character", "", Constant.CHARACTER_PATH, "char1.babylon");
        meshTask.onSuccess = function (task) {
            return _this.meshIsloaded(task);
        };

        for (var i = 0; i < this.texturesName.length; i++) {
            var textureTask = this.assetsManager.addTextureTask(this.texturesName[i], Constant.CHARACTER_PATH + this.texturesName[i]);
            textureTask.onSuccess = function (task) {
                return _this.textureIsloaded(task);
            };
            textureTask.onError = function (task) {
                return _this.textureError(task);
            };
        }

        var backTask = this.assetsManager.addTextureTask("fond.jpg", "Assets/misc/fond.jpg");
        backTask.onSuccess = function (task) {
            return _this.textureIsloaded(task);
        };
        backTask.onError = function (task) {
            return _this.textureError(task);
        };

        this.assetsManager.onFinish = function (tasks) {
            return _this.finish(tasks);
        };
        this.assetsManager.load();
    }
    Assets.prototype.textureIsloaded = function (task) {
        console.log(task.name);
        var textureName = task.name;
        switch (textureName) {
            case this.texturesName[0]:
                Assets.EyesDiffuse = task.texture;
                break;
            case this.texturesName[1]:
                Assets.MainDiffuse = task.texture;
                break;
            case this.texturesName[2]:
                Assets.PantsBump = task.texture;
                break;
            case this.texturesName[3]:
                Assets.PantsDiffuse = task.texture;
                break;
            case this.texturesName[4]:
                Assets.TeteDiffuse = task.texture;
                break;
            case this.texturesName[5]:
                Assets.TeteBump = task.texture;
                break;
            case this.texturesName[6]:
                Assets.TorseBump = task.texture;
                break;
            case this.texturesName[7]:
                Assets.TorseDiffuse = task.texture;
                break;
            case this.texturesName[8]:
                Assets.TeteZDiffuse = task.texture;
                break;

            case "fond.jpg":
                Assets.Background = task.texture;
        }

        console.log("texture n loaded");
    };

    Assets.prototype.meshIsloaded = function (task) {
        Assets.Character = task.loadedMeshes[0];
        Assets.Character.isVisible = false;
        Assets.Skeleton = task.loadedSkeletons[0];
    };

    Assets.prototype.finish = function (tasks) {
        this.sceneMaterial.create(this.scene);
        this.trigger(Constant.EVENT_ASSETS_MANAGEMENT);
    };

    Assets.prototype.textureError = function (task) {
        console.log("AssetManager error :" + task.name);
    };

    Assets.getCharacterAsClone = function () {
        return Assets.Character.clone("meshclone", null);
    };

    Assets.getSkeletonAsClone = function () {
        return Assets.Skeleton.clone("0", "0");
    };
    return Assets;
})(EventManagement);
