﻿class Assets extends EventManagement {

    private scene: BABYLON.Scene;
    private assetsManager: BABYLON.AssetsManager;

    private texturesName = ["eyes.jpg", "main.jpg", "pantsBump.jpg", "pantsDiffuse.jpg", "tete.jpg", "tetebump.jpg", "torseBump.jpg", "torseDiffuse.jpg","teteZ.jpg" ];

    //We have to ini sceneMaterial singleton before load texture...           
    private sceneMaterial: SceneMaterial = SceneMaterial.getInstance(); 

    // Assets as Static 

    // Main character
    static Character: BABYLON.AbstractMesh;
    static Skeleton: BABYLON.Skeleton;
    // Character textures
    static EyesDiffuse: BABYLON.Texture;
    static MainDiffuse: BABYLON.Texture;
    static PantsBump: BABYLON.Texture;
    static PantsDiffuse: BABYLON.Texture;
    static TeteDiffuse: BABYLON.Texture;
    static TeteBump: BABYLON.Texture;
    static TorseBump: BABYLON.Texture;
    static TorseDiffuse: BABYLON.Texture;
    static TeteZDiffuse: BABYLON.Texture;
    // Background texture
    static Background: BABYLON.Texture;

    constructor(scene: BABYLON.Scene) {

        super();
        this.scene = scene;
       
       
        

        // Assets 
        this.assetsManager = new BABYLON.AssetsManager(this.scene);

        // the mesh
        var meshTask = this.assetsManager.addMeshTask("character", "", Constant.CHARACTER_PATH, "char1.babylon");
        meshTask.onSuccess = (task) => this.meshIsloaded(task);

        // the character textures
        for (var i = 0; i < this.texturesName.length; i++) {
            var textureTask = this.assetsManager.addTextureTask(this.texturesName[i], Constant.CHARACTER_PATH + this.texturesName[i]);
            textureTask.onSuccess = (task) => this.textureIsloaded(task);
            textureTask.onError = (task) => this.textureError(task);
        }

        //background texture
        var backTask = this.assetsManager.addTextureTask("fond.jpg", "Assets/misc/fond.jpg");
        backTask.onSuccess = (task) => this.textureIsloaded(task);
        backTask.onError = (task) => this.textureError(task);

        this.assetsManager.onFinish = (tasks) => this.finish(tasks);
        this.assetsManager.load();
    }



    private textureIsloaded(task): void {
        console.log(task.name); 
        var textureName: string = task.name;
        switch (textureName) {
            case this.texturesName[0]: Assets.EyesDiffuse = task.texture;  break;
            case this.texturesName[1]: Assets.MainDiffuse = task.texture;  break;
            case this.texturesName[2]: Assets.PantsBump = task.texture;    break;
            case this.texturesName[3]: Assets.PantsDiffuse = task.texture; break;
            case this.texturesName[4]: Assets.TeteDiffuse = task.texture;  break;
            case this.texturesName[5]: Assets.TeteBump = task.texture;     break;
            case this.texturesName[6]: Assets.TorseBump = task.texture;    break;
            case this.texturesName[7]: Assets.TorseDiffuse = task.texture; break;
            case this.texturesName[8]: Assets.TeteZDiffuse = task.texture; break;
         
            case "fond.jpg": Assets.Background = task.texture;
        }

        console.log("texture n loaded"); 

    }

    private meshIsloaded(task): void {
     
        Assets.Character = task.loadedMeshes[0];    
        Assets.Character.isVisible = false;  
        Assets.Skeleton = task.loadedSkeletons[0];
    }

    private finish(tasks) {
        // create textures now and trigger event to Main to say hey doanloading is finish
        this.sceneMaterial.create(this.scene); 
        this.trigger(Constant.EVENT_ASSETS_MANAGEMENT);
    }

    private textureError(task): void {
        console.log("AssetManager error :" + task.name);
    }

    static getCharacterAsClone(): BABYLON.AbstractMesh {

        return Assets.Character.clone("meshclone", null);
    }

    static getSkeletonAsClone(): BABYLON.Skeleton {

        return Assets.Skeleton.clone("0","0"); 
    }




} 