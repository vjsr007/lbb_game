class Compute {


    static GetDistanceV3(p1: BABYLON.Vector3, p2: BABYLON.Vector3): number {
       
        var x: number = (p1.x - p2.x) * (p1.x - p2.x);
        var y: number = (p1.y - p2.y) * (p1.y - p2.y);
        var z: number = (p1.z - p2.z) * (p1.z - p2.z);

       return  Math.sqrt(x + y + z);        
        
    }



    static GetMiddle(p1: BABYLON.Vector3, p2: BABYLON.Vector3): BABYLON.Vector3 {

        return new BABYLON.Vector3((p1.x + p2.x) * .5, (p1.y + p2.y) * .5, (p1.z + p2.z) * .5);

    }

    static MatrixToXYZ(matrix: BABYLON.Matrix): BABYLON.Vector3 {

       return  new BABYLON.Vector3(matrix.m[12], matrix.m[13], matrix.m[14]);
        
    } 

    static MatrixToXYZ_( v:BABYLON.Vector3 ,    m: BABYLON.Matrix): BABYLON.Vector3 {

        v.x = m.m[12]; v.y = m.m[13]; v.z = m.m[14];
        return v;

    } 


  



}