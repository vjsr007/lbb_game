﻿var Constant = (function () {
    function Constant() {
    }
    Constant.IS_REAL = "REAL";
    Constant.IS_DUMMY = "DUMMY";

    Constant.EVENT = "EVENT";

    Constant.EVENT_ASSETS_MANAGEMENT = "EVENT_ASSETS_MANAGMENT";

    Constant.CHARACTER_PATH = "Assets/character/";

    Constant.NLAB = 10;

    Constant.OVER_PLAY = "OVER_PLAY";
    Constant.OVER_GRAVITY = "OVER_GRAVITY";
    Constant.OVER_RENDER = "OVER_RENDER";
    Constant.OVER_IMPULSE = "OVER_IMPULSE";
    Constant.OVER_RESET = "OVER_RESET";
    Constant.OVER_HANGED = "OVER_HANGED";
    Constant.OVER_GRAV = "OVER_GRAV";
    Constant.OVER_TARGET = "OVER_TARGET";
    Constant.OVER_LAB = "OVER_LAB";

    Constant.CLIC_PLAY = "CLIC_PLAY";
    Constant.CLIC_GRAVITY = "CLIC_GRAVITY";
    Constant.CLIC_RENDER = "CLIC_RENDER";
    Constant.CLIC_IMPULSE = "CLIC_IMPULSE";
    Constant.CLIC_RESET = "CLIC_RESET";
    Constant.CLIC_HANGED = "CLIC_HANGED";
    Constant.CLIC_TARGET = "CLIC_TARGET";
    Constant.CLIC_LAB = "CLIC_LAB";

    Constant.INTRO = true;
    Constant.PLAY = false;
    Constant.GRAVITY = false;
    Constant.HANGED = false;
    Constant.MULTI = false;
    Constant.TARGET = false;
    Constant.LAB = false;

    Constant.R1 = new BABYLON.Quaternion(0.5, -0.4999999999999999, 0.5, 0.5000000000000001);

    Constant.R2 = new BABYLON.Quaternion(-0.5, 0.4999999999999999, 0.5, 0.5000000000000001);

    Constant.R3 = new BABYLON.Quaternion(0.7071067811865476, -0.7071067811865475, 4.329780281177466e-17, 4.329780281177467e-17);
    return Constant;
})();
