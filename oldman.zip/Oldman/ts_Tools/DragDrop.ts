﻿class DragDrop {

    // private engine: BABYLON.Engine;
    private canvas: any;
    public scene: BABYLON.Scene;
    private camera: BABYLON.Camera;
    private ground: BABYLON.AbstractMesh;
    private oldman: BABYLON.AbstractMesh;
    private startingPoint;
    private currentMesh;

    private x: number = -1;
    private y: number = -1;

    static X = 0; static Y = 0;
    static _destinationX: number = 0;
    static _destinationY: number = 0;
    static _vx: number = 0;
    static _vy: number = 0;
    static _moveSpeedMax: number = 1000;
    static px = 0;
    static py = 0;
    static _decay: number = .97;



    constructor(scene) {
        this.scene = scene;
        this.camera = this.scene.getCameraByName("Camera");
        this.ground = this.scene.getMeshByName("ground");
        this.oldman = this.scene.getMeshByName("oldman");
        this.canvas = document.getElementById("renderCanvas");
        this.canvas.addEventListener("pointerdown", (evt) => this.onPointerDown(evt), false);
        this.canvas.addEventListener("pointerup", (evt) => this.onPointerUp(evt), false);
        this.canvas.addEventListener("pointermove", (evt) => this.onPointerMove(evt), false);

        DragDrop.X = DragDrop.Y = DragDrop._destinationX = DragDrop._destinationY = DragDrop._vx = DragDrop._vy = DragDrop.px = DragDrop.py = 0;


    }

    private getGroundPosition(evt) {
        // Use a predicate to get position on the ground

        var pickinfo = this.scene.pick(this.scene.pointerX, this.scene.pointerY);
        if (pickinfo.hit) {

            return pickinfo.pickedPoint;
        }

        return null;
    }

    private onPointerDown(evt) {

        if (evt.button !== 0) {
            return;
        }
        // check if we are under a mesh
        var pickInfo = this.scene.pick(this.scene.pointerX, this.scene.pointerY);
        if (pickInfo.hit) {
            this.currentMesh = pickInfo.pickedMesh;

            this.startingPoint = this.currentMesh.position;

            /*if (this.startingPoint) { // we need to disconnect camera from canvas
                setTimeout(() => {
                    this.camera.detachControl(this.canvas);
                }, 0);
            }*/
        }
    }

    private onPointerUp(evt) {
        if (this.startingPoint) {

            this.camera.attachControl(this.canvas);
            this.startingPoint = null;
            return;
        }
    }

    public move(): BABYLON.Vector2 {


        var current = new BABYLON.Vector3((this.x - (this.canvas.width / 2)) * .25, -this.y + (this.canvas.height / 3.3) > -70 ? -this.y + 300 : -70, 0);
        var v: BABYLON.Vector2 = DragDrop.updatePosition(current.x, current.y, 0, 120);
        return new BABYLON.Vector2(v.x, v.y + 110);

    }

    private onPointerMove(evt: MSEventObj) {
        this.x = evt.x;
        this.y = evt.y;
    }

    static updatePosition(x: number, y: number, px, py): BABYLON.Vector2 {


        // update destination
        DragDrop._destinationX = x;
        DragDrop._destinationY = y;

        // update velocity
        DragDrop._vx += (DragDrop._destinationX - DragDrop.px) / DragDrop._moveSpeedMax;
        DragDrop._vy += (DragDrop._destinationY - DragDrop.py) / DragDrop._moveSpeedMax;


        // apply decay (drag)
        DragDrop._vx *= DragDrop._decay;
        DragDrop._vy *= DragDrop._decay;

     
        // update position
        DragDrop.px += DragDrop._vx;
        DragDrop.py += DragDrop._vy;

        return new BABYLON.Vector2(DragDrop.px, DragDrop.py);

    }


} 