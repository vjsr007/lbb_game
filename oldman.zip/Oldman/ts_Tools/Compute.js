var Compute = (function () {
    function Compute() {
    }
    Compute.GetDistanceV3 = function (p1, p2) {
        var x = (p1.x - p2.x) * (p1.x - p2.x);
        var y = (p1.y - p2.y) * (p1.y - p2.y);
        var z = (p1.z - p2.z) * (p1.z - p2.z);

        return Math.sqrt(x + y + z);
    };

    Compute.GetMiddle = function (p1, p2) {
        return new BABYLON.Vector3((p1.x + p2.x) * .5, (p1.y + p2.y) * .5, (p1.z + p2.z) * .5);
    };

    Compute.MatrixToXYZ = function (matrix) {
        return new BABYLON.Vector3(matrix.m[12], matrix.m[13], matrix.m[14]);
    };

    Compute.MatrixToXYZ_ = function (v, m) {
        v.x = m.m[12];
        v.y = m.m[13];
        v.z = m.m[14];
        return v;
    };
    return Compute;
})();
