﻿class Constant {

   

    // bone type there are several dummmy so compute thing 
    static IS_REAL:  string  = "REAL"; 
    static IS_DUMMY: string = "DUMMY"; 

    // ui
    static EVENT :string = "EVENT";

    // Assets management
    static EVENT_ASSETS_MANAGEMENT = "EVENT_ASSETS_MANAGMENT";

    // folder path
    static CHARACTER_PATH = "Assets/character/";

    // lab
    static NLAB: number = 10; 


    // event
    static OVER_PLAY: string = "OVER_PLAY";
    static OVER_GRAVITY:string = "OVER_GRAVITY";
    static OVER_RENDER: string = "OVER_RENDER";
    static OVER_IMPULSE:string = "OVER_IMPULSE";
    static OVER_RESET:  string = "OVER_RESET";
    static OVER_HANGED: string = "OVER_HANGED";
    static OVER_GRAV:   string = "OVER_GRAV";
    static OVER_TARGET: string = "OVER_TARGET";
    static OVER_LAB: string = "OVER_LAB";

    static CLIC_PLAY:    string = "CLIC_PLAY";
    static CLIC_GRAVITY: string = "CLIC_GRAVITY";
    static CLIC_RENDER:  string = "CLIC_RENDER";
    static CLIC_IMPULSE: string = "CLIC_IMPULSE";
    static CLIC_RESET:   string = "CLIC_RESET";
    static CLIC_HANGED:  string = "CLIC_HANGED";
    static CLIC_TARGET: string = "CLIC_TARGET";
    static CLIC_LAB: string = "CLIC_LAB";



    // manage state
    public static INTRO:   boolean = true;
    public static PLAY:    boolean = false;   
    public static GRAVITY: boolean = false; 
    public static HANGED: boolean = false;
    public static MULTI: boolean = false;
    public static TARGET: boolean = false;
    public static LAB: boolean = false;

    // precalculate rotation QUATERNION BABYLON.Quaternion.RotationYawPitchRoll(...)

    // 0, Math.PI / 2, Math.PI / 2
    public static R1: BABYLON.Quaternion = new BABYLON.Quaternion(0.5, -0.4999999999999999, 0.5, 0.5000000000000001);
    //0, -Math.PI / 2, Math.PI / 2);
    public static R2: BABYLON.Quaternion = new BABYLON.Quaternion(-0.5, 0.4999999999999999, 0.5, 0.5000000000000001);
    // 0, Math.PI, Math.PI / 2   
    public static R3: BABYLON.Quaternion = new BABYLON.Quaternion(0.7071067811865476, -0.7071067811865475, 4.329780281177466e-17, 4.329780281177467e-17);



   
  
    





    

}