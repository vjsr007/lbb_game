﻿var DragDrop = (function () {
    function DragDrop(scene) {
        var _this = this;
        this.x = -1;
        this.y = -1;
        this.scene = scene;
        this.camera = this.scene.getCameraByName("Camera");
        this.ground = this.scene.getMeshByName("ground");
        this.oldman = this.scene.getMeshByName("oldman");
        this.canvas = document.getElementById("renderCanvas");
        this.canvas.addEventListener("pointerdown", function (evt) {
            return _this.onPointerDown(evt);
        }, false);
        this.canvas.addEventListener("pointerup", function (evt) {
            return _this.onPointerUp(evt);
        }, false);
        this.canvas.addEventListener("pointermove", function (evt) {
            return _this.onPointerMove(evt);
        }, false);

        DragDrop.X = DragDrop.Y = DragDrop._destinationX = DragDrop._destinationY = DragDrop._vx = DragDrop._vy = DragDrop.px = DragDrop.py = 0;
    }
    DragDrop.prototype.getGroundPosition = function (evt) {
        var pickinfo = this.scene.pick(this.scene.pointerX, this.scene.pointerY);
        if (pickinfo.hit) {
            return pickinfo.pickedPoint;
        }

        return null;
    };

    DragDrop.prototype.onPointerDown = function (evt) {
        if (evt.button !== 0) {
            return;
        }

        var pickInfo = this.scene.pick(this.scene.pointerX, this.scene.pointerY);
        if (pickInfo.hit) {
            this.currentMesh = pickInfo.pickedMesh;

            this.startingPoint = this.currentMesh.position;
        }
    };

    DragDrop.prototype.onPointerUp = function (evt) {
        if (this.startingPoint) {
            this.camera.attachControl(this.canvas);
            this.startingPoint = null;
            return;
        }
    };

    DragDrop.prototype.move = function () {
        var current = new BABYLON.Vector3((this.x - (this.canvas.width / 2)) * .25, -this.y + (this.canvas.height / 3.3) > -70 ? -this.y + 300 : -70, 0);
        var v = DragDrop.updatePosition(current.x, current.y, 0, 120);
        return new BABYLON.Vector2(v.x, v.y + 110);
    };

    DragDrop.prototype.onPointerMove = function (evt) {
        this.x = evt.x;
        this.y = evt.y;
    };

    DragDrop.updatePosition = function (x, y, px, py) {
        DragDrop._destinationX = x;
        DragDrop._destinationY = y;

        DragDrop._vx += (DragDrop._destinationX - DragDrop.px) / DragDrop._moveSpeedMax;
        DragDrop._vy += (DragDrop._destinationY - DragDrop.py) / DragDrop._moveSpeedMax;

        DragDrop._vx *= DragDrop._decay;
        DragDrop._vy *= DragDrop._decay;

        DragDrop.px += DragDrop._vx;
        DragDrop.py += DragDrop._vy;

        return new BABYLON.Vector2(DragDrop.px, DragDrop.py);
    };
    DragDrop.X = 0;
    DragDrop.Y = 0;
    DragDrop._destinationX = 0;
    DragDrop._destinationY = 0;
    DragDrop._vx = 0;
    DragDrop._vy = 0;
    DragDrop._moveSpeedMax = 1000;
    DragDrop.px = 0;
    DragDrop.py = 0;
    DragDrop._decay = .97;
    return DragDrop;
})();
