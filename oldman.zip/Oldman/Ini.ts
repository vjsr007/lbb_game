﻿class Ini {


    private engine: BABYLON.Engine;
    private scene: BABYLON.Scene;
    private main: Main;
    private canvas; 
   

 
    private assetsManager: BABYLON.AssetsManager;

    constructor() {

        this.canvas = document.getElementById("renderCanvas");

        if (!BABYLON.Engine.isSupported()) {
            window.alert('Browser not supported');

        } else {

            this.engine = new BABYLON.Engine(this.canvas, true);
            this.scene = new BABYLON.Scene(this.engine);
            this.main= new Main(this.scene);
           

            window.addEventListener("resize", () => this.engine.resize());                     

            // Assets, assets manager
            var assets = new Assets(this.scene);
            assets.bind(Constant.EVENT_ASSETS_MANAGEMENT, (event) => this.assetsAreLoaded(event));


        }
    }

    private assetsAreLoaded(event) {

        console.log("receive final event from assets management");     
        this.main.start();
        this.scene.executeWhenReady(() => this.iniCamera());
        this.engine.runRenderLoop(() => this.mainLoop());
    }

    private iniCamera(): void {

        if (this.scene.activeCamera) {
            this.scene.activeCamera.attachControl(this.canvas);
        }

    }


    private mainLoop(): void {

        var container = document.getElementById("fps");
        container.innerHTML = BABYLON.Tools.GetFps().toFixed()
        + " fps" + "<br>";

        if (this.scene) {    
            this.main.loop();   
            this.scene.render();
        }
    }



} 

document.addEventListener("DOMContentLoaded",() => new Ini(), false);